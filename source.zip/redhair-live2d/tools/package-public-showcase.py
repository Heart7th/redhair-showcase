"""Build an explicit, bounded public site and its corresponding source archive."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile

project=Path(__file__).resolve().parents[1]
site=project/'public-site'
site.mkdir(exist_ok=True)
app=project/'showcase-preview'
vendor=project/'vendor/myriad-figure'
config=json.loads((project/'shoulder-assets/arm-keyforms.json').read_text())

def images(value):
    if isinstance(value,list):
        return [name for item in value for name in images(item)]
    if not isinstance(value,dict):return []
    return [name for key,item in value.items() for name in
        ([item] if (key=='image' or key.endswith('Image')) and isinstance(item,str) and item.endswith('.png') else images(item))]

files=[]
files.extend(f for f in app.iterdir() if f.is_file() and f.name not in ['hand-flare-qa.mjs','file-qa.mjs','compare-motion.mjs','motion-kinematics-qa.mjs','motion-qa.mjs','performance-qa.mjs'])
files.extend(f for f in (vendor/'src').rglob('*') if f.is_file())
files.extend(f for f in (vendor/'contracts').rglob('*') if f.is_file())
files.extend(vendor/name for name in ['package.json','package-lock.json','tsconfig.json','LICENSE'])
files.extend(project/name for name in ['body-rig/rig-source-body.json','preview/export/atlas.png','shoulder-assets/arm-keyforms.json','tools/package-public-showcase.py'])
for name in sorted(set(images(config))):
    if Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('Unexpected runtime image path')
    files.append(project/'shoulder-assets'/name)

secret=re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{24,}|BEGIN (?:RSA |OPENSSH )?PRIVATE KEY|/Users/[^/\s]+/(?:Library|\.ssh)/|CindyGlobal[/]owners')
manifest=[]
for f in sorted(set(files)):
    content=f.read_bytes()
    if f.suffix.lower() not in ['.png','.jpg','.webp'] and secret.search(content):
        raise ValueError('Private material detected in bounded source file: '+str(f.relative_to(project)))
    manifest.append({'path':str(Path('redhair-live2d')/f.relative_to(project)),'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()})
archive_readme='''# 公开演示对应源码

此压缩包包含互动展示页的预览源码、所用运行时源码、姿态与绑定配置、图集及实际使用的图片。

构建：
1. 进入 redhair-live2d/vendor/myriad-figure，运行 npm ci。
2. 进入 redhair-live2d/showcase-preview，运行 node build-offline.mjs。
3. 输出 redhair-live2d/showcase-preview/export/index.html 为自包含页面。

运行时代码沿用 AGPL-3.0，包含上游 MIT 来源；请保留 vendor/myriad-figure/LICENSE 和 src/anime25drig/vendor/ 中的许可、NOTICE。
角色图像为本次演示素材，此源码发布不对人物图像另行授予许可。
'''
with zipfile.ZipFile(site/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(set(files)):z.write(f,str(Path('redhair-live2d')/f.relative_to(project)))
    z.writestr('README.md',archive_readme)
    z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(site/'source.zip') as z:
    if z.testzip() is not None:raise ValueError('Source archive verification failed')
html=(app/'export/index.html').read_bytes()
if secret.search(html):raise ValueError('Private material detected in public HTML')
shutil.copyfile(app/'export/index.html',site/'index.html')
video=app/'export/红发少女-九种表情四向转脸.mp4'
if not video.exists():raise FileNotFoundError('Current four-direction face recording is missing')
shutil.copyfile(video,site/'face-turns.mp4')
(site/'.nojekyll').write_text('')
licenses=site/'licenses';licenses.mkdir(exist_ok=True)
shutil.copyfile(app/'licenses.html',licenses/'index.html')
for name,f in [('AGPL-3.0.txt',vendor/'LICENSE'),('Anime2.5DRig-MIT.txt',vendor/'src/anime25drig/vendor/LICENSE'),('NOTICE.txt',vendor/'src/anime25drig/vendor/NOTICE')]:
    shutil.copyfile(f,licenses/name)
shutil.copyfile(vendor/'LICENSE',site/'LICENSE')
receipt={'site':str(site),'pageBytes':len(html),'sourceFiles':len(manifest),'sourceBytes':(site/'source.zip').stat().st_size,'htmlSha256':hashlib.sha256(html).hexdigest(),'sourceSha256':hashlib.sha256((site/'source.zip').read_bytes()).hexdigest(),'secretScanPassed':True}
(project/'showcase-review').mkdir(exist_ok=True)
(project/'showcase-review/package-validation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
print(json.dumps(receipt,ensure_ascii=False))
