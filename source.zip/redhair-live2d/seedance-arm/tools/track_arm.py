"""Track the raised arm (sleeve and hand) through generated video frames with SAM 2.1."""
import sys, os, glob, json, time
import numpy as np, cv2, torch
from sam2.build_sam import build_sam2_video_predictor

frames_dir, jpeg_dir, out_dir, ckpt, start, end = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5]), int(sys.argv[6])
prompts = json.loads(sys.argv[7])  # {"frame": 0, "positive": [[x,y],...], "negative": [[x,y],...]} or a list of them
prompts = prompts if isinstance(prompts, list) else [prompts]
os.makedirs(jpeg_dir, exist_ok=True); os.makedirs(out_dir, exist_ok=True)
files = sorted(glob.glob(frames_dir + '/*.png'))[start:end]
for i, f in enumerate(files):
    target = os.path.join(jpeg_dir, f'{i:05d}.jpg')
    if not os.path.exists(target): cv2.imwrite(target, cv2.imread(f), [cv2.IMWRITE_JPEG_QUALITY, 97])
device = torch.device('mps' if torch.backends.mps.is_available() else 'cpu')
predictor = build_sam2_video_predictor('configs/sam2.1/sam2.1_hiera_b+.yaml', ckpt, device=device)
t0 = time.time()
with torch.inference_mode():
    state = predictor.init_state(video_path=jpeg_dir, offload_video_to_cpu=True)
    for prompt in prompts:
        points = np.array(prompt['positive'] + prompt['negative'], np.float32)
        labels = np.array([1] * len(prompt['positive']) + [0] * len(prompt['negative']), np.int32)
        predictor.add_new_points_or_box(state, frame_idx=prompt.get('frame', 0), obj_id=1, points=points, labels=labels)
    areas = {}
    for frame_idx, obj_ids, logits in predictor.propagate_in_video(state):
        prob = torch.sigmoid(logits[0, 0]).float().cpu().numpy()
        cv2.imwrite(os.path.join(out_dir, f'{start + frame_idx:04d}.png'), np.clip(prob * 255 + .5, 0, 255).astype(np.uint8))
        areas[start + frame_idx] = int((prob > .5).sum())
print(json.dumps({'frames': len(files), 'seconds': round(time.time() - t0, 1), 'device': str(device), 'areaMin': min(areas.values()), 'areaMax': max(areas.values())}))
