"""Composite packed arm sprites over the arm-free rig render, for visual checks."""
import sys, json, os
import numpy as np, cv2
from PIL import Image
RENDER_SCALE, WORLD_X0, PLAYBACK_X = 1080 / 730, 430.0, 463.0
def composite(plate, manifest, atlases, k):
    f = manifest['frames'][k]
    x, y, w, h = f['rect']; sprite = atlases[f['atlas']][y:y + h, x:x + w].astype(np.float32) / 255
    sx, sy, sw, sh = f['world']
    rx, ry = (sx + PLAYBACK_X - WORLD_X0) * RENDER_SCALE, sy * RENDER_SCALE
    size = (round(sw * RENDER_SCALE), round(sh * RENDER_SCALE))
    sprite = cv2.resize(sprite, size, interpolation=cv2.INTER_CUBIC)
    out = plate.copy(); x0, y0 = round(rx), round(ry)
    H, W = out.shape[:2]; x1, y1 = min(W, x0 + size[0]), min(H, y0 + size[1])
    s = sprite[:y1 - y0, :x1 - x0]; a = s[..., 3:]
    out[y0:y1, x0:x1] = out[y0:y1, x0:x1] * (1 - a) + s[..., :3] * a
    return out
if __name__ == '__main__':
    d, out_path, picks = sys.argv[1], sys.argv[2], [int(v) for v in sys.argv[3].split(',')]
    manifest = json.load(open(os.path.join(d, 'manifest.json')))
    atlases = [np.asarray(Image.open(os.path.join(d, n)).convert('RGBA')) for n in manifest['atlases']]
    plate = np.asarray(Image.open(sys.argv[4]).convert('RGB')).astype(np.float32) / 255
    crop = [int(v) for v in sys.argv[5].split(',')]
    tiles = []
    for k in picks:
        c = composite(plate, manifest, atlases, k)[crop[1]:crop[3], crop[0]:crop[2]]
        t = (np.clip(c, 0, 1) * 255).astype(np.uint8)
        t = cv2.resize(t, (t.shape[1] // 2, t.shape[0] // 2), interpolation=cv2.INTER_AREA)
        cv2.putText(t, f"{manifest['frames'][k]['segment']}{manifest['frames'][k]['clipFrame']}", (6, 22), cv2.FONT_HERSHEY_SIMPLEX, .6, (255, 255, 0), 2)
        tiles.append(t)
    Image.fromarray(np.hstack(tiles)).save(out_path); print(np.hstack(tiles).shape)
