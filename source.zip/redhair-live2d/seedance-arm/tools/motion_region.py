"""Register generated video frames to the rendered first frame and find where the arm moves."""
import sys, glob, json
import numpy as np, cv2

def register(first, frame):
    """Affine (render -> video) for one frame; the generated clip zooms slightly about its centre."""
    g0 = cv2.GaussianBlur(cv2.cvtColor(first, cv2.COLOR_BGR2GRAY).astype(np.float32), (0, 0), 2)
    g1 = cv2.GaussianBlur(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32), (0, 0), 2)
    warp = np.eye(2, 3, dtype=np.float32)
    _, warp = cv2.findTransformECC(g0, g1, warp, cv2.MOTION_AFFINE, (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-6), None, 5)
    return warp

def main(frames_dir, first_path, start, end, out_json, out_png):
    files = sorted(glob.glob(frames_dir + '/*.png'))[start:end]
    first = cv2.imread(first_path)
    # Registration from the still opening frame; the camera holds, so one map serves the clip.
    warp = register(first, cv2.imread(files[0]))
    inverse = cv2.invertAffineTransform(warp)
    h, w = first.shape[:2]
    base = cv2.warpAffine(cv2.imread(files[0]), inverse, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE).astype(np.int16)
    union = np.zeros((h, w), np.uint8)
    for f in files[1:]:
        img = cv2.warpAffine(cv2.imread(f), inverse, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE).astype(np.int16)
        diff = np.abs(img - base).max(axis=2)
        union |= (cv2.GaussianBlur(diff.astype(np.float32), (0, 0), 1.5) > 28).astype(np.uint8)
    union = cv2.morphologyEx(union, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(union)
    keep = np.zeros_like(union)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] > 4000: keep[labels == i] = 1
    ys, xs = np.nonzero(keep)
    vis = first.copy(); vis[keep > 0] = (0.45 * vis[keep > 0] + 0.55 * np.array([40, 40, 255])).astype(np.uint8)
    cv2.imwrite(out_png, cv2.resize(vis, (w // 3, h // 3)))
    np.save(out_json.replace('.json', '.npy'), keep)
    json.dump({'frames': [start, end], 'warpRenderToVideo': warp.tolist(), 'bbox': [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())], 'components': int(n - 1)}, open(out_json, 'w'), indent=1)
    print(json.dumps({'bbox': [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())], 'warp': np.round(warp, 4).tolist()}))

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), sys.argv[5], sys.argv[6])
