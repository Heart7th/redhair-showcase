"""Write the runtime `videoArm` section: frames from the cut clips, the raise path, the wave loop and the demo timing.

usage: build_config.py <first-half sprites> <second-half sprites> <reach frame> <wave start> <wave end> [label] [lower]
`lower` = 'clip' plays the second clip's own lowering; 'reverse' (for a clip that ends
with the hand still raised) plays the raise back: second clip reach→start, then the first.
The second half starts from the first half's last (chest) frame. `reach` is the clip
frame where the hand arrives at its raised pose; [wave start, wave end] the clip
frames of the gesture loop. Copies the atlases under shoulder-assets/video-arm/.
"""
import sys, os, json, shutil
here = os.path.dirname(os.path.abspath(__file__)); arm = os.path.dirname(here); project = os.path.dirname(arm)
first, second, reach, wave0, wave1 = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
label = sys.argv[6] if len(sys.argv) > 6 else 'raise'
lower = sys.argv[7] if len(sys.argv) > 7 else 'clip'
out_dir = os.path.join(project, 'shoulder-assets', 'video-arm'); os.makedirs(out_dir, exist_ok=True)
for name in os.listdir(out_dir):
    if name.endswith('.webp'): os.remove(os.path.join(out_dir, name))
atlases, frames = [], []
for tag, folder in [('A', first), ('B', second)]:
    m = json.load(open(os.path.join(arm, folder, 'manifest.json')))
    base = len(atlases)
    for name in m['atlases']:
        target = f'{tag}-{name}'; shutil.copyfile(os.path.join(arm, folder, name), os.path.join(out_dir, target)); atlases.append({'image': 'video-arm/' + target})
    for f in m['frames']:
        frames.append({'segment': tag, 'clipFrame': f['clipFrame'], 'atlas': base + f['atlas'], 'rect': f['rect'], 'world': f['world']})
A = [i for i, f in enumerate(frames) if f['segment'] == 'A']; B = [i for i, f in enumerate(frames) if f['segment'] == 'B']
# Close the loop: the clip ends near, not exactly at, the opening pose; cross-fade to a copy of it.
frames.append(dict(frames[A[0]])); rest_copy = len(frames) - 1
def index_of(seg, clip):
    return min((i for i in (A if seg == 'A' else B)), key=lambda i: abs(frames[i]['clipFrame'] - clip))
fps = 24
a_start, chest = index_of('A', 26), A[-1]
reach_i, w0, w1 = index_of('B', reach), index_of('B', wave0), index_of('B', wave1)
t_lift = 1.0
t_chest = t_lift + (frames[chest]['clipFrame'] - frames[a_start]['clipFrame']) / fps
clip_t = lambda i: t_chest + frames[i]['clipFrame'] / fps          # second-half clip frame 0 is the chest frame
demo = [[0, A[0], 0, 'breathe'], [t_lift, A[0], 0, 'prepare']]
for i in A[1:]:                                                     # first half at its own timing
    demo.append([round(t_lift + (frames[i]['clipFrame'] - frames[a_start]['clipFrame']) / fps, 4), i, round(.5 * (frames[i]['clipFrame'] - 26) / (frames[chest]['clipFrame'] - 26), 4), 'lift'])
for i in B:                                                         # second half at its own timing
    c = frames[i]['clipFrame']
    if lower == 'reverse':
        p = .5 + .5 * min(1, c / reach); phase = 'lift' if c < reach else 'greet'
    else:
        p = .5 + .5 * min(1, c / reach) if c <= wave1 else max(0, 1 - (c - wave1) / (frames[B[-1]]['clipFrame'] - wave1))
        phase = 'lift' if c < reach else 'greet' if c <= wave1 else 'lower'
    demo.append([round(clip_t(i), 4), i, round(p, 4), phase])
end = demo[-1][0]
if lower == 'reverse':
    # The clip rests raised: settle onto its reach pose, then play the raise back.
    t = end + .35; demo.append([round(t, 4), reach_i, 1, 'greet'])
    back = [i for i in B if frames[i]['clipFrame'] <= frames[reach_i]['clipFrame']][::-1] + A[::-1]
    prev = reach_i
    for i in back[1:]:
        seg, c = frames[i]['segment'], frames[i]['clipFrame']
        dc = abs(frames[prev]['clipFrame'] - c) if frames[prev]['segment'] == seg else (frames[prev]['clipFrame'] + (frames[chest]['clipFrame'] - c))
        t += max(1, dc) / fps * 1.05                                   # a touch slower going down
        p = .5 + .5 * min(1, c / reach) if seg == 'B' else .5 * max(0, c - 26) / (frames[chest]['clipFrame'] - 26)
        demo.append([round(t, 4), i, round(p, 4), 'lower']); prev = i
    end = t
    demo += [[round(end + 1.2, 4), A[0], 0, 'breathe']]
else:
    demo += [[round(end + .5, 4), rest_copy, 0, 'settle'], [round(end + 1.5, 4), rest_copy, 0, 'breathe']]
timeline = {'rest': A[0], 'raise': [A[0], chest, reach_i], 'progress': [0, .5, 1], 'wave': list(range(w0, w1 + 1)), 'demo': demo, 'label': label}
config_path = os.path.join(project, 'shoulder-assets', 'arm-keyforms.json')
cfg = json.load(open(config_path))
cfg['videoArm'] = {'source': 'Seedance 2.0 VIP image-to-video clips from the rig render (seedance-arm/), arm tracked with SAM 2.1 base-plus, cut and packed by seedance-arm/tools', 'fps': fps, 'atlases': atlases, 'frames': frames, 'timeline': timeline}
json.dump(cfg, open(config_path, 'w'), ensure_ascii=False, indent=2)
print(json.dumps({'frames': len(frames), 'atlases': [a['image'] for a in atlases], 'chest': chest, 'reach': reach_i, 'wave': [w0, w1], 'demoSeconds': demo[-1][0]}))
