"""Compose a clean last frame: the chest frame with its arm replaced by the torso plate and the Flare-drawn raised arm."""
import json
import numpy as np, cv2
def ecc(src, dst, motion=cv2.MOTION_AFFINE, mask=None):
    g0 = cv2.GaussianBlur(cv2.cvtColor(src, cv2.COLOR_BGR2GRAY).astype(np.float32), (0, 0), 2)
    g1 = cv2.GaussianBlur(cv2.cvtColor(dst, cv2.COLOR_BGR2GRAY).astype(np.float32), (0, 0), 2)
    warp = np.eye(2, 3, dtype=np.float32)
    _, warp = cv2.findTransformECC(g0, g1, warp, motion, (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-6), mask, 5)
    return warp
def compose(outer, inner):
    a = np.vstack([outer, [0, 0, 1]]); b = np.vstack([inner, [0, 0, 1]]); return (a @ b)[:2].astype(np.float32)
base = cv2.imread('chest-frame-A072.png'); H, W = base.shape[:2]
plate = cv2.imread('clean-plate.png')
flare = cv2.imread('head-end-flare-1080.png'); arm_new = cv2.imread('head-end-arm-solid.png', 0)
old = cv2.imread('masks-A/0072.png', 0)
manifest = json.load(open('sprites-A/manifest.json'))
warp_a = np.array(manifest['segments'][0]['warpRenderToClip'], np.float32)
shift = [f for f in manifest['frames'] if f['clipFrame'] == 72][0]['shift']
# Clean plate into the chest frame: shift like the clip's torso, then the clip's zoom.
to_video = compose(warp_a, np.float32([[1, 0, shift[0]], [0, 1, shift[1]]]))
plate_v = cv2.warpAffine(plate, to_video, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
# Match the plate's colours to the clip (backdrop and cloth drift) on pixels both show.
old_d = cv2.dilate((old > 100).astype(np.uint8), np.ones((31, 31), np.uint8))
same = (old_d == 0) & (np.abs(plate_v.astype(int) - base.astype(int)).max(axis=2) < 40)
fit = []
for c in range(3):
    x, y = plate_v[..., c][same].astype(np.float64), base[..., c][same].astype(np.float64)
    A = np.vstack([x, np.ones_like(x)]).T; gain, bias = np.linalg.lstsq(A, y, rcond=None)[0]; fit.append((gain, bias))
plate_m = np.dstack([np.clip(plate_v[..., c] * fit[c][0] + fit[c][1], 0, 255) for c in range(3)]).astype(np.float32)
# Flare image onto the chest frame: register on what it kept (left side, face), outside the redrawn region.
keep = np.zeros((H, W), np.uint8); keep[200:1700, 60:560] = 1
warp_f = ecc(base, flare, cv2.MOTION_AFFINE, keep)
inv_f = cv2.invertAffineTransform(warp_f)
flare_v = cv2.warpAffine(flare, inv_f, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE).astype(np.float32)
arm_v = cv2.warpAffine(arm_new, inv_f, (W, H), flags=cv2.INTER_LINEAR).astype(np.float32) / 255
arm_v = cv2.GaussianBlur(arm_v, (0, 0), 1.2)[..., None]
old_a = cv2.GaussianBlur(cv2.dilate((old > 100).astype(np.uint8), np.ones((9, 9), np.uint8)).astype(np.float32), (0, 0), 2.5)[..., None]
out = base.astype(np.float32) * (1 - old_a) + plate_m * old_a
out = out * (1 - arm_v) + flare_v * arm_v
cv2.imwrite('head-end-composed.png', np.clip(out, 0, 255).astype(np.uint8))
print(json.dumps({'colourFit': [[round(g, 3), round(b, 1)] for g, b in fit], 'flareToChest': np.round(warp_f, 4).tolist()}))
