"""Cut the generated arm (sleeve + hand) out of registered video frames into world-space sprites.

Each frame: register the clip back onto the rendered first frame, hold the
shoulder on the rig's torso (translation from the collar/torso band beside
the arm), key the blue-grey backdrop and the red hair out of the tracked
SAM 2 arm mask, decontaminate backdrop spill, and pack the result into WebP
atlases with a JSON manifest in the rig's 640-wide source coordinates.
"""
import sys, os, json, glob
import numpy as np, cv2
from PIL import Image

WORLD_X0, RENDER_SCALE, PLAYBACK_X = 430.0, 1080 / 730, 463.0   # first-frame crop: world x0, px per world px, rig offset
SPRITE_SCALE = float(os.environ.get('SPRITE_SCALE', '1.0'))        # sprite px per world px
KEEP_CHANGE = float(os.environ.get('KEEP_CHANGE', '2.5'))         # drop frames that change less than this (mean |Δ| over the arm, 0-255)

def smooth(x, a, b):
    t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)

def ecc(src, dst, motion=cv2.MOTION_AFFINE, mask=None):
    g0 = cv2.GaussianBlur(cv2.cvtColor(src, cv2.COLOR_BGR2GRAY).astype(np.float32), (0, 0), 2)
    g1 = cv2.GaussianBlur(cv2.cvtColor(dst, cv2.COLOR_BGR2GRAY).astype(np.float32), (0, 0), 2)
    warp = np.eye(2, 3, dtype=np.float32)
    _, warp = cv2.findTransformECC(g0, g1, warp, motion, (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-6), mask, 5)
    return warp

def compose(outer, inner):
    """Affine that applies `inner` then `outer` (both 2x3)."""
    a = np.vstack([outer, [0, 0, 1]]); b = np.vstack([inner, [0, 0, 1]]); return (a @ b)[:2].astype(np.float32)

def robust_track(raw, window=9, limit=1.5, reliable=None):
    """Drift is smooth: drop samples measured through an occluded band or far from a
    running median, interpolate across them, then ease."""
    raw = np.asarray(raw, np.float64); n = len(raw)
    good = np.ones(n, bool) if reliable is None else np.asarray(reliable, bool).copy()
    if good.sum() >= 2:
        idx0 = np.arange(n)
        for c in range(2): raw[:, c] = np.interp(idx0, idx0[good], raw[good, c])
    for i in range(n):
        lo, hi = max(0, i - window // 2), min(n, i + window // 2 + 1)
        if np.abs(raw[i] - np.median(raw[lo:hi], axis=0)).max() > limit: good[i] = False
    idx = np.arange(n); out = raw.copy()
    for c in range(2): out[:, c] = np.interp(idx, idx[good], raw[good, c])
    k = np.array([1, 2, 3, 2, 1], np.float64); k /= k.sum()
    pad = np.pad(out, ((2, 2), (0, 0)), mode='edge')
    return np.stack([np.convolve(pad[:, c], k, mode='valid') for c in range(2)], axis=1), int((~good).sum())

def main(spec_path):
    spec = json.load(open(spec_path))
    root = os.path.dirname(os.path.abspath(spec_path))
    render = cv2.imread(os.path.join(root, spec['renderedFirstFrame']))
    H, W = render.shape[:2]
    out_dir = os.path.join(root, spec['output']); os.makedirs(out_dir, exist_ok=True)
    # Backdrop colour from the rendered frame's empty upper corner.
    bg = np.median(render[60:260, 960:1060].reshape(-1, 3), axis=0).astype(np.float32)
    band = np.zeros((H, W), np.uint8); x0, y0, x1, y1 = spec['anchorBand']; band[y0:y1, x0:x1] = 1
    sprites, previous_shift = [], np.zeros(2, np.float32)
    for segment in spec['segments']:
        files = sorted(glob.glob(os.path.join(root, segment['frames'], '*.png')))
        if 'parentFrame' in segment:
            parent = cv2.imread(os.path.join(root, segment['parentFrame']))
            to_clip = compose(ecc(parent, cv2.imread(files[0])), np.array(segment['parentWarp'], np.float32))
        else:
            to_clip = ecc(render, cv2.imread(files[0]))
        segment['warpRenderToClip'] = to_clip.tolist()
        to_render_pre = cv2.invertAffineTransform(to_clip)
        raw, seen = [], []
        for entry in segment['use']:
            index, mask_index = entry if isinstance(entry, list) else (entry, entry)
            img = cv2.warpAffine(cv2.imread(files[index]), to_render_pre, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
            prob0 = cv2.warpAffine(cv2.imread(os.path.join(root, segment['masks'], f'{mask_index:04d}.png'), 0), to_render_pre, (W, H))
            arm0 = cv2.dilate((prob0 > 64).astype(np.uint8), np.ones((41, 41), np.uint8))
            visible = (band & (1 - arm0)).astype(np.uint8)
            seen.append(visible.sum() / max(1, band.sum()))
            try:
                w = ecc(render, img, cv2.MOTION_TRANSLATION, visible); raw.append([w[0, 2], w[1, 2]])
            except cv2.error:
                raw.append(raw[-1] if raw else [0, 0])
        # Where the arm covers most of the band the measurement is of the arm, not the torso.
        smoothed, outliers = robust_track(raw, reliable=[v > .55 for v in seen])
        if 'fixedShift' in segment:
            # A clip whose body is verifiably still keeps its opening offset throughout.
            smoothed = np.tile(np.asarray(segment['fixedShift'], np.float64), (len(raw), 1))
        segment['occludedFrames'] = int(sum(v <= .55 for v in seen))
        segment['shiftOutliers'] = outliers
        shifts = {i: smoothed[k] for k, i in enumerate(segment['use'] if not isinstance(segment['use'][0], list) else [e[0] for e in segment['use']])}
        to_render = None
        for entry in segment['use']:
            index, mask_index = entry if isinstance(entry, list) else (entry, entry)
            frame = cv2.imread(files[index])
            if to_render is None:
                to_render = to_render_pre
            img = cv2.warpAffine(frame, to_render, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
            prob = cv2.imread(os.path.join(root, segment['masks'], f'{mask_index:04d}.png'), 0)
            # The arm is one solid piece: fill interior holes (ribbed cuffs read as a
            # checkerboard near the threshold) and keep the tracker's soft rim.
            solid = cv2.morphologyEx((prob > 127).astype(np.uint8), cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
            flood = solid.copy(); cv2.floodFill(flood, np.zeros((solid.shape[0] + 2, solid.shape[1] + 2), np.uint8), (0, 0), 1)
            solid = solid | (1 - flood)
            prob = np.maximum(prob, cv2.erode(solid, np.ones((5, 5), np.uint8)) * 255)
            prob = cv2.warpAffine(prob, to_render, (W, H), flags=cv2.INTER_LINEAR)
            # Hold the sleeve root on the rig: the torso/collar band's drift, smoothed over the clip.
            shift = np.asarray(shifts[index], np.float32)
            move = np.float32([[1, 0, -shift[0]], [0, 1, -shift[1]]])
            img = cv2.warpAffine(img, move, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
            prob = cv2.warpAffine(prob, move, (W, H), flags=cv2.INTER_LINEAR)
            # Arm alpha: the tracked mask, grown a little to keep the drawn outline,
            # minus the backdrop and the red hair (the rig draws its own hair).
            f = img.astype(np.float32)
            grown = cv2.dilate(prob, np.ones((5, 5), np.uint8)).astype(np.float32) / 255
            arm_alpha = smooth(cv2.GaussianBlur(grown, (0, 0), 1.0), .3, .7)
            # The clip's backdrop drifts from the rendered colour (encoding, gentle
            # gradients): estimate it locally from backdrop-coloured pixels outside
            # the arm, so a fringe of real backdrop does not survive at a few % alpha.
            cand = ((np.linalg.norm(f - bg, axis=2) < 48) & (prob < 64)).astype(np.float32)
            num = cv2.GaussianBlur(f * cand[..., None], (0, 0), 21); den = cv2.GaussianBlur(cand, (0, 0), 21)[..., None]
            local = np.where(den > 1e-3, num / np.maximum(den, 1e-3), bg)
            dist = np.linalg.norm(f - local, axis=2)
            bg_alpha = smooth(dist, 10, 52)
            b_, g_, r_ = f[..., 0], f[..., 1], f[..., 2]
            redness = r_ - np.maximum(g_, b_)
            # SAM already leaves the hair out; only drop strands that are unmistakably hair, or
            # the edge of a hand lying over hair turns into a grey, half-transparent rim.
            hair = smooth(redness, 115, 150) * smooth(r_, 140, 180) * (cv2.erode(prob, np.ones((9, 9), np.uint8)) > 200)
            alpha = arm_alpha * bg_alpha * (1 - hair)
            # Remove backdrop spill where the edge was mixed with it.
            k = np.clip(bg_alpha, .08, 1)[..., None]
            colour = np.clip((f - (1 - k) * local) / k, 0, 255)
            ys, xs = np.nonzero(alpha > .01)
            if not len(xs): continue
            rx0, ry0, rx1, ry1 = max(0, xs.min() - 3), max(0, ys.min() - 3), min(W, xs.max() + 4), min(H, ys.max() + 4)
            rgba = np.dstack([colour[ry0:ry1, rx0:rx1, ::-1], alpha[ry0:ry1, rx0:rx1, None] * 255]).astype(np.float32)
            # Premultiply before resampling so edges do not darken, then store straight alpha.
            pre = rgba.copy(); pre[..., :3] *= rgba[..., 3:] / 255
            factor = SPRITE_SCALE / RENDER_SCALE
            size = (max(1, round((rx1 - rx0) * factor)), max(1, round((ry1 - ry0) * factor)))
            pre = cv2.resize(pre, size, interpolation=cv2.INTER_AREA)
            a = pre[..., 3:]; straight = np.where(a > 0, pre[..., :3] * 255 / np.maximum(a, 1e-3), 0)
            sprite = np.dstack([np.clip(straight, 0, 255), np.clip(a, 0, 255)]).astype(np.uint8)
            world = [WORLD_X0 + rx0 / RENDER_SCALE - PLAYBACK_X, ry0 / RENDER_SCALE, (rx1 - rx0) / RENDER_SCALE, (ry1 - ry0) / RENDER_SCALE]
            # Holds and near-still frames add memory, not motion: keep a frame only once
            # the premultiplied arm has changed enough since the last kept one.
            premul = (np.dstack([colour * alpha[..., None], alpha[..., None] * 255]))[::4, ::4]
            last = segment.get('_last')
            if last is not None and entry != segment['use'][-1]:
                region = (premul[..., 3] > 12) | (last[..., 3] > 12)
                if region.any() and np.abs(premul - last)[region].mean() < KEEP_CHANGE:
                    continue
            segment['_last'] = premul
            sprites.append({'segment': segment['id'], 'clipFrame': index, 'shift': [round(float(v), 2) for v in shift], 'world': [round(v, 3) for v in world], 'pixels': sprite})
    # Shelf-pack into 4096-wide atlases.
    atlases, frames, page, x, y, shelf = [], [], None, 0, 0, 0
    def new_page():
        return np.zeros((4096, 4096, 4), np.uint8)
    page = new_page()
    for s in sprites:
        h, w = s['pixels'].shape[:2]
        if x + w > 4096: x, y, shelf = 0, y + shelf + 2, 0
        if y + h > 4096:
            atlases.append(page); page = new_page(); x, y, shelf = 0, 0, 0
        page[y:y + h, x:x + w] = s['pixels']
        frames.append({'segment': s['segment'], 'clipFrame': s['clipFrame'], 'atlas': len(atlases), 'rect': [x, y, w, h], 'world': s['world'], 'shift': s['shift']})
        x += w + 2; shelf = max(shelf, h)
    used = y + shelf
    atlases.append(page[:max(1, used)] if len(atlases) == 0 else page)
    names = []
    for i, a in enumerate(atlases):
        name = f'atlas-{i}.webp'; names.append(name)
        Image.fromarray(a, 'RGBA').save(os.path.join(out_dir, name), 'WEBP', quality=92, alpha_quality=100, method=6)
    manifest = {'version': 1, 'spriteScale': SPRITE_SCALE, 'keepChange': KEEP_CHANGE, 'atlases': names, 'frames': frames, 'segments': [{k: v for k, v in s.items() if k in ('id', 'fps', 'warpRenderToClip', 'shiftOutliers', 'occludedFrames')} for s in spec['segments']]}
    json.dump(manifest, open(os.path.join(out_dir, 'manifest.json'), 'w'), indent=1)
    print(json.dumps({'sprites': len(frames), 'atlases': [(n, os.path.getsize(os.path.join(out_dir, n))) for n in names], 'pages': [a.shape[:2] for a in atlases]}))

if __name__ == '__main__':
    main(sys.argv[1])
