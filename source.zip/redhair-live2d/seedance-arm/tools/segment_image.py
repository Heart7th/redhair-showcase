"""Segment one object in a still image with SAM 2.1 (points in pixel coordinates)."""
import sys, json
import numpy as np, cv2, torch
from sam2.build_sam import build_sam2
from sam2.sam2_image_predictor import SAM2ImagePredictor
image_path, out_path, ckpt, prompts = sys.argv[1], sys.argv[2], sys.argv[3], json.loads(sys.argv[4])
import os
device = torch.device(os.environ.get('SAM_DEVICE') or ('mps' if torch.backends.mps.is_available() else 'cpu'))
predictor = SAM2ImagePredictor(build_sam2('configs/sam2.1/sam2.1_hiera_b+.yaml', ckpt, device=device))
img = cv2.cvtColor(cv2.imread(image_path), cv2.COLOR_BGR2RGB)
with torch.inference_mode():
    predictor.set_image(img)
    pts = np.array(prompts['positive'] + prompts['negative'], np.float32)
    lbl = np.array([1] * len(prompts['positive']) + [0] * len(prompts['negative']), np.int32)
    masks, scores, logits = predictor.predict(point_coords=pts, point_labels=lbl, multimask_output=False, return_logits=True)
prob = 1 / (1 + np.exp(-masks[0]))
cv2.imwrite(out_path, np.clip(prob * 255 + .5, 0, 255).astype(np.uint8))
print(json.dumps({'score': float(scores[0]), 'area': int((prob > .5).sum())}))
