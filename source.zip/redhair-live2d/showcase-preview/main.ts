import { PerformanceWorkbench } from './workbench'
import { performanceApi } from './api'
async function start() {
  const source = await fetch('/project/body-rig/rig-source-body.json').then(r => r.json())
  const config = await fetch('/project/shoulder-assets/arm-keyforms.json').then(r => r.json())
  const app = await new PerformanceWorkbench(source, '/project/preview/export/atlas.png', config, name => '/project/shoulder-assets/' + name).init()
  app.setPose('demo'); app.setView('full'); app.setExpression('neutral')
  const api = performanceApi(app)
  Object.assign(window, { performancePreview: api, raisePreview: api })
}
start().catch(e => { document.querySelector('#status')!.textContent = `动作表情预览未能加载：${e?.message || e}`; throw e })
