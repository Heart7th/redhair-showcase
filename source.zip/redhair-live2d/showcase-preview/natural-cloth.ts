import type { Joints, Point, ShoulderRoot } from './arm-skin'

export type SleevePoseDescriptor = {
  id: string; progress: number; sleeveImage: string
  sourceJoints: { shoulder: [number, number]; elbow: [number, number]; wrist: [number, number] }
  sourceRoot?: { outer: [number, number]; inner: [number, number] }
}
export type ClothGeometry = { positions: number[]; firstUV: number[]; secondUV: number[]; indices: number[]; coverage?: number[] }
type Vertex = { point: Point; fore: number }
type WidthProfile = { negative: number; positive: number }[]
export type NaturalCloth = { descriptor: SleevePoseDescriptor; texture: WebGLTexture; vertices: Vertex[]; indices: number[]; upper: WidthProfile; fore: WidthProfile }
const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x))
const ease = (x: number) => { const t = clamp(x); return t * t * (3 - 2 * t) }
const handoverWindows: Record<string, [number, number]> = {
  'down:half': [.055, .195], 'half:chest': [.305, .445],
  'chest:roll': [.515, .620], 'roll:head': [.710, .870],
}
// A gesture has both joint travel and painted-fold travel. Limiting this
// coordinate keeps buttons and slider catches from racing through a handover.
function sleeveTravel(progress: number) {
  const p = clamp(progress)
  return p / .8 + Object.values(handoverWindows).reduce((total, [a, b]) => total + ease((p - a) / (b - a)) / 3.5, 0)
}
export function limitSleeveProgress(from: number, proposed: number, seconds: number) {
  const start = sleeveTravel(from), end = sleeveTravel(proposed), budget = Math.max(0, seconds)
  if (Math.abs(end - start) <= budget) return clamp(proposed)
  const target = start + Math.sign(end - start) * budget
  let low = 0, high = 1
  for (let i = 0; i < 28; i++) { const middle = (low + high) / 2; if (sleeveTravel(middle) < target) low = middle; else high = middle }
  return (low + high) / 2
}
const point = (p: [number, number]): Point => ({ x: p[0], y: p[1] })
const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y)
function segmentDistance(p: Point, a: Point, b: Point) {
  const dx = b.x - a.x, dy = b.y - a.y, t = clamp(((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy))
  return Math.hypot(p.x - a.x - dx * t, p.y - a.y - dy * t)
}
export function createNaturalCloth(descriptor: SleevePoseDescriptor, texture: WebGLTexture, rgba: Uint8ClampedArray, width: number, height: number): NaturalCloth {
  let x0 = width, y0 = height, x1 = 0, y1 = 0
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) if (rgba[(y * width + x) * 4 + 3]! > 8) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y) }
  x0 = Math.max(0, x0 - 8); y0 = Math.max(0, y0 - 8); x1 = Math.min(width, x1 + 8); y1 = Math.min(height, y1 + 8)
  const columns = Math.ceil((x1 - x0) / 9), rows = Math.ceil((y1 - y0) / 9), vertices: Vertex[] = [], faces: { ids: number[]; fore: number }[] = []
  const j = descriptor.sourceJoints, s = point(j.shoulder), e = point(j.elbow), w = point(j.wrist)
  const profile = (a: Point, b: Point): WidthProfile => {
    const length = distance(a, b), nx = -(b.y - a.y) / length, ny = (b.x - a.x) / length
    const values = Array.from({ length: 25 }, (_, i) => {
      const t = i / 24, cx = a.x + (b.x - a.x) * t, cy = a.y + (b.y - a.y) * t, runs: [number, number][] = []
      let begin: number | null = null
      for (let q = -160; q <= 160; q++) {
        const x = Math.round(cx + nx * q), y = Math.round(cy + ny * q), alpha = x >= 0 && x < width && y >= 0 && y < height ? rgba[(y * width + x) * 4 + 3]! : 0
        if (alpha > 80 && begin === null) begin = q
        if ((alpha <= 80 || q === 160) && begin !== null) { runs.push([begin, q - 1]); begin = null }
      }
      runs.sort((x, y) => Math.max(0, x[0], -x[1]) - Math.max(0, y[0], -y[1]))
      const run = runs[0] ?? [-28, 28]
      return { negative: Math.max(16, -run[0]), positive: Math.max(16, run[1]) }
    })
    return values.map((v, i) => ({ negative: (values[Math.max(0, i - 1)]!.negative + 2 * v.negative + values[Math.min(24, i + 1)]!.negative) / 4, positive: (values[Math.max(0, i - 1)]!.positive + 2 * v.positive + values[Math.min(24, i + 1)]!.positive) / 4 }))
  }
  for (let row = 0; row <= rows; row++) for (let col = 0; col <= columns; col++) {
    const p = { x: x0 + (x1 - x0) * col / columns, y: y0 + (y1 - y0) * row / rows }
    const upperDistance = segmentDistance(p, s, e), foreDistance = segmentDistance(p, e, w)
    const projection = ((p.x - e.x) * (w.x - e.x) + (p.y - e.y) * (w.y - e.y)) / ((w.x - e.x) ** 2 + (w.y - e.y) ** 2)
    const capsule = projection >= 0 && projection <= 1.1 ? 1 - ease((foreDistance - 29) / 15) : 0
    const fore = Math.max(ease((upperDistance - foreDistance + 15) / 30), capsule)
    vertices.push({ point: p, fore })
  }
  for (let row = 0; row < rows; row++) for (let col = 0; col < columns; col++) {
    const q = row * (columns + 1) + col
    for (const ids of [[q, q + 1, q + columns + 1], [q + 1, q + columns + 2, q + columns + 1]]) faces.push({ ids, fore: ids.reduce((a, id) => a + vertices[id]!.fore, 0) / 3 })
  }
  // When the native painting folds over itself after a small deformation,
  // its foreground forearm is drawn last; no cross-product side swapping.
  faces.sort((a, b) => a.fore - b.fore)
  return { descriptor, texture, vertices, indices: faces.flatMap(f => f.ids), upper: profile(s, e), fore: profile(e, w) }
}
function profileWidth(profile: WidthProfile, along: number, normal: number) {
  const t = clamp(along) * 24, i = Math.floor(t), k = Math.min(24, i + 1), side = normal < 0 ? 'negative' : 'positive'
  return profile[i]![side] + (profile[k]![side] - profile[i]![side]) * (t - i)
}
function transform(p: Point, a: Point, b: Point, ta: Point, tb: Point, own?: WidthProfile, other?: WidthProfile, blend = 0): Point {
  const dx = b.x - a.x, dy = b.y - a.y, length = Math.hypot(dx, dy), tx = tb.x - ta.x, ty = tb.y - ta.y, targetLength = Math.hypot(tx, ty)
  const along = ((p.x - a.x) * dx + (p.y - a.y) * dy) / (length * length), normal = ((p.y - a.y) * dx - (p.x - a.x) * dy) / length
  const ownWidth = own ? profileWidth(own, along, normal) : 1, otherWidth = other ? profileWidth(other, along, normal) : ownWidth
  const ratio = 1 + (otherWidth / ownWidth - 1) * blend, n = normal * clamp(ratio, .55, 1.8)
  return { x: ta.x + tx * along - ty / targetLength * n, y: ta.y + ty * along + tx / targetLength * n }
}
export function naturalClothGeometry(cloth: NaturalCloth, target: Joints, root?: ShoulderRoot, registration?: { other: NaturalCloth; blend: number }): ClothGeometry {
  const j = cloth.descriptor.sourceJoints, s = point(j.shoulder), e = point(j.elbow), w = point(j.wrist)
  const skin = (p: Point, fore: number) => {
    const a = transform(p, s, e, target.shoulder, target.elbow, cloth.upper, registration?.other.upper, registration?.blend), b = transform(p, e, w, target.elbow, target.wrist, cloth.fore, registration?.other.fore, registration?.blend)
    return { x: a.x + (b.x - a.x) * fore, y: a.y + (b.y - a.y) * fore }
  }
  const anchors = cloth.descriptor.sourceRoot, sourceOuter = anchors ? point(anchors.outer) : s, sourceInner = anchors ? point(anchors.inner) : s
  const bridgeShoulder = cloth.descriptor.id === 'half' || cloth.descriptor.id === 'roll', radius = bridgeShoulder ? 34 : 60
  const delta = (p: Point, t: Point) => { const a = skin(p, 0), dx = t.x - a.x, dy = t.y - a.y, limit = bridgeShoulder ? 28 : 65, scale = Math.min(1, limit / Math.max(1, Math.hypot(dx, dy))); return { x: dx * scale, y: dy * scale } }
  const outerDelta = root && anchors ? delta(sourceOuter, root.outer) : { x: 0, y: 0 }, innerDelta = root && anchors ? delta(sourceInner, root.inner) : { x: 0, y: 0 }
  const g: ClothGeometry = { positions: [], firstUV: [], secondUV: [], indices: cloth.indices, coverage: [] }
  const mx = sourceInner.x - sourceOuter.x, my = sourceInner.y - sourceOuter.y, mouthLength = Math.max(1, Math.hypot(mx, my)), inwardSign = (-my * (e.x - s.x) + mx * (e.y - s.y)) >= 0 ? 1 : -1
  for (const vertex of cloth.vertices) {
    const p = skin(vertex.point, vertex.fore)
    // Pin only the rear shoulder fabric. In the roll key the short shoulder
    // mouth must not stretch the foreground forearm or its painted cuff.
    if (root && anchors) {
      const rear = (1 - vertex.fore) ** 3, a = Math.exp(-((distance(vertex.point, sourceOuter) / radius) ** 2)) * rear, b = Math.exp(-((distance(vertex.point, sourceInner) / radius) ** 2)) * rear
      p.x += outerDelta.x * a + innerDelta.x * b; p.y += outerDelta.y * a + innerDelta.y * b
    }
    g.positions.push(p.x, p.y); g.firstUV.push(vertex.point.x, vertex.point.y); g.secondUV.push(vertex.point.x, vertex.point.y)
    const inside = ((vertex.point.x - sourceOuter.x) * -my + (vertex.point.y - sourceOuter.y) * mx) / mouthLength * inwardSign
    g.coverage!.push(bridgeShoulder ? vertex.fore + (1 - vertex.fore) * ease((inside - 3) / 16) : 1)
  }
  return g
}
export function naturalRootBridge(cloth: NaturalCloth, target: Joints, root?: ShoulderRoot): ClothGeometry | null {
  const anchors = cloth.descriptor.sourceRoot
  if (!anchors || !root || !['half', 'roll'].includes(cloth.descriptor.id)) return null
  const source = cloth.descriptor.sourceJoints, s = point(source.shoulder), e = point(source.elbow), outer = point(anchors.outer), inner = point(anchors.inner)
  const direction = { x: (e.x - s.x) / distance(s, e), y: (e.y - s.y) / distance(s, e) }, insetOuter = { x: outer.x + direction.x * 28, y: outer.y + direction.y * 28 }, insetInner = { x: inner.x + direction.x * 28, y: inner.y + direction.y * 28 }
  const endOuter = transform(insetOuter, s, e, target.shoulder, target.elbow), endInner = transform(insetInner, s, e, target.shoulder, target.elbow)
  const dx = e.x - s.x, dy = e.y - s.y, length = Math.hypot(dx, dy), g: ClothGeometry = { positions: [], firstUV: [], secondUV: [], indices: [] }
  const columns = 10, rows = 8
  for (let row = 0; row <= rows; row++) for (let col = 0; col <= columns; col++) {
    const u = row / rows, v = col / columns, t = ease(u), start = { x: root.outer.x + (root.inner.x - root.outer.x) * v, y: root.outer.y + (root.inner.y - root.outer.y) * v }, end = { x: endOuter.x + (endInner.x - endOuter.x) * v, y: endOuter.y + (endInner.y - endOuter.y) * v }
    const p = { x: start.x + (end.x - start.x) * t + Math.sin(Math.PI * u) * 9, y: start.y + (end.y - start.y) * t }
    const uv = { x: outer.x + (inner.x - outer.x) * v + dx / length * (28 + 12 * u), y: outer.y + (inner.y - outer.y) * v + dy / length * (28 + 12 * u) }
    g.positions.push(p.x, p.y); g.firstUV.push(uv.x, uv.y); g.secondUV.push(uv.x, uv.y)
    if (row < rows && col < columns) { const q = row * (columns + 1) + col; g.indices.push(q, q + 1, q + columns + 1, q + 1, q + columns + 2, q + columns + 1) }
  }
  return g
}
export function selectSleevePoses(poses: NaturalCloth[], progress: number) {
  let current = poses[0]!
  for (let i = 0; i < poses.length - 1; i++) {
    const a = poses[i]!, b = poses[i + 1]!
    // Give the painted folds time to change, while keeping the chest hold
    // and the foreshortened elbow key as unmixed authored poses.
    const fallback = (a.descriptor.progress + b.descriptor.progress) / 2
    const [start, end] = handoverWindows[a.descriptor.id + ':' + b.descriptor.id] ?? [fallback - .06, fallback + .06]
    if (progress < start) return { first: current, second: current, blend: 0 }
    if (progress <= end) return { first: a, second: b, blend: ease((progress - start) / (end - start)) }
    current = b
  }
  return { first: current, second: current, blend: 0 }
}
export function registeredClothMixGeometry(first: Uint8Array, second: Uint8Array, maskWidth: number, maskHeight: number, width: number, height: number, imageWidth: number, imageHeight: number, offset: [number, number], blend: number, wristY?: number): ClothGeometry {
  const outline = (rgba: Uint8Array) => {
    const rows: { left: number; right: number }[] = [], valid: number[] = [], maxima: number[] = []
    const alpha = (x: number, y: number) => x < 0 || x >= maskWidth || y < 0 || y >= maskHeight ? 0 : rgba[((maskHeight - y - 1) * maskWidth + x) * 4 + 3]!
    for (let y = 0; y < maskHeight; y++) {
      let left = maskWidth, right = -1
      let maximum = 0
      for (let x = 0; x < maskWidth; x++) { const a = alpha(x, y); maximum = Math.max(maximum, a); if (a > 24) { left = Math.min(left, x); right = Math.max(right, x) } }
      maxima.push(maximum)
      const l = left - 1 + clamp((24 - alpha(left - 1, y)) / Math.max(1, alpha(left, y) - alpha(left - 1, y))), r = right + clamp((alpha(right, y) - 24) / Math.max(1, alpha(right, y) - alpha(right + 1, y)))
      rows.push({ left: Math.max(0, l - .6), right: Math.min(maskWidth, r + .6) }); if (right >= left) valid.push(y)
    }
    const top = valid[0] ?? 0, bottom = valid.at(-1) ?? maskHeight - 1
    for (let y = 0; y < maskHeight; y++) if (y < top || y > bottom || rows[y]!.right <= rows[y]!.left) { const nearest = valid.reduce((a, b) => Math.abs(b - y) < Math.abs(a - y) ? b : a, valid[0] ?? 0); rows[y] = rows[nearest]! }
    const smoothed = rows.map((_, y) => { let left = 0, right = 0, total = 0; for (let k = -2; k <= 2; k++) { const weight = 3 - Math.abs(k), r = rows[Math.max(0, Math.min(maskHeight - 1, y + k))]!; left += r.left * weight; right += r.right * weight; total += weight } return { left: left / total, right: right / total } })
    return { rows: smoothed, top: Math.max(0, top - 1 + clamp((24 - (maxima[top - 1] ?? 0)) / Math.max(1, maxima[top]! - (maxima[top - 1] ?? 0)))), bottom: Math.min(maskHeight - 1, bottom + clamp((maxima[bottom]! - 24) / Math.max(1, maxima[bottom]! - (maxima[bottom + 1] ?? 0)))) }
  }
  const a = outline(first), b = outline(second), g: ClothGeometry = { positions: [], firstUV: [], secondUV: [], indices: [] }, rowCount = maskHeight
  const commonTop = a.top + (b.top - a.top) * blend, commonBottom = a.bottom + (b.bottom - a.bottom) * blend, anchor = wristY === undefined ? undefined : wristY / height * maskHeight - .5
  const sourceY = (y: number, top: number, bottom: number) => {
    const whole = top + (y - commonTop) / Math.max(1, commonBottom - commonTop) * (bottom - top)
    if (anchor === undefined) return whole
    // Ease in wrist anchoring as the cuff enters the crop. A boolean switch
    // here used to move the whole painted sleeve in a single frame.
    const room = Math.min(anchor - Math.max(a.top, b.top), Math.min(a.bottom, b.bottom) - anchor)
    const pin = ease((room - 1) / 4)
    if (pin === 0) return whole
    const pinned = y < anchor ? top + (y - commonTop) / (anchor - commonTop) * (anchor - top) : anchor + (y - anchor) / (commonBottom - anchor) * (bottom - anchor)
    return whole + (pinned - whole) * pin
  }
  for (let row = 0; row <= rowCount; row++) {
    const t = row / rowCount, y = commonTop + (commonBottom - commonTop) * t, ay = sourceY(y, a.top, a.bottom), by = sourceY(y, b.top, b.bottom)
    const at = (rows: { left: number; right: number }[], y: number) => { const low = Math.floor(y), high = Math.min(maskHeight - 1, low + 1), t = y - low; return { left: rows[low]!.left + (rows[high]!.left - rows[low]!.left) * t, right: rows[low]!.right + (rows[high]!.right - rows[low]!.right) * t } }
    const ar = at(a.rows, ay), br = at(b.rows, by)
    for (let side = 0; side < 2; side++) {
      const ax = side ? ar.right : ar.left, bx = side ? br.right : br.left, x = ax + (bx - ax) * blend
      g.positions.push(x / maskWidth * width - offset[0], (y + .5) / maskHeight * height - offset[1])
      g.firstUV.push(ax / maskWidth * imageWidth, (1 - (ay + .5) / maskHeight) * imageHeight)
      g.secondUV.push(bx / maskWidth * imageWidth, (1 - (by + .5) / maskHeight) * imageHeight)
    }
    if (row < rowCount) { const q = row * 2; g.indices.push(q, q + 1, q + 2, q + 1, q + 3, q + 2) }
  }
  return g
}
