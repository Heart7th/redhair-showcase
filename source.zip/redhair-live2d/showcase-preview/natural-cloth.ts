import type { Joints, Point, ShoulderRoot } from './arm-skin'

export type SleevePoseDescriptor = {
  id: string; progress: number; sleeveImage: string
  sourceJoints: { shoulder: [number, number]; elbow: [number, number]; wrist: [number, number] }
  sourceRoot?: { outer: [number, number]; inner: [number, number] }
}
export type ClothGeometry = { positions: number[]; firstUV: number[]; secondUV: number[]; indices: number[]; coverage?: number[] }
type Vertex = { point: Point; fore: number }
type WidthProfile = { negative: number; positive: number }[]
export type NaturalCloth = { descriptor: SleevePoseDescriptor; texture: WebGLTexture; vertices: Vertex[]; indices: number[]; upper: WidthProfile; fore: WidthProfile }
const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x))
const ease = (x: number) => { const t = clamp(x); return t * t * (3 - 2 * t) }
const handoverWindows: Record<string, [number, number]> = {
  'down:half': [.055, .195], 'half:chest': [.305, .445],
  'chest:roll': [.515, .620], 'roll:head': [.710, .870],
}
// A gesture has both joint travel and painted-fold travel. Limiting this
// coordinate keeps buttons and slider catches from racing through a handover.
function sleeveTravel(progress: number) {
  const p = clamp(progress)
  return p / .8 + Object.values(handoverWindows).reduce((total, [a, b]) => total + ease((p - a) / (b - a)) / 3.5, 0)
}
export function limitSleeveProgress(from: number, proposed: number, seconds: number) {
  const start = sleeveTravel(from), end = sleeveTravel(proposed), budget = Math.max(0, seconds)
  if (Math.abs(end - start) <= budget) return clamp(proposed)
  const target = start + Math.sign(end - start) * budget
  let low = 0, high = 1
  for (let i = 0; i < 28; i++) { const middle = (low + high) / 2; if (sleeveTravel(middle) < target) low = middle; else high = middle }
  return (low + high) / 2
}
const point = (p: [number, number]): Point => ({ x: p[0], y: p[1] })
const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y)
function segmentDistance(p: Point, a: Point, b: Point) {
  const dx = b.x - a.x, dy = b.y - a.y, t = clamp(((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy))
  return Math.hypot(p.x - a.x - dx * t, p.y - a.y - dy * t)
}
export function createNaturalCloth(descriptor: SleevePoseDescriptor, texture: WebGLTexture, rgba: Uint8ClampedArray, width: number, height: number): NaturalCloth {
  let x0 = width, y0 = height, x1 = 0, y1 = 0
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) if (rgba[(y * width + x) * 4 + 3]! > 8) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y) }
  x0 = Math.max(0, x0 - 8); y0 = Math.max(0, y0 - 8); x1 = Math.min(width, x1 + 8); y1 = Math.min(height, y1 + 8)
  const columns = Math.ceil((x1 - x0) / 9), rows = Math.ceil((y1 - y0) / 9), vertices: Vertex[] = [], faces: { ids: number[]; fore: number }[] = []
  const j = descriptor.sourceJoints, s = point(j.shoulder), e = point(j.elbow), w = point(j.wrist)
  const profile = (a: Point, b: Point): WidthProfile => {
    const length = distance(a, b), nx = -(b.y - a.y) / length, ny = (b.x - a.x) / length
    const values = Array.from({ length: 25 }, (_, i) => {
      const t = i / 24, cx = a.x + (b.x - a.x) * t, cy = a.y + (b.y - a.y) * t, runs: [number, number][] = []
      let begin: number | null = null
      for (let q = -160; q <= 160; q++) {
        const x = Math.round(cx + nx * q), y = Math.round(cy + ny * q), alpha = x >= 0 && x < width && y >= 0 && y < height ? rgba[(y * width + x) * 4 + 3]! : 0
        if (alpha > 80 && begin === null) begin = q
        if ((alpha <= 80 || q === 160) && begin !== null) { runs.push([begin, q - 1]); begin = null }
      }
      runs.sort((x, y) => Math.max(0, x[0], -x[1]) - Math.max(0, y[0], -y[1]))
      const run = runs[0] ?? [-28, 28]
      return { negative: Math.max(16, -run[0]), positive: Math.max(16, run[1]) }
    })
    return values.map((v, i) => ({ negative: (values[Math.max(0, i - 1)]!.negative + 2 * v.negative + values[Math.min(24, i + 1)]!.negative) / 4, positive: (values[Math.max(0, i - 1)]!.positive + 2 * v.positive + values[Math.min(24, i + 1)]!.positive) / 4 }))
  }
  for (let row = 0; row <= rows; row++) for (let col = 0; col <= columns; col++) {
    const p = { x: x0 + (x1 - x0) * col / columns, y: y0 + (y1 - y0) * row / rows }
    const upperDistance = segmentDistance(p, s, e), foreDistance = segmentDistance(p, e, w)
    const projection = ((p.x - e.x) * (w.x - e.x) + (p.y - e.y) * (w.y - e.y)) / ((w.x - e.x) ** 2 + (w.y - e.y) ** 2)
    const capsule = projection >= 0 && projection <= 1.1 ? 1 - ease((foreDistance - 29) / 15) : 0
    let fore = Math.max(ease((upperDistance - foreDistance + 15) / 30), capsule)
    // An open shoulder rim is not a foreground forearm, even when the bent
    // arm happens to put its other bone nearer in this single source view.
    const root = descriptor.sourceRoot
    if (root) { const mouth = segmentDistance(p, point(root.outer), point(root.inner)), lip = (1 - ease((mouth - 8) / 42)) * ease((foreDistance - 36) / 24) * ease((distance(p, w) - 55) / 25); fore *= 1 - lip }
    vertices.push({ point: p, fore })
  }
  for (let row = 0; row < rows; row++) for (let col = 0; col < columns; col++) {
    const q = row * (columns + 1) + col
    for (const ids of [[q, q + 1, q + columns + 1], [q + 1, q + columns + 2, q + columns + 1]]) faces.push({ ids, fore: ids.reduce((a, id) => a + vertices[id]!.fore, 0) / 3 })
  }
  // When the native painting folds over itself after a small deformation,
  // its foreground forearm is drawn last; no cross-product side swapping.
  faces.sort((a, b) => a.fore - b.fore)
  return { descriptor, texture, vertices, indices: faces.flatMap(f => f.ids), upper: profile(s, e), fore: profile(e, w) }
}
function profileWidth(profile: WidthProfile, along: number, normal: number) {
  const t = clamp(along) * 24, i = Math.floor(t), k = Math.min(24, i + 1), side = normal < 0 ? 'negative' : 'positive'
  return profile[i]![side] + (profile[k]![side] - profile[i]![side]) * (t - i)
}
function transform(p: Point, a: Point, b: Point, ta: Point, tb: Point, own?: WidthProfile, other?: WidthProfile, blend = 0, shoulder?: WidthProfile): Point {
  const dx = b.x - a.x, dy = b.y - a.y, length = Math.hypot(dx, dy), tx = tb.x - ta.x, ty = tb.y - ta.y, targetLength = Math.hypot(tx, ty)
  const along = ((p.x - a.x) * dx + (p.y - a.y) * dy) / (length * length), normal = ((p.y - a.y) * dx - (p.x - a.x) * dy) / length
  const ownWidth = own ? profileWidth(own, along, normal) : 1, otherWidth = other ? profileWidth(other, along, normal) : ownWidth
  let targetWidth = ownWidth + (otherWidth - ownWidth) * blend
  // Every upper sleeve meets the same shoulder piece. Keep its width stable
  // throughout the overlap, then release the individual drawing near the elbow.
  if (shoulder) { const shared = profileWidth(shoulder, along, normal), release = ease((along - .65) / .45); targetWidth = shared + (targetWidth - shared) * release }
  const ratio = targetWidth / ownWidth, n = normal * clamp(ratio, .55, 1.8)
  return { x: ta.x + tx * along - ty / targetLength * n, y: ta.y + ty * along + tx / targetLength * n }
}
/** The down drawing retains its complete alpha edge; no UV quadrilateral cuts the cap. */
export function naturalShoulderCapGeometry(cloth: NaturalCloth, target: Joints, root?: ShoulderRoot): (ClothGeometry & { pinError: number }) | null {
  const anchors = cloth.descriptor.sourceRoot
  if (!anchors || !root) return null
  const source = cloth.descriptor.sourceJoints, s = point(source.shoulder), e = point(source.elbow), dx = e.x - s.x, dy = e.y - s.y, square = dx * dx + dy * dy
  const g = naturalClothGeometry(cloth, target, root)
  g.coverage = cloth.vertices.map(vertex => { const along = ((vertex.point.x - s.x) * dx + (vertex.point.y - s.y) * dy) / square; return 1 - ease((along - .55) / .25) })
  // Sample a small seam allowance along and across the outer armhole.
  // This supplies a small seam allowance beneath the hood without moving
  // either root pin or changing the rest of the original alpha contour.
  const length = Math.sqrt(square), outer = point(anchors.outer)
  for (let i = 0; i < cloth.vertices.length; i++) {
    const allowance = 8 * (1 - ease((distance(cloth.vertices[i]!.point, outer) - 18) / 52))
    g.firstUV[i * 2]! += (dx - dy) / length * allowance; g.firstUV[i * 2 + 1]! += (dy + dx) / length * allowance
    g.secondUV[i * 2] = g.firstUV[i * 2]!; g.secondUV[i * 2 + 1] = g.firstUV[i * 2 + 1]!
  }
  g.indices = cloth.indices.filter((_, index) => { const triangle = Math.floor(index / 3) * 3; return cloth.indices.slice(triangle, triangle + 3).some(vertex => g.coverage![vertex]! > .001) })
  // A narrow, opaque underlap meets the torso seam before the sleeve is drawn.
  // It uses original fabric pixels and the same two torso pins at every pose.
  const so = point(anchors.outer), si = point(anchors.inner), rx = root.inner.x - root.outer.x, ry = root.inner.y - root.outer.y, rl = Math.max(1, Math.hypot(rx, ry)), sx = si.x - so.x, sy = si.y - so.y, sl = Math.max(1, Math.hypot(sx, sy))
  const base = g.positions.length / 2, rows = 24, columns = 4
  for (let row = 0; row <= rows; row++) for (let col = 0; col <= columns; col++) {
    const t = -.05 + row / rows * 1.1, v = col / columns, width = 8 + 20 * (1 - ease(t / .22))
    g.positions.push(root.outer.x + rx * t + ry / rl * width * v, root.outer.y + ry * t - rx / rl * width * v)
    const u = clamp(t), x = so.x + sx * u + sy / sl * (10 + 12 * v), y = so.y + sy * u - sx / sl * (10 + 12 * v)
    g.firstUV.push(x, y); g.secondUV.push(x, y)
    g.coverage!.push(ease((t + .05) / .05) * (1 - ease((t - .97) / .08)) * (1 - ease((v - .85) / .15)))
    if (row < rows && col < columns) { const q = base + row * (columns + 1) + col; g.indices.push(q, q + 1, q + columns + 1, q + 1, q + columns + 2, q + columns + 1) }
  }
  const pins = naturalClothGeometry({ ...cloth, vertices: [{ point: point(anchors.outer), fore: 0 }, { point: point(anchors.inner), fore: 0 }], indices: [] }, target, root)
  const pinError = Math.max(Math.hypot(pins.positions[0]! - root.outer.x, pins.positions[1]! - root.outer.y), Math.hypot(pins.positions[2]! - root.inner.x, pins.positions[3]! - root.inner.y))
  return { ...g, pinError }
}
export function naturalClothGeometry(cloth: NaturalCloth, target: Joints, root?: ShoulderRoot, registration?: { other: NaturalCloth; blend: number }, shoulder?: NaturalCloth): ClothGeometry {
  const j = cloth.descriptor.sourceJoints, s = point(j.shoulder), e = point(j.elbow), w = point(j.wrist)
  const skin = (p: Point, fore: number) => {
    const a = transform(p, s, e, target.shoulder, target.elbow, cloth.upper, registration?.other.upper, registration?.blend, shoulder?.upper), b = transform(p, e, w, target.elbow, target.wrist, cloth.fore, registration?.other.fore, registration?.blend)
    return { x: a.x + (b.x - a.x) * fore, y: a.y + (b.y - a.y) * fore }
  }
  const anchors = cloth.descriptor.sourceRoot, sourceOuter = anchors ? point(anchors.outer) : s, sourceInner = anchors ? point(anchors.inner) : s
  const radius = Math.max(60, distance(sourceOuter, sourceInner) * .7)
  const delta = (p: Point, t: Point) => { const a = skin(p, 0); return { x: t.x - a.x, y: t.y - a.y } }
  const outerDelta = root && anchors ? delta(sourceOuter, root.outer) : { x: 0, y: 0 }, innerDelta = root && anchors ? delta(sourceInner, root.inner) : { x: 0, y: 0 }
  const g: ClothGeometry = { positions: [], firstUV: [], secondUV: [], indices: cloth.indices, coverage: [] }
  const coupling = Math.exp(-((distance(sourceOuter, sourceInner) / radius) ** 2)), normalization = Math.max(.001, 1 - coupling * coupling)
  for (const vertex of cloth.vertices) {
    const p = skin(vertex.point, vertex.fore)
    // Cardinal weights give exact, independent constraints at both ends of
    // the armhole. Foreground forearm and cuff remain outside this correction.
    if (root && anchors) {
      const along = ((vertex.point.x - s.x) * (e.x - s.x) + (vertex.point.y - s.y) * (e.y - s.y)) / ((e.x - s.x) ** 2 + (e.y - s.y) ** 2), rear = (1 - vertex.fore) ** 3 * (1 - ease((along - .4) / .5))
      const ga = Math.exp(-((distance(vertex.point, sourceOuter) / radius) ** 2)), gb = Math.exp(-((distance(vertex.point, sourceInner) / radius) ** 2)), a = (ga - coupling * gb) / normalization * rear, b = (gb - coupling * ga) / normalization * rear
      p.x += outerDelta.x * a + innerDelta.x * b; p.y += outerDelta.y * a + innerDelta.y * b
    }
    g.positions.push(p.x, p.y); g.firstUV.push(vertex.point.x, vertex.point.y); g.secondUV.push(vertex.point.x, vertex.point.y)
    // All poses share one armhole. Their open source mouths are hidden beneath
    // it; only lower sleeve cloth and the foreground forearm enter the blend.
    const tx = target.elbow.x - target.shoulder.x, ty = target.elbow.y - target.shoulder.y, along = ((p.x - target.shoulder.x) * tx + (p.y - target.shoulder.y) * ty) / (tx * tx + ty * ty)
    const armhole = root ? ease(segmentDistance(p, root.outer, root.inner) / 12) : 1
    let coverage = shoulder && root ? vertex.fore + (1 - vertex.fore) * ease(along / .3) * armhole : 1
    if (cloth.descriptor.id === 'roll' && anchors) {
      const mouth = segmentDistance(vertex.point, sourceOuter, sourceInner), foreDistance = segmentDistance(vertex.point, e, w)
      const openLip = (1 - ease((mouth - 12) / 45)) * ease((foreDistance - 30) / 20) * ease((distance(vertex.point, w) - 35) / 20)
      coverage *= 1 - openLip
    }
    g.coverage!.push(coverage)
  }
  return g
}
export function selectSleevePoses(poses: NaturalCloth[], progress: number) {
  let current = poses[0]!
  for (let i = 0; i < poses.length - 1; i++) {
    const a = poses[i]!, b = poses[i + 1]!
    // Give the painted folds time to change, while keeping the chest hold
    // and the foreshortened elbow key as unmixed authored poses.
    const fallback = (a.descriptor.progress + b.descriptor.progress) / 2
    const [start, end] = handoverWindows[a.descriptor.id + ':' + b.descriptor.id] ?? [fallback - .06, fallback + .06]
    if (progress < start) return { first: current, second: current, blend: 0 }
    if (progress <= end) return { first: a, second: b, blend: ease((progress - start) / (end - start)) }
    current = b
  }
  return { first: current, second: current, blend: 0 }
}
export function registeredClothMixGeometry(first: Uint8Array, second: Uint8Array, maskWidth: number, maskHeight: number, width: number, height: number, imageWidth: number, imageHeight: number, offset: [number, number], blend: number, wristY?: number): ClothGeometry {
  const outline = (rgba: Uint8Array) => {
    const rows: { left: number; right: number }[] = [], valid: number[] = [], maxima: number[] = []
    const alpha = (x: number, y: number) => x < 0 || x >= maskWidth || y < 0 || y >= maskHeight ? 0 : rgba[((maskHeight - y - 1) * maskWidth + x) * 4 + 3]!
    for (let y = 0; y < maskHeight; y++) {
      let left = maskWidth, right = -1
      let maximum = 0
      for (let x = 0; x < maskWidth; x++) { const a = alpha(x, y); maximum = Math.max(maximum, a); if (a > 24) { left = Math.min(left, x); right = Math.max(right, x) } }
      maxima.push(maximum)
      const l = left - 1 + clamp((24 - alpha(left - 1, y)) / Math.max(1, alpha(left, y) - alpha(left - 1, y))), r = right + clamp((alpha(right, y) - 24) / Math.max(1, alpha(right, y) - alpha(right + 1, y)))
      rows.push({ left: Math.max(0, l - .6), right: Math.min(maskWidth, r + .6) }); if (right >= left) valid.push(y)
    }
    const top = valid[0] ?? 0, bottom = valid.at(-1) ?? maskHeight - 1
    for (let y = 0; y < maskHeight; y++) if (y < top || y > bottom || rows[y]!.right <= rows[y]!.left) { const nearest = valid.reduce((a, b) => Math.abs(b - y) < Math.abs(a - y) ? b : a, valid[0] ?? 0); rows[y] = rows[nearest]! }
    const smoothed = rows.map((_, y) => { let left = 0, right = 0, total = 0; for (let k = -2; k <= 2; k++) { const weight = 3 - Math.abs(k), r = rows[Math.max(0, Math.min(maskHeight - 1, y + k))]!; left += r.left * weight; right += r.right * weight; total += weight } return { left: left / total, right: right / total } })
    return { rows: smoothed, top: Math.max(0, top - 1 + clamp((24 - (maxima[top - 1] ?? 0)) / Math.max(1, maxima[top]! - (maxima[top - 1] ?? 0)))), bottom: Math.min(maskHeight - 1, bottom + clamp((maxima[bottom]! - 24) / Math.max(1, maxima[bottom]! - (maxima[bottom + 1] ?? 0)))) }
  }
  const a = outline(first), b = outline(second), g: ClothGeometry = { positions: [], firstUV: [], secondUV: [], indices: [] }, rowCount = maskHeight
  const commonTop = a.top + (b.top - a.top) * blend, commonBottom = a.bottom + (b.bottom - a.bottom) * blend, anchor = wristY === undefined ? undefined : wristY / height * maskHeight - .5
  const sourceY = (y: number, top: number, bottom: number) => {
    const whole = top + (y - commonTop) / Math.max(1, commonBottom - commonTop) * (bottom - top)
    if (anchor === undefined) return whole
    // Ease in wrist anchoring as the cuff enters the crop. A boolean switch
    // here used to move the whole painted sleeve in a single frame.
    const room = Math.min(anchor - Math.max(a.top, b.top), Math.min(a.bottom, b.bottom) - anchor)
    const pin = ease((room - 1) / 4)
    if (pin === 0) return whole
    const pinned = y < anchor ? top + (y - commonTop) / (anchor - commonTop) * (anchor - top) : anchor + (y - anchor) / (commonBottom - anchor) * (bottom - anchor)
    return whole + (pinned - whole) * pin
  }
  for (let row = 0; row <= rowCount; row++) {
    const t = row / rowCount, y = commonTop + (commonBottom - commonTop) * t, ay = sourceY(y, a.top, a.bottom), by = sourceY(y, b.top, b.bottom)
    const at = (rows: { left: number; right: number }[], y: number) => { const low = Math.floor(y), high = Math.min(maskHeight - 1, low + 1), t = y - low; return { left: rows[low]!.left + (rows[high]!.left - rows[low]!.left) * t, right: rows[low]!.right + (rows[high]!.right - rows[low]!.right) * t } }
    const ar = at(a.rows, ay), br = at(b.rows, by)
    for (let side = 0; side < 2; side++) {
      const ax = side ? ar.right : ar.left, bx = side ? br.right : br.left, x = ax + (bx - ax) * blend
      g.positions.push(x / maskWidth * width - offset[0], (y + .5) / maskHeight * height - offset[1])
      g.firstUV.push(ax / maskWidth * imageWidth, (1 - (ay + .5) / maskHeight) * imageHeight)
      g.secondUV.push(bx / maskWidth * imageWidth, (1 - (by + .5) / maskHeight) * imageHeight)
    }
    if (row < rowCount) { const q = row * 2; g.indices.push(q, q + 1, q + 2, q + 1, q + 3, q + 2) }
  }
  return g
}
