import type { Anime25DPlayer } from '../vendor/myriad-figure/src/anime25drig/index'
import { jointsFor, type ClothBend, type Joints, type KeyConfig, type Point } from './arm-skin'

type Driver = ReturnType<Anime25DPlayer['getCurrent']>
export type PerformanceSample = {
  progress: number
  arm: Joints
  driver: Partial<Driver>
  phase: 'breathe' | 'prepare' | 'lift' | 'present' | 'greet' | 'lower' | 'settle'
  cycleDuration: number
  boneProgress: { upper: number; fore: number; hand: number }
  clothBend: ClothBend
}

export const PERFORMANCE_DURATION = 16
const TAU = 2 * Math.PI
const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x))
const smooth = (x: number) => { const t = clamp(x); return t * t * t * (t * (t * 6 - 15) + 10) }
const lerp = (a: number, b: number, t: number) => a + (b - a) * t
const vec = (a: Point, angle: number, length: number): Point => ({ x: a.x + Math.cos(angle) * length, y: a.y + Math.sin(angle) * length })

/** Pose timing is deliberately different from the old equal-speed, long-stop loop. */
function phrase(time: number) {
  const t = ((time % PERFORMANCE_DURATION) + PERFORMANCE_DURATION) % PERFORMANCE_DURATION
  if (t < .65) return { progress: 0, phase: 'breathe' as const }
  if (t < 1.15) return { progress: 0, phase: 'prepare' as const }
  if (t < 4.2) return { progress: .5 * smooth((t - 1.15) / 3.05), phase: 'lift' as const }
  if (t < 5.05) return { progress: .5, phase: 'present' as const }
  if (t < 8.35) return { progress: .5 + .5 * smooth((t - 5.05) / 3.3), phase: 'lift' as const }
  if (t < 10.8) return { progress: 1, phase: 'greet' as const }
  if (t < 15.05) return { progress: 1 - smooth((t - 10.8) / 4.25), phase: 'lower' as const }
  return { progress: 0, phase: 'settle' as const }
}

function unwrap(values: number[]) {
  const out = [values[0]!]
  for (let i = 1; i < values.length; i++) {
    let value = values[i]!, previous = out[i - 1]!
    while (value - previous > Math.PI) value -= TAU
    while (value - previous < -Math.PI) value += TAU
    out.push(value)
  }
  return out
}

/** Monotone C1 Hermite interpolation passes every authored pose without a velocity corner. */
function through(values: number[], points: number[], progress: number) {
  if (values.length === 1 || progress <= points[0]!) return values[0]!
  if (progress >= points.at(-1)!) return values.at(-1)!
  const secants = values.slice(1).map((value, i) => (value - values[i]!) / (points[i + 1]! - points[i]!))
  const slopes = values.map((_, i) => {
    if (i === 0) return secants[0]!
    if (i === values.length - 1) return secants.at(-1)!
    const before = secants[i - 1]!, after = secants[i]!
    if (before * after <= 0) return 0
    const h0 = points[i]! - points[i - 1]!, h1 = points[i + 1]! - points[i]!, w0 = 2 * h1 + h0, w1 = h1 + 2 * h0
    return (w0 + w1) / (w0 / before + w1 / after)
  })
  let high = points.findIndex(value => value >= progress); if (high < 1) high = 1
  const low = high - 1, h = points[high]! - points[low]!, t = (progress - points[low]!) / h
  return (2 * t ** 3 - 3 * t * t + 1) * values[low]! + (t ** 3 - 2 * t * t + t) * h * slopes[low]! + (-2 * t ** 3 + 3 * t * t) * values[high]! + (t ** 3 - t * t) * h * slopes[high]!
}

function curve(config: KeyConfig, segment: 'upper' | 'fore' | 'hand', progress: number) {
  const from = segment === 'upper' ? 'shoulder' : segment === 'fore' ? 'elbow' : 'wrist'
  const to = segment === 'upper' ? 'elbow' : segment === 'fore' ? 'wrist' : 'palm'
  const bones = config.keyforms.map(key => { const joints = jointsFor(key), a = joints[from], b = joints[to]; return { angle: Math.atan2(b.y - a.y, b.x - a.x), length: Math.hypot(b.x - a.x, b.y - a.y) } })
  const points = config.keyforms.map(key => key.progress)
  return { angle: through(unwrap(bones.map(b => b.angle)), points, clamp(progress)), length: through(bones.map(b => b.length), points, clamp(progress)) }
}

/**
 * Arm coordinates remain in the 640x1856 source space. The caller attaches them
 * to the animated torso after the player ticks, rather than rotating the whole sprite.
 * Non-demo modes always honour manualProgress; changing buttons cannot teleport the arm.
 */
export function samplePerformance(config: KeyConfig, time: number, mode: string, manualProgress: number): PerformanceSample {
  const clock = Math.max(0, Number.isFinite(time) ? time : 0), demo = mode === 'demo', event = phrase(clock)
  const p = clamp(demo ? event.progress : manualProgress), local = p < .5 ? p * 2 : (p - .5) * 2
  const bubble = Math.sin(Math.PI * local) ** 2
  // Poses at 0, .5 and 1 remain exact; between them the proximal segment leads.
  const upperP = demo ? phrase(clock + .10).progress : clamp(p + .040 * bubble)
  const foreP = demo ? phrase(Math.max(0, clock - .055)).progress : clamp(p - .025 * bubble)
  const handP = demo ? phrase(Math.max(0, clock - .145)).progress : clamp(p - .055 * bubble)
  const upper = curve(config, 'upper', upperP), fore = curve(config, 'fore', foreP), hand = curve(config, 'hand', handP)
  const breath = Math.sin(clock * TAU / 4.5), breathLate = Math.sin(clock * TAU / 4.5 - .5), raised = smooth((p - .12) / .88)
  // A small outward preparatory elbow arc keeps the forearm from scraping straight across the belly.
  upper.angle -= p < .5 ? .22 * bubble : .04 * bubble
  const leadIn = demo && clock % PERFORMANCE_DURATION >= .65 && clock % PERFORMANCE_DURATION < 1.15
    ? Math.sin((clock % PERFORMANCE_DURATION - .65) / .5 * Math.PI) : 0
  upper.angle += .035 * leadIn
  fore.angle += .022 * leadIn
  hand.angle += .055 * leadIn
  const wave = (mode === 'wave' || (demo && event.phase === 'greet')) ? smooth((p - .72) / .28) : 0
  const waveTime = demo ? clock - 8.35 : clock
  const waveEnvelope = demo ? smooth((clock % PERFORMANCE_DURATION - 8.35) / .35) * (1 - smooth((clock % PERFORMANCE_DURATION - 10.4) / .4)) : 1
  upper.angle += .012 * breathLate * raised + .018 * Math.sin(waveTime * TAU * .9 - .7) * wave * waveEnvelope
  fore.angle += .018 * breath * raised + .038 * Math.sin(waveTime * TAU * .9 - .35) * wave * waveEnvelope
  hand.angle += .025 * breathLate * raised + (.20 * Math.sin(waveTime * TAU * .9) + .035 * Math.sin(waveTime * TAU * 1.8 + .3)) * wave * waveEnvelope
  // A damped arrival is separate from the wave, with more wrist than shoulder motion.
  if (demo) {
    const age = clock % PERFORMANCE_DURATION - 8.35
    if (age >= 0 && age < 2) { const settle = Math.exp(-age * 3) * Math.sin(age * 9); hand.angle += .07 * settle; fore.angle += .018 * settle }
  }
  const shoulder = { ...config.baseShoulder }, elbow = vec(shoulder, upper.angle, upper.length), wrist = vec(elbow, fore.angle, fore.length), palm = vec(wrist, hand.angle, hand.length)
  const arm = { shoulder, elbow, wrist, palm }
  const bodyBeat = Math.sin(clock * TAU / 6.2)
  const activity = Math.sin(Math.PI * p)
  // The loose cloth follows the movement slightly after the bones. Bend is a
  // small section-normal offset with pinned ends, not another pose/material swap.
  const clothBend: ClothBend = {
    upper: clamp(2.6 * Math.sin(Math.PI * upperP) + 1.15 * breathLate * raised + .8 * leadIn + 1.1 * Math.sin(waveTime * TAU * .9 - .95) * wave * waveEnvelope, -6, 6),
    fore: clamp(3.8 * Math.sin(Math.PI * handP) + 1.4 * Math.sin(clock * TAU / 4.5 - .85) * raised + 1.9 * Math.sin(waveTime * TAU * .9 - .8) * wave * waveEnvelope, -6, 6),
  }
  const driver: Partial<Driver> = {
    body: -.16 * raised + .045 * bodyBeat,
    torsoTurn: -.065 * raised + .020 * Math.sin(clock * TAU / 6.2 - .4),
    bodyLift: .060 * breath + .050 * activity - .025 * leadIn,
    bodyPitch: -.045 * raised + .022 * breathLate,
    angleX: .095 * raised + .020 * bodyBeat,
    angleY: .035 * raised + .022 * breathLate,
    angleZ: -.075 * raised + .018 * bodyBeat,
    armRaiseL: .025 * raised + .012 * breathLate,
    armSwingL: -.035 * raised + .020 * Math.sin(clock * TAU / 6.2 - .8),
    armRaiseR: 0,
    armSwingR: 0,
    physAmp: .55,
    fhAmp: .65,
    soft: 1.6,
    fhSoft: .55,
  }
  return { progress: p, arm, driver, phase: demo ? event.phase : mode === 'wave' ? 'greet' : p > .72 ? 'present' : 'breathe', cycleDuration: PERFORMANCE_DURATION, boneProgress: { upper: upperP, fore: foreP, hand: handP }, clothBend }
}
