import type { Point } from './arm-skin'

/** One cut-out frame of the generated arm clip: where it sits in an atlas and in the rig's source canvas. */
export type VideoArmFrame = { segment: string; clipFrame: number; atlas: number; rect: [number, number, number, number]; world: [number, number, number, number] }
/** Frame sequences, by index into `frames`; progress keys map the manual 0…1 raise onto them. */
export type VideoArmTimeline = { rest: number; raise: number[]; progress: number[]; wave?: number[]; lower?: number[] }
export type VideoArmConfig = { atlases: { image: string }[]; frames: VideoArmFrame[]; timeline: VideoArmTimeline; fps: number }
/** The torso's drawn transform at the shoulder: rest shoulder `s` maps to `S`, offsets by [[a, c], [b, d]]. */
export type ArmAttach = { s: Point; S: Point; a: number; b: number; c: number; d: number }

const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x))
const vertex = `#version 300 es
precision highp float;
in vec2 position;in vec2 uv;uniform vec2 view;out vec2 st;
void main(){st=uv;vec2 p=position/view;gl_Position=vec4(2.*p.x-1.,1.-2.*p.y,0.,1.);}`
const fragment = `#version 300 es
precision highp float;
in vec2 st;uniform sampler2D atlas;uniform float weight;out vec4 color;
void main(){color=texture(atlas,st)*weight;}`

function image(url: string) { return new Promise<HTMLImageElement>((resolve, reject) => { const im = new Image(); im.onload = () => resolve(im); im.onerror = () => reject(Error('无法加载手臂序列：' + url)); im.src = url }) }

/**
 * The arm as drawn frame by frame (a generated clip cut out per frame), not a
 * mesh bent between a few paintings: neighbouring frames differ by a frame of
 * motion, so a cross-fade between them reads as continuous cloth. Each frame
 * rides the torso's drawn shoulder transform, so breathing and lean carry it.
 */
export class VideoArm {
  private readonly gl: WebGL2RenderingContext
  private readonly shader: WebGLProgram
  private readonly vao: WebGLVertexArrayObject
  private readonly position: WebGLBuffer
  private readonly uv: WebGLBuffer
  private textures: { texture: WebGLTexture; width: number; height: number }[] = []
  private diagnostics = { frame: 0, first: -1, second: -1, blend: 0, nonFinite: 0, loaded: false }

  constructor(readonly canvas: HTMLCanvasElement, readonly config: VideoArmConfig, readonly playbackOffset: [number, number]) {
    const gl = canvas.getContext('webgl2', { alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, antialias: true }); if (!gl) throw Error('WebGL2 unavailable')
    this.gl = gl
    const p = gl.createProgram()!
    for (const [kind, code] of [[gl.VERTEX_SHADER, vertex], [gl.FRAGMENT_SHADER, fragment]] as const) { const s = gl.createShader(kind)!; gl.shaderSource(s, code); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(s) || 'Shader compile'); gl.attachShader(p, s); gl.deleteShader(s) }
    gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw Error(gl.getProgramInfoLog(p) || 'Shader link')
    this.shader = p; this.vao = gl.createVertexArray()!; this.position = gl.createBuffer()!; this.uv = gl.createBuffer()!
  }

  async load(urlFor: (name: string) => string) {
    const gl = this.gl
    for (const t of this.textures) gl.deleteTexture(t.texture)
    this.textures = []
    for (const atlas of this.config.atlases) {
      const im = await image(urlFor(atlas.image)), texture = gl.createTexture()!
      gl.bindTexture(gl.TEXTURE_2D, texture); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true)
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, im)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
      this.textures.push({ texture, width: im.naturalWidth, height: im.naturalHeight })
    }
    this.diagnostics.loaded = true
    return this.config.frames.length
  }

  /** The frame (fractional, into `frames`) for a manual raise progress 0…1, through the timeline's keys. */
  frameForProgress(progress: number) {
    const { raise, progress: keys } = this.config.timeline, p = clamp(progress)
    let high = keys.findIndex(k => k >= p); if (high < 1) high = high === 0 ? 0 : keys.length - 1
    if (high === 0) return raise[0]!
    const t = (p - keys[high - 1]!) / Math.max(1e-6, keys[high]! - keys[high - 1]!)
    return raise[high - 1]! + (raise[high]! - raise[high - 1]!) * clamp(t)
  }

  /** Sequence frame for a time along a named run, clamped at its ends. */
  frameForRun(run: number[], seconds: number) {
    const f = clamp(seconds * this.config.fps, 0, run.length - 1), i = Math.floor(f), j = Math.min(run.length - 1, i + 1)
    return run[i]! + (run[j]! - run[i]!) * (f - i)
  }

  /** Draws a fractional frame index: the two neighbouring frames cross-fade, each on the torso's transform. */
  draw(frame: number, view: { width: number; height: number }, options: { viewport?: [number, number, number, number]; attach?: ArmAttach; blend?: boolean; crossTo?: number; crossWeight?: number } = {}) {
    const gl = this.gl, frames = this.config.frames
    // Played at its own rate the clip is shown frame by frame, as video is: a
    // cross-fade there would print two outlines of a fast hand. Slow scrubbing
    // and authored hand-overs (blend) fade between neighbours instead.
    const exact = clamp(Number.isFinite(frame) ? frame : 0, 0, frames.length - 1), f = options.blend === false ? Math.round(exact) : exact
    // A cross-fade between two poses far apart in the sequence (the end of the wave onto
    // its arrival pose) mixes those two frames, rather than scrubbing every frame between.
    const cross = options.crossTo !== undefined && Number.isFinite(options.crossTo)
    const i = cross ? Math.round(f) : Math.floor(f), j = cross ? Math.round(clamp(options.crossTo!, 0, frames.length - 1)) : Math.min(frames.length - 1, i + 1)
    const t = cross ? clamp(options.crossWeight ?? 0) : f - i
    const viewport: [number, number, number, number] = options.viewport ?? [0, 0, this.canvas.width, this.canvas.height]
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(...viewport); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT)
    if (!this.textures.length) return this.diagnostics
    gl.useProgram(this.shader); gl.uniform2f(gl.getUniformLocation(this.shader, 'view'), view.width, view.height); gl.uniform1i(gl.getUniformLocation(this.shader, 'atlas'), 0)
    // Premultiplied frames summed with weights (1−t, t): an exact cross-fade, opaque wherever both cover.
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE)
    let nonFinite = 0
    const [ox, oy] = this.playbackOffset, a = options.attach
    const place = (x: number, y: number) => {
      if (!a) return [x + ox, y + oy]
      const dx = x - a.s.x, dy = y - a.s.y
      return [a.S.x + a.a * dx + a.c * dy + ox, a.S.y + a.b * dx + a.d * dy + oy]
    }
    for (const [index, weight] of (i === j || t < 1e-4 ? [[i, 1]] : t > 1 - 1e-4 ? [[j, 1]] : [[i, 1 - t], [j, t]]) as [number, number][]) {
      const frameInfo = frames[index]!, atlas = this.textures[frameInfo.atlas]
      if (!atlas) continue
      const [x, y, w, h] = frameInfo.world, [u, v, uw, vh] = frameInfo.rect
      const corners = [place(x, y), place(x + w, y), place(x, y + h), place(x + w, y + h)].flat()
      for (const value of corners) if (!Number.isFinite(value)) nonFinite++
      const u0 = u / atlas.width, v0 = v / atlas.height, u1 = (u + uw) / atlas.width, v1 = (v + vh) / atlas.height
      gl.bindVertexArray(this.vao)
      gl.bindBuffer(gl.ARRAY_BUFFER, this.position); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(corners), gl.DYNAMIC_DRAW)
      let loc = gl.getAttribLocation(this.shader, 'position'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0)
      gl.bindBuffer(gl.ARRAY_BUFFER, this.uv); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([u0, v0, u1, v0, u0, v1, u1, v1]), gl.DYNAMIC_DRAW)
      loc = gl.getAttribLocation(this.shader, 'uv'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0)
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, atlas.texture); gl.uniform1f(gl.getUniformLocation(this.shader, 'weight'), weight)
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4)
    }
    this.diagnostics = { frame: f, first: i, second: j, blend: t, nonFinite, loaded: true }
    return this.diagnostics
  }

  inspect() { return { ...this.diagnostics, frames: this.config.frames.length, atlases: this.textures.length, webglError: this.gl.getError() } }
}
