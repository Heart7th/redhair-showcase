import { PerformanceWorkbench } from './workbench'
import { performanceApi } from './api'
const pkg = (window as any).__RAISE_PREVIEW__
async function start() {
  const app = await new PerformanceWorkbench(pkg.source, pkg.atlas, pkg.config, name => {
    const image = pkg.images[name]
    if (!image) throw Error('离线包缺少素材：' + name)
    return image
  }).init()
  app.setPose('demo'); app.setView('full'); app.setExpression('neutral')
  const api = performanceApi(app)
  Object.assign(window, { performancePreview: api, raisePreview: api })
}
start().catch(e => { document.querySelector('#status')!.textContent = `动作表情预览未能加载：${e?.message || e}`; throw e })
