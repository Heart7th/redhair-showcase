import { Anime25DPlayer } from '../vendor/myriad-figure/src/anime25drig/index'
import { ArmSkin, type KeyConfig, type Joints } from './arm-skin'
import { BodyAttachment } from './body-attachment'
import { FlareFace } from './flare-face'
import { samplePerformance } from './motion'
import { EXPRESSION_PRESETS, sampleExpression, type ExpressionId } from './expressions'
import { sampleHeadTurn, HEAD_TURN_PERIOD_SECONDS, type HeadTurnMode } from './head-motion'

type Save = (name: string, body: Blob | string) => Promise<any>
type View = 'full' | 'face' | 'shoulder'
const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x))

export class PerformanceWorkbench {
  readonly base = document.querySelector<HTMLCanvasElement>('#base')!
  readonly arm = document.querySelector<HTMLCanvasElement>('#arm')!
  readonly overlay = document.querySelector<HTMLCanvasElement>('#bones')!
  readonly expressionCanvas = document.querySelector<HTMLCanvasElement>('#expression-art')!
  readonly face = document.querySelector<HTMLCanvasElement>('#face')!
  readonly player: Anime25DPlayer
  readonly skin: ArmSkin
  readonly flare: FlareFace
  private expressionPresets = EXPRESSION_PRESETS
  private attachment?: BodyAttachment
  private progress = 0
  private velocity = 0
  private goal = 0
  private mode = 'demo'
  private elapsed = 0
  private expressionTime = 0
  private headTime = 0
  private headMode: HeadTurnMode = 'auto'
  private headBlend = 1
  private headFrom = { yaw: 0, pitch: 0 }
  private headSample?: ReturnType<typeof sampleHeadTurn>
  private last = 0
  private warmup = 0
  private paused = false
  private recording = false
  private loaded: string[] = []
  private missing: string[] = []
  private expression: ExpressionId = 'smile'
  private expressionAuto = false
  private expressionStrength = 1
  private talk = false
  private view: View = 'full'
  private sample?: ReturnType<typeof samplePerformance>
  private faceSample?: ReturnType<typeof sampleExpression>
  private actualJoints?: Joints
  private camera?: { width: number; height: number; viewport: [number, number, number, number] }
  private captureSize?: { width: number; height: number }

  constructor(readonly source: any, private atlas: string, readonly config: KeyConfig, private urlFor: (name: string) => string, private saver?: Save) {
    const playback = structuredClone(source.anime25dPlayback ?? source)
    // This artwork already paints the back hood in topwear. The generated
    // collar-back duplicates it and exposes a filled rectangle when nodding.
    // Keep collar-front: its native clip preserves the V-neck skin boundary.
    playback.layers = playback.layers.filter((l: any) => !(l.role === 'handwear' && l.side === 'R') && !(l.role === 'collar-back' && l.synthetic))
    this.player = new Anime25DPlayer(this.base, playback)
    // The skull is rigid; hair springs remain enabled independently.
    this.player.setHeadSquashStretch(false)
    this.skin = new ArmSkin(this.arm, config)
    const manifest=(config as any).faceArt??{expressions:[]}
    this.flare=new FlareFace(this.expressionCanvas,{crop:manifest.crop??{x:64,y:0,width:512,height:512},playbackOffset:config.playbackOffset,transitionSeconds:.12})
    this.expressionPresets=EXPRESSION_PRESETS.filter(p=>p.id==='neutral'||manifest.expressions.some((e:any)=>e.id===p.id))
    for (const button of document.querySelectorAll<HTMLButtonElement>('[data-pose]')) button.onclick = () => this.setPose(button.dataset.pose!)
    for (const button of document.querySelectorAll<HTMLButtonElement>('[data-view]')) button.onclick = () => this.setView(button.dataset.view as View)
    for (const button of document.querySelectorAll<HTMLButtonElement>('[data-head]')) button.onclick = () => this.setHeadTurn(button.dataset.head as HeadTurnMode)
    const choices = document.querySelector('#expression-buttons')!
    for (const preset of this.expressionPresets) {
      const button = document.createElement('button'); button.textContent = preset.label; button.title = preset.description; button.dataset.expression = preset.id
      button.onclick = () => this.setExpression(preset.id); choices.append(button)
    }
    document.querySelector<HTMLInputElement>('#raise')!.oninput = e => this.setProgress(Number((e.target as HTMLInputElement).value))
    document.querySelector<HTMLInputElement>('#expression-strength')!.oninput = e => this.setExpressionStrength(Number((e.target as HTMLInputElement).value))
    
    document.querySelector<HTMLInputElement>('#show-bones')!.onchange = () => this.drawBones()
    document.querySelector<HTMLButtonElement>('#expression-loop')!.onclick = () => { this.setPose('down'); this.setView('face'); this.setExpressionLoop(true) }
    document.querySelector<HTMLButtonElement>('#pause')!.onclick = () => this.setPaused(!this.paused)
    document.querySelector<HTMLButtonElement>('#record')!.onclick = () => this.record().catch(e => this.say(e.message))
    document.querySelector<HTMLButtonElement>('#record-shoulder')!.onclick = () => this.record(16, false, 'shoulder').catch(e => this.say(e.message))
    document.querySelector<HTMLButtonElement>('#record-faces')!.onclick = () => this.record(HEAD_TURN_PERIOD_SECONDS * this.expressionPresets.length + 2, false, 'expressions').catch(e => this.say(e.message))
    document.querySelector<HTMLButtonElement>('#export-face')!.onclick = () => this.snapshot('红发角色-高清表情.png', false, true).catch(e => this.say(e.message))
    window.addEventListener('resize', () => this.resize())
  }

  async init() {
    await this.player.loadAtlas(this.atlas)
    this.player.setMotionPolicy({ mouth: 'preview', expression: 'preview', gaze: 'preview', headBody: 'preview' })
    this.player.setTarget({ idle: false, rand: false, blink: false, talk: false, mouse: false, phys: true, bust: 0, bodyYaw: 0, body: 0, torsoTurn: 0, bodyLift: 0, bodyPitch: 0, armRaiseL: 0, armRaiseR: 0, armSwingL: 0, armSwingR: 0 })
    await this.loadKeyforms()
    this.resize(); this.player.tick(1 / 60)
    this.attachment = new BodyAttachment(this.player.inspect(), this.config)
    this.updateButtons(); this.render(1 / 60)
    requestAnimationFrame(t => this.frame(t))
    return this
  }
  private say(text: string) { document.querySelector('#status')!.textContent = text }
  private resize() {
    const box = document.querySelector<HTMLElement>('#stagebox')!, dpr = Math.min(this.view === 'full' ? 2 : 3, devicePixelRatio || 1)
    this.player.resize(box.clientWidth, box.clientHeight, dpr)
    this.face.width = this.captureSize?.width ?? Math.round(box.clientWidth * dpr); this.face.height = this.captureSize?.height ?? Math.round(box.clientHeight * dpr)
    this.camera = undefined
    if (this.view !== 'full') {
      const world = this.source.anime25dPlayback.pixelCanvas, crop = this.closeupCrop()
      const gl = this.base.getContext('webgl2')!, maxViewport = gl.getParameter(gl.MAX_VIEWPORT_DIMS) as Int32Array
      const scale = Math.min(this.face.width / crop.width, this.face.height / crop.height, maxViewport[0]! / world.width, maxViewport[1]! / world.height)
      const width = Math.round(crop.width * scale), height = Math.round(crop.height * scale)
      // Render the face directly at its output pixel density. A shifted viewport
      // clips the world without first shrinking the entire full-body drawing.
      this.camera = { width, height, viewport: [Math.round(-crop.x * scale), Math.round(height - (world.height - crop.y) * scale), Math.round(world.width * scale), Math.round(world.height * scale)] }
      this.base.width = width; this.base.height = height
      this.base.getContext('webgl2')!.viewport(...this.camera.viewport)
    }
    for (const canvas of [this.arm, this.overlay, this.expressionCanvas]) { canvas.width = this.base.width; canvas.height = this.base.height; canvas.style.width = this.base.style.width; canvas.style.height = this.base.style.height }
    this.face.style.width = box.clientWidth + 'px'; this.face.style.height = box.clientHeight + 'px'
    if (this.attachment) this.render(1 / 60)
  }
  private closeupCrop() { return this.view === 'shoulder' ? { x: this.config.baseShoulder.x + this.config.playbackOffset[0] - 160, y: 300, width: 480, height: 560 } : { x: this.source.anime25dPlayback.anchors.face.cx - 260, y: 0, width: 540, height: 570 } }
  async loadKeyforms() {
    const result = await this.skin.load(this.urlFor); this.loaded = result.loaded; this.missing = result.missing
    const faceResult=await this.flare.load((this.config as any).faceArt??{expressions:[]},this.urlFor);this.missing=[...this.missing,...faceResult.missing]
    this.say(this.missing.length ? `尚缺手臂素材：${this.missing.join('、')}` : '自然手型、翻腕过渡与 Flare 原画表情已加载')
    return result
  }
  setProgress(p: number, immediate = false) {
    this.mode = 'manual'; this.goal = clamp(p); this.paused = false
    if (immediate) { this.progress = this.goal; this.velocity = 0; this.elapsed = 0; this.render(1 / 60); this.paused = true }
    this.updateButtons()
  }
  setPose(mode: string) {
    this.mode = mode; this.elapsed = 0; this.paused = false
    this.warmup = mode === 'demo' && this.progress > .01 ? 1.2 : 0
    if (mode === 'down') this.goal = 0
    if (mode === 'chest') this.goal = .5
    if (mode === 'head' || mode === 'wave') this.goal = 1
    this.updateButtons()
    this.say(({ down: '自然待机', chest: '抬到胸前，轻轻收势', head: '举手后保持呼吸', wave: '手腕轻挥，身体自然配合', demo: '连续动作演示' } as Record<string, string>)[mode] ?? '手动查看动作')
  }
  setExpression(id: ExpressionId) { if(this.headMode==='auto'){const h=this.player.getCurrent();this.headFrom={yaw:h.angleX,pitch:h.angleY};this.headBlend=0} this.expression = this.expressionPresets.some(p => p.id === id) ? id : 'neutral'; this.expressionTime = 0; this.headTime = 0; this.expressionAuto = false; this.paused = false; this.updateButtons() }
  setExpressionStrength(value: number) { this.expressionStrength = clamp(value); this.paused = false }
  setExpressionLoop(enabled: boolean) { this.expressionAuto = enabled; this.expressionTime = 0; this.headTime = 0; if (enabled) { const h=this.player.getCurrent();this.headFrom={yaw:h.angleX,pitch:h.angleY};this.headBlend=0;this.headMode = 'auto' }; this.paused = false; this.updateButtons() }
  setHeadTurn(mode: HeadTurnMode) { const current=this.player.getCurrent(); this.headFrom={yaw:current.angleX,pitch:current.angleY}; this.headBlend=0; this.headMode = ['center','left','right','up','down','auto'].includes(mode) ? mode : 'center'; this.headTime = 0; this.paused = false; this.updateButtons() }
  setTalk(_enabled: boolean) { this.talk = false }
  setView(view: View) { const changed = this.view !== view; this.view = view; document.querySelector<HTMLElement>('#stagebox')!.dataset.view = view; this.updateButtons(); if (changed) this.resize(); else this.drawCloseup() }
  setPaused(value: boolean) { this.paused = value; document.querySelector('#pause')!.textContent = value ? '继续播放' : '暂停' }
  setSkeleton(show: boolean) { document.querySelector<HTMLInputElement>('#show-bones')!.checked = show; this.drawBones() }
  seek(time: number, mode = 'demo', settleFrames = 45) { this.mode = mode; this.elapsed = Math.max(0, time); this.expressionTime = Math.max(0, time); this.headTime = Math.max(0, time); this.warmup = 0; this.headBlend=1; for(let i=0;i<settleFrames;i++)this.render(1 / 60); this.paused = true; this.updateButtons() }
  private updateButtons() {
    for (const b of document.querySelectorAll<HTMLButtonElement>('[data-pose]')) b.setAttribute('aria-pressed', String(b.dataset.pose === this.mode))
    for (const b of document.querySelectorAll<HTMLButtonElement>('[data-view]')) b.setAttribute('aria-pressed', String(b.dataset.view === this.view))
    for (const b of document.querySelectorAll<HTMLButtonElement>('[data-expression]')) b.setAttribute('aria-pressed', String(!this.expressionAuto && b.dataset.expression === this.expression))
    for (const b of document.querySelectorAll<HTMLButtonElement>('[data-head]')) b.setAttribute('aria-pressed', String(b.dataset.head === this.headMode))
    document.querySelector('#expression-loop')!.setAttribute('aria-pressed', String(this.expressionAuto))
    document.querySelector('#pause')!.textContent = this.paused ? '继续播放' : '暂停'
  }
  private frame(now: number) {
    const dt = Math.min(.05, this.last ? (now - this.last) / 1000 : 1 / 60); this.last = now
    if (!this.paused) {
      this.expressionTime += dt
      this.headTime += dt
      if (this.warmup > 0) this.warmup = Math.max(0, this.warmup - dt)
      else this.elapsed += dt
      if (this.mode !== 'demo' || this.warmup > 0) {
        const goal = this.warmup > 0 ? 0 : this.goal, omega = 5.5
        // A damped joint-control approach eases both acceleration and settling.
        const step = Math.min(dt, 1 / 60), steps = Math.max(1, Math.ceil(dt / step)), h = dt / steps
        for (let k = 0; k < steps; k++) { this.velocity += ((goal - this.progress) * omega * omega - 2 * omega * this.velocity) * h; this.progress = clamp(this.progress + this.velocity * h) }
        if (Math.abs(this.progress - goal) < .00001 && Math.abs(this.velocity) < .0001) { this.progress = goal; this.velocity = 0 }
      }
      this.render(dt)
    }
    requestAnimationFrame(t => this.frame(t))
  }
  private render(dt: number) {
    if (!this.loaded.length || !this.attachment) return
    const mode = this.warmup > 0 ? 'manual' : this.mode
    this.sample = samplePerformance(this.config, this.elapsed, mode, this.progress)
    this.progress = this.sample.progress
    const expressionLocalTime = this.expressionTime % HEAD_TURN_PERIOD_SECONDS
    const preset = this.expressionAuto ? this.expressionPresets[Math.floor(this.expressionTime / HEAD_TURN_PERIOD_SECONDS) % this.expressionPresets.length]!.id : this.expression
    this.faceSample = sampleExpression(preset, this.expressionStrength, expressionLocalTime, { talk: this.talk })
    this.headSample = sampleHeadTurn(this.headMode, this.expressionAuto ? expressionLocalTime : this.headTime)
    this.headBlend = Math.min(1, this.headBlend + dt / .75)
    const u=this.headBlend, blend=u*u*u*(u*(u*6-15)+10)
    const headYaw=this.headFrom.yaw+(this.headSample.yaw-this.headFrom.yaw)*blend
    const headPitch=this.headFrom.pitch+(this.headSample.pitch-this.headFrom.pitch)*blend
    const motion = this.sample.driver, face = this.faceSample, neutral=sampleExpression('neutral',0,0).driver
    this.player.setTarget({ idle: false, rand: false, talk: false, mouse: false, phys: true, bodyYaw: 0, bust: 0, physAmp: .5, soft: 1.4, ...motion, ...neutral, blink:false,
      angleX: clamp(headYaw + .08 * (motion.angleX ?? 0) + .1 * face.head.angleX, -1, 1), angleY: clamp(headPitch + .08 * (motion.angleY ?? 0) + .1 * face.head.angleY, -1, 1), angleZ: clamp((motion.angleZ ?? 0) + face.head.angleZ, -.5, .5) })
    if (this.camera) this.base.getContext('webgl2')!.viewport(...this.camera.viewport)
    this.player.tick(dt)
    const inspection = this.player.inspect()
    this.actualJoints = this.attachment.map(this.sample.arm, inspection)
    this.skin.draw(this.progress, this.source.anime25dPlayback.pixelCanvas, { joints: this.actualJoints, clothBend: this.sample.clothBend, viewport: this.camera?.viewport, shoulderRoot: this.attachment.sleeveRoot() })
    const phase=this.expressionTime%4.8, blink=(preset==='happy'||preset==='wink')?0:phase>4.3&&phase<4.54?Math.sin((phase-4.3)/.24*Math.PI)**2:0
    this.flare.draw(preset,1,dt,inspection,this.source.anime25dPlayback.pixelCanvas,{blink,viewport:this.camera?.viewport})
    this.drawBones(); this.drawCloseup()
    document.querySelector<HTMLInputElement>('#raise')!.value = String(this.progress)
    document.querySelector('#raise-value')!.textContent = this.progress.toFixed(2)
    document.querySelector('#expression-label')!.textContent = this.faceSample.label
    document.querySelector('#head-turn-label')!.textContent = this.headSample.label
    document.querySelector('#expression-strength-value')!.textContent = this.expressionStrength.toFixed(2)
    document.querySelector<HTMLInputElement>('#expression-strength')!.value = String(this.expressionStrength)
  }
  private drawBones() {
    const c = this.overlay.getContext('2d')!; c.clearRect(0, 0, this.overlay.width, this.overlay.height)
    if (!document.querySelector<HTMLInputElement>('#show-bones')!.checked || !this.actualJoints) return
    const view = this.source.anime25dPlayback.pixelCanvas, sx = this.overlay.width / view.width, sy = this.overlay.height / view.height, offset = this.config.playbackOffset
    const points = ['shoulder', 'elbow', 'wrist', 'palm'].map(n => this.actualJoints![n as keyof Joints])
    c.lineWidth = Math.max(2, this.overlay.width / 360); c.strokeStyle = '#216f7b'; c.fillStyle = '#fff5c0'
    c.beginPath(); points.forEach((p, k) => { const x = (p.x + offset[0]) * sx, y = (p.y + offset[1]) * sy; k ? c.lineTo(x, y) : c.moveTo(x, y) }); c.stroke()
    for (const p of points) { c.beginPath(); c.arc((p.x + offset[0]) * sx, (p.y + offset[1]) * sy, Math.max(3, this.overlay.width / 230), 0, Math.PI * 2); c.fill(); c.stroke() }
  }
  private drawTo(ctx: CanvasRenderingContext2D, width: number, height: number, bones: boolean, face: boolean) {
    ctx.fillStyle = '#e6e3dc'; ctx.fillRect(0, 0, width, height)
    if (face) {
      if (this.camera) {
        const scale = Math.min(width / this.camera.width, height / this.camera.height), w = this.camera.width * scale, h = this.camera.height * scale
        const x = (width - w) / 2, y = (height - h) / 2
        ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high'
        for (const canvas of [this.base, this.arm, this.expressionCanvas]) ctx.drawImage(canvas, x, y, w, h)
        return
      }
      const anchors = this.source.anime25dPlayback.anchors, view = this.source.anime25dPlayback.pixelCanvas
      const crop = { x: anchors.face.cx - 260, y: 0, width: 540, height: 570 }, sx = this.base.width / view.width, sy = this.base.height / view.height
      const scale = Math.min(width / crop.width, height / crop.height), w = crop.width * scale, h = crop.height * scale, x = (width - w) / 2, y = (height - h) / 2
      for (const canvas of bones ? [this.base, this.arm, this.expressionCanvas, this.overlay] : [this.base, this.arm, this.expressionCanvas]) ctx.drawImage(canvas, crop.x * sx, crop.y * sy, crop.width * sx, crop.height * sy, x, y, w, h)
    } else {
      const scale = Math.min(width / this.base.width, height / this.base.height), w = this.base.width * scale, h = this.base.height * scale, x = (width - w) / 2, y = (height - h) / 2
      ctx.drawImage(this.base, x, y, w, h); ctx.drawImage(this.arm, x, y, w, h); ctx.drawImage(this.expressionCanvas,x,y,w,h); if (bones) ctx.drawImage(this.overlay, x, y, w, h)
    }
  }
  private drawCloseup() { if (this.view !== 'full') this.drawTo(this.face.getContext('2d')!, this.face.width, this.face.height, false, true) }
  getState() { return { mode: this.mode, time: this.elapsed, progress: this.progress, goal: this.goal, paused: this.paused, view: this.view, expression: this.faceSample?.id ?? this.expression, expressionLabel: this.faceSample?.label, expressionStrength: this.expressionStrength, expressionAuto: this.expressionAuto, headTurn:{...this.headSample,mode:this.headMode,time:this.headTime,actualYaw:this.player.getCurrent().angleX,actualPitch:this.player.getCurrent().angleY,expressionSeconds:HEAD_TURN_PERIOD_SECONDS}, phase: this.sample?.phase, boneProgress: this.sample?.boneProgress, targetDriver: this.sample?.driver, cycleDuration: this.sample?.cycleDuration, loaded: this.loaded, missing: this.missing, arm: this.skin.inspect(), attachment: this.attachment?.inspect(), driver: this.player.getCurrent(), recording: this.recording, faceArt:this.flare.inspect(), expressionCount:this.expressionPresets.length, baseLayers: this.player.inspect().layers.length } }
  async snapshot(name = 'performance-neutral.png', bones = false, face?: boolean) {
    const previous = this.view
    try {
      const target = face === undefined ? this.view : face ? 'face' : 'full', closeup = target !== 'full', height = target === 'shoulder' ? 1680 : 1520
      if (closeup) { this.captureSize = { width: 1440, height }; this.setView(target); this.resize() }
      else this.setView('full')
      const out = document.createElement('canvas'); out.width = closeup ? 1440 : this.base.width; out.height = closeup ? height : this.base.height
      this.drawTo(out.getContext('2d')!, out.width, out.height, bones, closeup)
      const blob = await new Promise<Blob>(resolve => out.toBlob(b => resolve(b!)))
      return await this.save(name, blob)
    } finally { this.captureSize = undefined; this.setView(previous); this.resize() }
  }
  private async save(name: string, body: Blob | string) {
    if (this.saver) return this.saver(name, body)
    const blob = typeof body === 'string' ? new Blob([body], { type: 'application/json' }) : body, a = document.createElement('a')
    a.href = URL.createObjectURL(blob); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000)
    return { download: name, bytes: blob.size }
  }
  async record(seconds = 16, bones = false, kind: 'motion' | 'expressions' | 'shoulder' = 'motion') {
    if (this.recording) throw Error('正在录制，请等待完成')
    this.recording = true
    const previous = { bones: document.querySelector<HTMLInputElement>('#show-bones')!.checked, view: this.view, auto: this.expressionAuto, headMode: this.headMode, headTime: this.headTime, expressionTime: this.expressionTime }
    this.setSkeleton(bones); this.progress = 0; this.velocity = 0
    if (kind === 'expressions') { this.setPose('down'); this.setView('face'); this.setExpressionLoop(true) }
    else { this.setView(kind === 'shoulder' ? 'shoulder' : 'full'); this.setExpressionLoop(false); this.setPose('demo') }
    const output = document.createElement('canvas'); output.width = 720; output.height = kind !== 'motion' ? 900 : 1200
    const ctx = output.getContext('2d')!, stream = output.captureStream(30), mime = MediaRecorder.isTypeSupported('video/mp4') ? 'video/mp4' : 'video/webm;codecs=vp9'
    const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 7000000 }), chunks: Blob[] = []
    recorder.ondataavailable = e => { if (e.data.size) chunks.push(e.data) }
    const ended = new Promise<Blob>(resolve => { recorder.onstop = () => resolve(new Blob(chunks, { type: mime })) })
    let capture = 0
    const draw = () => {
      this.drawTo(ctx, output.width, output.height, bones, kind !== 'motion')
      if (kind === 'expressions') { ctx.fillStyle = '#302d28'; ctx.textAlign = 'center'; ctx.font = '32px system-ui'; ctx.fillText(this.faceSample?.label ?? '', 360, 860) }
      capture = requestAnimationFrame(draw)
    }
    draw(); recorder.start(1000); this.say(`正在录制 ${seconds} 秒${kind === 'expressions' ? '表情' : '动作'}演示…`)
    await new Promise(r => setTimeout(r, seconds * 1000)); recorder.stop()
    const blob = await ended; cancelAnimationFrame(capture); stream.getTracks().forEach(t => t.stop())
    this.recording = false; this.expressionAuto = previous.auto; this.headMode = previous.headMode; this.headTime = previous.headTime; this.expressionTime = previous.expressionTime
    this.setSkeleton(previous.bones); this.setView(previous.view); this.updateButtons()
    const name = (kind === 'shoulder' ? 'performance-shoulder' : kind === 'expressions' ? 'performance-expressions' : bones ? 'performance-skeleton' : 'performance-motion') + (mime.startsWith('video/mp4') ? '.mp4' : '.webm')
    const result = await this.save(name, blob); this.say('演示已保存')
    return { ...result, seconds, name }
  }
}
