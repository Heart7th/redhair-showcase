import { createHandArt, handGeometry, selectHandView, type HandArt, type HandDescriptor } from './hand'
export type Point = { x: number; y: number }
export type JointName = 'shoulder' | 'elbow' | 'wrist' | 'palm'
export type Joints = Record<JointName, Point>
export type ClothBend = { upper: number; fore: number }
export type KeyDescriptor = { id: string; progress: number; image: string; handImage?: string; sleeveImage?: string; sourceJoints: Record<JointName, [number, number]>; handSourceJoints?: { wrist: [number, number]; palm: [number, number]; thumb?: [number, number] } }
export type KeyConfig = { canvas: [number, number]; playbackOffset: [number, number]; baseShoulder: Point; keyforms: KeyDescriptor[]; handEdge?: { image: string; sourceJoints: { wrist: [number, number]; palm: [number, number] }; thumb?: [number, number] } }
type Span = { left: Point; right: Point; negative: number; positive: number }
type Form = { key: KeyDescriptor; joints: Joints; texture: WebGLTexture; rgba: Uint8ClampedArray; upper: Span[]; fore: Span[] }
type Geometry = { positions: number[]; firstUV: number[]; secondUV: number[]; indices: number[]; coverage?: number[]; softness?: number[] }
export type ShoulderRoot = { outer: Point; inner: Point }
const names: JointName[] = ['shoulder', 'elbow', 'wrist', 'palm']
const SECTIONS = 16
const mix = (a: number, b: number, t: number) => a + (b - a) * t
const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x))
const ease = (x: number) => { const t = clamp(x, 0, 1); return t * t * (3 - 2 * t) }
const lerp = (a: Point, b: Point, t: number): Point => ({ x: mix(a.x, b.x, t), y: mix(a.y, b.y, t) })
const add = (a: Point, b: Point): Point => ({ x: a.x + b.x, y: a.y + b.y })
const mul = (a: Point, s: number): Point => ({ x: a.x * s, y: a.y * s })
function axis(a: Point, b: Point) { const length = Math.hypot(b.x - a.x, b.y - a.y); const d = { x: (b.x - a.x) / length, y: (b.y - a.y) / length }; return { length, d, n: { x: -d.y, y: d.x } } }
export function jointsFor(key: KeyDescriptor): Joints { return Object.fromEntries(names.map(n => [n, { x: key.sourceJoints[n][0], y: key.sourceJoints[n][1] }])) as Joints }
function bone(a: Point, b: Point) { return { angle: Math.atan2(b.y - a.y, b.x - a.x), length: Math.hypot(b.x - a.x, b.y - a.y) } }
function angleMix(a: number, b: number, t: number) { let d = b - a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return a + d * t }
function triangulateBoundary(positions: number[], boundary: number[]): number[] {
  const cross = (a: number, b: number, c: number) => (positions[b * 2]! - positions[a * 2]!) * (positions[c * 2 + 1]! - positions[a * 2 + 1]!) - (positions[b * 2 + 1]! - positions[a * 2 + 1]!) * (positions[c * 2]! - positions[a * 2]!)
  const polygon = [...boundary], result: number[] = []
  for (let guard = 0; polygon.length > 3 && guard < boundary.length ** 2; guard++) {
    let clipped = false
    for (let i = 0; i < polygon.length; i++) {
      const a = polygon[(i + polygon.length - 1) % polygon.length]!, b = polygon[i]!, c = polygon[(i + 1) % polygon.length]!
      if (cross(a, b, c) < .0001) continue
      if (polygon.some(p => p !== a && p !== b && p !== c && cross(a, b, p) > -.0001 && cross(b, c, p) > -.0001 && cross(c, a, p) > -.0001)) continue
      result.push(a, b, c); polygon.splice(i, 1); clipped = true; break
    }
    if (!clipped) break
  }
  if (polygon.length === 3 && cross(polygon[0]!, polygon[1]!, polygon[2]!) > .0001) result.push(...polygon)
  return result
}
function smoothClothInterior(g: Geometry, boundary: number[], triangles: number[]) {
  const points = boundary.map(i => ({ x: g.positions[i * 2]!, y: g.positions[i * 2 + 1]! }))
  const sourceA = [...g.firstUV], sourceB = [...g.secondUV], count = points.length
  const interpolate = (p: Point, uv: number[]) => {
    const vectors = points.map(q => ({ x: q.x - p.x, y: q.y - p.y })), distances = vectors.map(q => Math.hypot(q.x, q.y))
    const nearest = distances.findIndex(d => d < .001)
    if (nearest >= 0) { const q = boundary[nearest]! * 2; return { x: uv[q]!, y: uv[q + 1]! } }
    for (let i = 0; i < count; i++) {
      const next = (i + 1) % count, a = points[i]!, b = points[next]!, dx = b.x - a.x, dy = b.y - a.y, length2 = dx * dx + dy * dy
      const t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / length2
      if (t >= 0 && t <= 1 && Math.abs((p.x - a.x) * dy - (p.y - a.y) * dx) < .001 * Math.sqrt(length2)) {
        const q = boundary[i]! * 2, r = boundary[next]! * 2
        return { x: mix(uv[q]!, uv[r]!, t), y: mix(uv[q + 1]!, uv[r + 1]!, t) }
      }
    }
    const tangents = vectors.map((v, i) => { const n = vectors[(i + 1) % count]!, cross = v.x * n.y - v.y * n.x, dot = distances[i]! * distances[(i + 1) % count]! + v.x * n.x + v.y * n.y; return cross / (Math.abs(dot) < .00001 ? Math.sign(dot || 1) * .00001 : dot) })
    let weights = distances.map((d, i) => (tangents[(i + count - 1) % count]! + tangents[i]!) / d)
    // Near a fully folded elbow, signed mean-value coordinates can cancel.
    // Positive coordinates retain a bounded, smooth cloth chart in that case.
    if (weights.some(w => w < -.00001)) weights = weights.map(Math.abs)
    const total = weights.reduce((a, b) => a + b, 0)
    let x = 0, y = 0
    for (let i = 0; i < count; i++) { const q = boundary[i]! * 2, w = weights[i]! / total; x += uv[q]! * w; y += uv[q + 1]! * w }
    return { x, y }
  }
  const subdivisions = 5
  for (let i = 0; i < triangles.length; i += 3) {
    const corners = triangles.slice(i, i + 3).map(q => ({ x: g.positions[q * 2]!, y: g.positions[q * 2 + 1]! })), rows: number[][] = []
    for (let u = 0; u <= subdivisions; u++) {
      const row: number[] = []
      for (let v = 0; v <= subdivisions - u; v++) {
        const s = u / subdivisions, t = v / subdivisions, p = { x: corners[0]!.x * (1 - s - t) + corners[1]!.x * s + corners[2]!.x * t, y: corners[0]!.y * (1 - s - t) + corners[1]!.y * s + corners[2]!.y * t }
        const a = interpolate(p, sourceA), b = interpolate(p, sourceB), index = g.positions.length / 2
        const ids = triangles.slice(i, i + 3), soft = g.softness![ids[0]!]! * (1 - s - t) + g.softness![ids[1]!]! * s + g.softness![ids[2]!]! * t
        g.positions.push(p.x, p.y); g.firstUV.push(a.x, a.y); g.secondUV.push(b.x, b.y); g.coverage!.push(1); g.softness!.push(soft); row.push(index)
      }
      rows.push(row)
    }
    for (let u = 0; u < subdivisions; u++) for (let v = 0; v < subdivisions - u; v++) {
      g.indices.push(rows[u]![v]!, rows[u + 1]![v]!, rows[u]![v + 1]!)
      if (v < subdivisions - u - 1) g.indices.push(rows[u + 1]![v]!, rows[u + 1]![v + 1]!, rows[u]![v + 1]!)
    }
  }
}
export function targetJoints(config: KeyConfig, progress: number): Joints {
  const p = clamp(progress, 0, 1), keys = config.keyforms
  let high = keys.findIndex(k => k.progress >= p); if (high < 0) high = keys.length - 1
  const b = keys[high]!, a = keys[Math.max(0, high - 1)]!, t = a === b ? 0 : (p - a.progress) / (b.progress - a.progress), ja = jointsFor(a), jb = jointsFor(b)
  const out = { shoulder: { ...config.baseShoulder } } as Joints
  for (let k = 1; k < names.length; k++) { const n = names[k]!, prev = names[k - 1]!, ba = bone(ja[prev], ja[n]), bb = bone(jb[prev], jb[n]), angle = angleMix(ba.angle, bb.angle, t), length = mix(ba.length, bb.length, t); out[n] = { x: out[prev].x + Math.cos(angle) * length, y: out[prev].y + Math.sin(angle) * length } }
  return out
}
function image(url: string) { return new Promise<HTMLImageElement>((resolve, reject) => { const im = new Image(); im.onload = () => resolve(im); im.onerror = () => reject(Error('无法加载手臂素材：' + url)); im.src = url }) }
function program(gl: WebGL2RenderingContext, vertex: string, fragment: string) { const p = gl.createProgram()!; for (const [kind, code] of [[gl.VERTEX_SHADER, vertex], [gl.FRAGMENT_SHADER, fragment]] as const) { const s = gl.createShader(kind)!; gl.shaderSource(s, code); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(s) || 'Shader compile'); gl.attachShader(p, s); gl.deleteShader(s) } gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw Error(gl.getProgramInfoLog(p) || 'Shader link'); return p }
const vertex = `#version 300 es
precision highp float;
in vec2 position;in vec2 firstUV;in vec2 secondUV;in float coverage;in float softness;
uniform vec2 view;out vec2 uvA;out vec2 uvB;out float opacity;out float soften;
void main(){uvA=firstUV;uvB=secondUV;opacity=coverage;soften=softness;vec2 p=position/view;gl_Position=vec4(2.*p.x-1.,1.-2.*p.y,0.,1.);}`
const fragment = `#version 300 es
precision highp float;
in vec2 uvA;in vec2 uvB;in float opacity;in float soften;uniform sampler2D first;uniform sampler2D second;uniform vec2 imageSize;uniform float blend;uniform bool garment;out vec4 color;
vec4 cloth(sampler2D tex,vec2 uv){
 vec4 c=texture(tex,uv);if(c.a>.92)return vec4(c.rgb/c.a,1.);
 // Padding only extends existing garment texels into the authored panel boundary.
 vec4 best=c;float offsets[6]=float[6](2.,4.,8.,16.,32.,64.);
 for(int k=0;k<6;k++){float r=offsets[k];for(int q=0;q<8;q++){float a=float(q)*.785398163;vec4 n=texture(tex,uv+vec2(cos(a),sin(a))*r/imageSize);if(n.a>best.a)best=n;}if(best.a>.92)break;}
 if(best.a>.01)return vec4(best.rgb/best.a,1.);return vec4(0.);
}
vec4 softCloth(sampler2D tex,vec2 uv){
 vec4 c=cloth(tex,uv);if(soften<.001)return c;
 vec2 r=vec2(25.)/imageSize;vec4 smoothColor=(c*4.+cloth(tex,uv+vec2(r.x,0.))+cloth(tex,uv-vec2(r.x,0.))+cloth(tex,uv+vec2(0.,r.y))+cloth(tex,uv-vec2(0.,r.y)))/8.;
 return mix(c,smoothColor,min(soften,1.));
}
void main(){if(garment){vec4 a=softCloth(first,uvA),b=softCloth(second,uvB);color=mix(a,b,blend)*opacity;}else{color=texture(first,uvA);}}
`
export class ArmSkin {
  readonly gl: WebGL2RenderingContext
  private shader: WebGLProgram
  private vao: WebGLVertexArrayObject
  private buffers: WebGLBuffer[]
  private forms: Form[] = []
  private hands: HandArt[] = []
  private handDiagnostics: ReturnType<typeof handGeometry>['diagnostics'] | null = null
  private diagnostics = { progress: 0, weights: [] as { id: string; weight: number }[], nonFinite: 0, uvOutside: 0, uvBounds: [0, 0, 0, 0], foldedTriangles: 0, triangles: 0, missing: [] as string[], joints: {} as Joints, clothBend: { upper: 0, fore: 0 }, topology: 'torso-pinned shoulder bridge, continuous rounded elbow cloth with bounded interior UVs and opaque padded cloth charts, existing natural hand and wrist roll' }
  constructor(readonly canvas: HTMLCanvasElement, readonly config: KeyConfig) {
    const gl = canvas.getContext('webgl2', { alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, antialias: true }); if (!gl) throw Error('WebGL2 unavailable')
    this.gl = gl; this.shader = program(gl, vertex, fragment); this.vao = gl.createVertexArray()!; this.buffers = Array.from({ length: 6 }, () => gl.createBuffer()!)
  }
  private texture(im: HTMLImageElement) { const gl = this.gl, tex = gl.createTexture()!; gl.bindTexture(gl.TEXTURE_2D, tex); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, im); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); return tex }
  private clothTexture(rgba: Uint8ClampedArray) {
    const [w, h] = this.config.canvas, size = w * h, nearest = new Int32Array(size).fill(-1), queue = new Int32Array(size)
    let head = 0, tail = 0
    // Use only interior cloth as padding seeds. The painted silhouette ink is
    // not a seam and must not be stretched across the inside of a bent elbow.
    for (let y = 4; y < h - 4; y++) for (let x = 4; x < w - 4; x++) {
      const q = y * w + x
      if ([q, q - 4, q + 4, q - w * 4, q + w * 4].every(i => rgba[i * 4 + 3]! > 245)) { nearest[q] = q; queue[tail++] = q }
    }
    if (!tail) throw Error('Sleeve has no interior cloth pixels')
    while (head < tail) {
      const q = queue[head++]!, x = q % w
      for (const n of [x > 0 ? q - 1 : -1, x < w - 1 ? q + 1 : -1, q >= w ? q - w : -1, q < size - w ? q + w : -1]) if (n >= 0 && nearest[n] === -1) { nearest[n] = nearest[q]!; queue[tail++] = n }
    }
    const padded = new Uint8Array(size * 4)
    for (let i = 0; i < size; i++) { const q = nearest[i]! * 4; padded[i * 4] = rgba[q]!; padded[i * 4 + 1] = rgba[q + 1]!; padded[i * 4 + 2] = rgba[q + 2]!; padded[i * 4 + 3] = 255 }
    const gl = this.gl, texture = gl.createTexture()!
    gl.bindTexture(gl.TEXTURE_2D, texture); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, padded)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
    return texture
  }
  private pixels(im: HTMLImageElement) { const c = document.createElement('canvas'); [c.width, c.height] = this.config.canvas; const ctx = c.getContext('2d')!; ctx.drawImage(im, 0, 0, c.width, c.height); return ctx.getImageData(0, 0, c.width, c.height).data }
  private alpha(rgba: Uint8ClampedArray, p: Point) { const [w, h] = this.config.canvas, x = Math.round(clamp(p.x, 0, w - 1)), y = Math.round(clamp(p.y, 0, h - 1)); return rgba[(y * w + x) * 4 + 3]! }
  private span(rgba: Uint8ClampedArray, a: Point, b: Point, t: number, min: number, max: number): Span {
    const { n } = axis(a, b), center = lerp(a, b, t)
    let low = 0, high = 0
    // Find the contiguous authored sleeve run nearest the anatomical centreline.
    const runs: [number, number][] = []; let begin: number | null = null
    for (let q = -120; q <= 120; q++) { const filled = this.alpha(rgba, add(center, mul(n, q))) > 100; if (filled && begin === null) begin = q; if ((!filled || q === 120) && begin !== null) { runs.push([begin, filled ? q : q - 1]); begin = null } }
    if (runs.length) { const chosen = runs.sort((x, y) => Math.max(0, x[0], -x[1]) - Math.max(0, y[0], -y[1]))[0]!; [low, high] = chosen }
    if (high - low < 8) { low = -min; high = min }
    // Keep source UVs just inside ink/alpha boundaries; shared geometry owns coverage.
    const negative = clamp(-low, min, max), positive = clamp(high, min, max)
    const left = add(center, mul(n, -negative + 4)), right = add(center, mul(n, positive - 4))
    return { left, right, negative, positive }
  }
  private sourcePanel(rgba: Uint8ClampedArray, j: Joints, kind: 'upper' | 'fore') {
    const a = kind === 'upper' ? j.shoulder : j.elbow, b = kind === 'upper' ? j.elbow : j.wrist
    const spans = Array.from({ length: SECTIONS + 1 }, (_, i) => this.span(rgba, a, b, i / SECTIONS, kind === 'upper' ? 28 : 25, kind === 'upper' ? 64 : 68))
    if (kind === 'upper' && j.wrist.y < 300) {
      // The raised forearm overlaps this scanline. It must not count as upper
      // sleeve width or get squeezed into the upper sleeve's UV range.
      for (let i = 0; i <= SECTIONS; i++) {
        const center = lerp(a, b, i / SECTIONS), span = spans[i]!
        span.negative = Math.min(span.negative, 53)
        span.left = add(center, mul(axis(a, b).n, -span.negative + 4))
      }
    }
    if (kind === 'fore') {
      // The anatomical wrist may lie above the visible cuff; use actual painted cuff edges.
      const cuff: [Point, Point] = b.y > 800 ? [{x:548,y:935},{x:493,y:935}] : b.y > 400 ? [{x:405,y:540},{x:462,y:515}] : [{x:540,y:253},{x:596,y:246}]
      for (let i=0;i<=SECTIONS;i++){const blend=ease((i/SECTIONS-.80)/.20);spans[i]!.left=lerp(spans[i]!.left,cuff[0],blend);spans[i]!.right=lerp(spans[i]!.right,cuff[1],blend)}
    }
    return spans
  }
  async load(urlFor: (name: string) => string) {
    const missing: string[] = [], forms: Form[] = []
    for (const key of this.config.keyforms) { try { if (!key.sleeveImage) throw Error('Sleeve missing'); const im = await image(urlFor(key.sleeveImage)), rgba = this.pixels(im), joints = jointsFor(key); forms.push({ key, joints, texture: this.clothTexture(rgba), rgba, upper: this.sourcePanel(rgba, joints, 'upper'), fore: this.sourcePanel(rgba, joints, 'fore') }) } catch { missing.push(key.id) } }
    const hands: HandArt[] = []
    for (const key of this.config.keyforms) {
      try {
        if (!key.handImage) throw Error('Hand missing')
        const hand = await image(urlFor(key.handImage))
        hands.push(createHandArt(key as HandDescriptor, this.texture(hand), this.pixels(hand), ...this.config.canvas))
      } catch { missing.push('hand-' + key.id) }
    }
    if (this.config.handEdge) {
      const edge = this.config.handEdge
      const imageData = await image(urlFor(edge.image))
      const reference = this.config.keyforms.find(k => k.id === 'head') ?? this.config.keyforms.at(-1)!
      const key: HandDescriptor = { ...reference, id: 'edge', handImage: edge.image, handSourceJoints: { ...edge.sourceJoints, thumb: edge.thumb } }
      hands.push(createHandArt(key, this.texture(imageData), this.pixels(imageData), ...this.config.canvas))
    }
    for (const f of this.forms) this.gl.deleteTexture(f.texture)
    for (const hand of this.hands) this.gl.deleteTexture(hand.texture)
    this.forms = forms; this.hands = hands; this.diagnostics.missing = missing
    if (hands.length !== this.config.keyforms.length + (this.config.handEdge ? 1 : 0)) throw Error('垂手、手背或掌面素材未加载齐')
    if (!forms.length) throw Error('袖子素材未加载')
    return { loaded: forms.map(f => f.key.id), missing }
  }
  private panel(a: Form, b: Form, target: Joints, kind: 'upper' | 'fore', t: number, material?: Form, bend = 0, root?: ShoulderRoot, artwork?: { first: Form; second: Form }): Geometry {
    const one = kind === 'upper' ? a.upper : a.fore, two = kind === 'upper' ? b.upper : b.fore, start = kind === 'upper' ? target.shoulder : target.elbow, end = kind === 'upper' ? target.elbow : target.wrist, { n } = axis(start, end), g: Geometry = { positions: [], firstUV: [], secondUV: [], indices: [] }
    // Both edges share the same normal displacement; their longitudinal projection
    // stays strictly ordered while shoulder, elbow and cuff endpoints stay fixed.
    for (let i = 0; i <= SECTIONS; i++) { const s = i / SECTIONS, x = one[i]!, y = two[i]!, center = add(lerp(start, end, s), mul(n, Math.sin(Math.PI * s) * bend)); let negative = mix(x.negative, y.negative, t), positive = mix(x.positive, y.positive, t)
      // Width is measured in drawing pixels, never stretched by the changing bone length.
      if (kind === 'fore') { const cuff = ease((s - .70) / .30); negative = mix(negative, 27, cuff); positive = mix(positive, 27, cuff) }
      for (const p of [add(center, mul(n, -negative)), add(center, mul(n, positive))]) g.positions.push(p.x, p.y)
      const materialSpan = material ? (kind === 'upper' ? material.upper : material.fore)[i]! : null
      for (const [span, uv] of [[materialSpan ?? artwork?.first.upper[i] ?? x, g.firstUV], [materialSpan ?? artwork?.second.upper[i] ?? y, g.secondUV]] as const) uv.push(span.left.x, span.left.y, span.right.x, span.right.y)
      if (i < SECTIONS) { const q = i * 2; g.indices.push(q, q + 2, q + 1, q + 1, q + 2, q + 3) }
    }
    if (kind === 'upper' && root) {
      // A continuous sleeve root opens from two points on the actual torso.
      // Its long low-pose bridge keeps the underarm below the outgoing ring;
      // the high pose uses the painted raised-sleeve folds instead of a cap.
      const direction = axis(start, end).d
      const bridgeEnd = mix(12, 8, ease((Math.abs(direction.x) - .3) / .7))
      const sourceRoots = (form: Form): ShoulderRoot => form.key.id === 'head'
        ? { outer: { x: 453, y: 374 }, inner: { x: 437, y: 530 } }
        : form.key.id === 'chest'
        ? { outer: { x: 444, y: 404 }, inner: { x: 444, y: 510 } }
        : { outer: { x: 443, y: 400 }, inner: { x: 403, y: 554 } }
      const bridge = (rows: number[], anchors: ShoulderRoot) => {
        const point = (ring: number, side: number) => {
          const low = Math.floor(ring), high = Math.min(SECTIONS, low + 1), t = ring - low, a = low * 4 + side * 2, b = high * 4 + side * 2
          return { x: mix(rows[a]!, rows[b]!, t), y: mix(rows[a + 1]!, rows[b + 1]!, t) }
        }
        for (const [side, anchor] of [[0, anchors.outer], [1, anchors.inner]] as const) {
          const finish = point(bridgeEnd, side), next = point(bridgeEnd + 1, side)
          const c1 = lerp(anchor, finish, 1 / 3), c2 = { x: finish.x - (next.x - finish.x) * bridgeEnd / 3, y: finish.y - (next.y - finish.y) * bridgeEnd / 3 }
          for (let i = 0; i < bridgeEnd; i++) {
            const u = i / bridgeEnd, v = 1 - u, index = i * 4 + side * 2
            rows[index] = v ** 3 * anchor.x + 3 * v * v * u * c1.x + 3 * v * u * u * c2.x + u ** 3 * finish.x
            rows[index + 1] = v ** 3 * anchor.y + 3 * v * v * u * c1.y + 3 * v * u * u * c2.y + u ** 3 * finish.y
          }
        }
      }
      bridge(g.positions, root); bridge(g.firstUV, sourceRoots(material ?? artwork?.first ?? a)); bridge(g.secondUV, sourceRoots(material ?? artwork?.second ?? b))
      g.coverage = Array.from({ length: (SECTIONS + 1) * 2 }, (_, i) => i === 1 ? 0 : 1)
    }
    return g
  }
  private sleeve(a: Form, b: Form, target: Joints, t: number, bend: ClothBend, root: ShoulderRoot | undefined, first: Form, second: Form, soften: number): Geometry {
    const upper = this.panel(a, b, target, 'upper', t, undefined, bend.upper, root, { first, second })
    const fore = this.panel(a, b, target, 'fore', t, undefined, bend.fore)
    fore.firstUV = first.fore.flatMap(s => [s.left.x, s.left.y, s.right.x, s.right.y])
    fore.secondUV = second.fore.flatMap(s => [s.left.x, s.left.y, s.right.x, s.right.y])
    // The elbow is a band of the same cloth, with one shared cross-section.
    // Round both the destination and the artwork coordinates. Independent quads
    // or a cap here expose the straight end of one panel over the other.
    const join = (u: number[], f: number[], joints: Joints, source = false) => {
      const up = axis(joints.shoulder, joints.elbow), low = axis(joints.elbow, joints.wrist)
      const cross = up.d.x * low.d.y - up.d.y * low.d.x
      const dot = up.d.x * low.d.x + up.d.y * low.d.y
      const cutU = 10, cutF = 6, rows: number[] = u.slice(0, cutU * 4)
      const point = (data: number[], ring: number, side: number) => ({ x: data[ring * 4 + side * 2]!, y: data[ring * 4 + side * 2 + 1]! })
      const controls = [0, 1].map(side => {
        const start = point(u, cutU, side), end = point(f, cutF, side)
        const edgeU = point(u, SECTIONS, side), edgeF = point(f, 0, side)
        const delta = { x: edgeF.x - edgeU.x, y: edgeF.y - edgeU.y }
        const distance = Math.abs(cross) > .03 ? (delta.x * low.d.y - delta.y * low.d.x) / cross : 0
        const intersection = add(edgeU, mul(up.d, distance))
        const maxReach = source ? Math.min(up.length * .52, low.length * .66, 105) : Math.min(up.length, low.length) * .32
        const offset = { x: intersection.x - joints.elbow.x, y: intersection.y - joints.elbow.y }
        const reach = Math.hypot(offset.x, offset.y)
        const inner = (cross > 0) === (side === 1)
        const nx = up.n.x + low.n.x, ny = up.n.y + low.n.y, normalLength = Math.hypot(nx, ny)
        const width = (Math.hypot(edgeU.x - joints.elbow.x, edgeU.y - joints.elbow.y) + Math.hypot(edgeF.x - joints.elbow.x, edgeF.y - joints.elbow.y)) * .5
        const outward = normalLength > .001 ? { x: nx / normalLength * (side ? 1 : -1), y: ny / normalLength * (side ? 1 : -1) } : up.d
        let middle = inner ? add(joints.elbow, mul(offset, Math.min(1, maxReach / Math.max(1, reach)))) : source ? lerp(edgeU, edgeF, .5) : add(joints.elbow, mul(outward, width * .92))
        if (dot > .92) middle = lerp(edgeU, edgeF, .5)
        const arc = Math.min(38, Math.hypot(start.x - end.x, start.y - end.y) * .26)
        return { start, end, middle, arc, inner, tangent: axis(start, end).d }
      })
      const cubic = (a: Point, b: Point, c: Point, d: Point, t: number) => { const s = 1 - t; return { x: s ** 3 * a.x + 3 * s * s * t * b.x + 3 * s * t * t * c.x + t ** 3 * d.x, y: s ** 3 * a.y + 3 * s * s * t * b.y + 3 * s * t * t * c.y + t ** 3 * d.y } }
      for (let ring = 0; ring <= 12; ring++) for (const c of controls) {
        const q = ring / 12, c1 = c.inner ? lerp(c.start, c.middle, 1 / 3) : add(c.start, mul(up.d, c.arc)), c2 = c.inner ? lerp(c.middle, c.end, 2 / 3) : add(c.end, mul(low.d, -c.arc))
        const p = q <= .5
          ? cubic(c.start, c1, c.inner ? lerp(c.start, c.middle, .86) : add(c.middle, mul(c.tangent, -c.arc)), c.middle, q * 2)
          : cubic(c.middle, c.inner ? lerp(c.middle, c.end, .14) : add(c.middle, mul(c.tangent, c.arc)), c2, c.end, q * 2 - 1)
        rows.push(p.x, p.y)
      }
      rows.push(...f.slice((cutF + 1) * 4))
      return rows
    }
    const g: Geometry = { positions: join(upper.positions, fore.positions, target), firstUV: join(upper.firstUV, fore.firstUV, first.joints, true), secondUV: join(upper.secondUV, fore.secondUV, second.joints, true), indices: [] }
    const rings = g.positions.length / 4
    for (let i = 0; i < rings - 1; i++) { if (i >= 10 && i < 22) continue; const q = i * 2; g.indices.push(q, q + 2, q + 1, q + 1, q + 2, q + 3) }
    const boundary = [...Array.from({ length: 13 }, (_, i) => (10 + i) * 2), ...Array.from({ length: 13 }, (_, i) => (22 - i) * 2 + 1)]
    g.coverage = Array.from({ length: rings * 2 }, (_, i) => i === 1 && root ? 0 : 1)
    g.softness = Array.from({ length: rings * 2 }, (_, i) => Math.sin(Math.PI * clamp((Math.floor(i / 2) - 6) / 20, 0, 1)) * soften)
    smoothClothInterior(g, boundary, triangulateBoundary(g.positions, boundary))
    return g
  }
  private drawGeometry(g: Geometry, first: WebGLTexture, second: WebGLTexture, blend: number, garment: boolean) {
    const gl = this.gl, [w, h] = this.config.canvas; let bad = 0, folded = 0, outside = 0
    const pos = g.positions.map((v, i) => v + this.config.playbackOffset[i % 2]!), uvA = g.firstUV.map((v, i) => v / (i % 2 ? h : w)), uvB = g.secondUV.map((v, i) => v / (i % 2 ? h : w))
    for (const v of pos) if (!Number.isFinite(v)) bad++
    const bounds = [Infinity, Infinity, -Infinity, -Infinity]
    for (const uv of [g.firstUV, g.secondUV]) for (let i = 0; i < uv.length; i += 2) {
      const x = uv[i]!, y = uv[i + 1]!
      if (!Number.isFinite(x)) bad++; if (!Number.isFinite(y)) bad++
      if (x < 0 || x > w || y < 0 || y > h) outside++
      bounds[0] = Math.min(bounds[0]!, x); bounds[1] = Math.min(bounds[1]!, y); bounds[2] = Math.max(bounds[2]!, x); bounds[3] = Math.max(bounds[3]!, y)
    }
    for (let i = 0; i < g.indices.length; i += 3) { const a = g.indices[i]! * 2, b = g.indices[i + 1]! * 2, c = g.indices[i + 2]! * 2; if ((pos[b]! - pos[a]!) * (pos[c + 1]! - pos[a + 1]!) - (pos[b + 1]! - pos[a + 1]!) * (pos[c]! - pos[a]!) < -.001) folded++ }
    gl.bindVertexArray(this.vao)
    for (const [i, name, data] of [[0, 'position', pos], [1, 'firstUV', uvA], [2, 'secondUV', uvB]] as const) { gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[i]!); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data), gl.DYNAMIC_DRAW); const loc = gl.getAttribLocation(this.shader, name); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0) }
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[4]!); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(g.coverage ?? Array(pos.length / 2).fill(1)), gl.DYNAMIC_DRAW); const opacity = gl.getAttribLocation(this.shader, 'coverage'); gl.enableVertexAttribArray(opacity); gl.vertexAttribPointer(opacity, 1, gl.FLOAT, false, 0, 0)
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[5]!); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(g.softness ?? Array(pos.length / 2).fill(0)), gl.DYNAMIC_DRAW); const softness = gl.getAttribLocation(this.shader, 'softness'); gl.enableVertexAttribArray(softness); gl.vertexAttribPointer(softness, 1, gl.FLOAT, false, 0, 0)
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.buffers[3]!); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(g.indices), gl.DYNAMIC_DRAW); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, first); gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, second); gl.uniform1f(gl.getUniformLocation(this.shader, 'blend'), blend); gl.uniform1i(gl.getUniformLocation(this.shader, 'garment'), Number(garment)); gl.drawElements(gl.TRIANGLES, g.indices.length, gl.UNSIGNED_SHORT, 0)
    return { bad, folded, outside, bounds, count: g.indices.length / 3 }
  }
  draw(progress: number, view: { width: number; height: number }, options: { part?: 'all' | 'sleeve' | 'hand'; materialId?: string; upperMaterialId?: string; joints?: Joints; clothBend?: ClothBend; viewport?: [number, number, number, number]; shoulderRoot?: ShoulderRoot } = {}) {
    if (!this.forms.length) return this.diagnostics
    const gl = this.gl, p = clamp(progress, 0, 1), target = options.joints ?? targetJoints(this.config, p)
    let high = this.forms.findIndex(f => f.key.progress >= p); if (high < 0) high = this.forms.length - 1
    const b = this.forms[high]!, a = this.forms[Math.max(0, high - 1)]!, raw = a === b ? 0 : (p - a.key.progress) / (b.key.progress - a.key.progress), t = ease(raw), part = options.part ?? 'all', upperMaterial = this.forms.find(f => f.key.id === (options.upperMaterialId ?? options.materialId))
    const bend: ClothBend = { upper: Number.isFinite(options.clothBend?.upper) ? clamp(options.clothBend!.upper, -8, 8) : 0, fore: Number.isFinite(options.clothBend?.fore) ? clamp(options.clothBend!.fore, -8, 8) : 0 }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(...(options.viewport ?? [0, 0, this.canvas.width, this.canvas.height])); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT); gl.useProgram(this.shader); gl.uniform2f(gl.getUniformLocation(this.shader, 'view'), view.width, view.height); gl.uniform2f(gl.getUniformLocation(this.shader, 'imageSize'), ...this.config.canvas); gl.uniform1i(gl.getUniformLocation(this.shader, 'first'), 0); gl.uniform1i(gl.getUniformLocation(this.shader, 'second'), 1); gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA)
    let nonFinite = 0, foldedTriangles = 0, triangles = 0, uvOutside = 0
    const uvBounds = [Infinity, Infinity, -Infinity, -Infinity]
    const draw = (g: Geometry, first: WebGLTexture, second = first, blend = 0, garment = true) => { const d = this.drawGeometry(g, first, second, blend, garment); nonFinite += d.bad; foldedTriangles += d.folded; triangles += d.count; uvOutside += d.outside; for (let i = 0; i < 4; i++) uvBounds[i] = i < 2 ? Math.min(uvBounds[i]!, d.bounds[i]!) : Math.max(uvBounds[i]!, d.bounds[i]!) }
    if (part !== 'hand') {
      // Chest artwork has a removed-hand cut through its upper sleeve. Keep
      // its pose geometry, but sample only clean rest/raised upper cloth.
      const upperArtwork = { first: this.forms.find(f => f.key.id === 'down') ?? a, second: this.forms.find(f => f.key.id === 'head') ?? b }
      const upperBlend = ease((p - .38) / .62)
      const first = upperMaterial ?? upperArtwork.first, second = upperMaterial ?? upperArtwork.second
      const soften = .9 * ease(p / .2) * (1 - ease((p - .7) / .3))
      draw(this.sleeve(a, b, target, t, bend, options.shoulderRoot, first, second, soften), first.texture, second.texture, upperMaterial ? 0 : upperBlend)
    }
    if (part !== 'sleeve') {
      const handView = selectHandView(p, this.hands), art = this.hands.find(h => h.id === handView.sourceId) ?? this.hands[0]!
      const hand = handGeometry(art, this.hands, target, p, handView)
      draw(hand.geometry, art.texture, art.texture, 0, false); this.handDiagnostics = hand.diagnostics
    }
    this.diagnostics = { ...this.diagnostics, progress: p, weights: [{ id: a.key.id, weight: 1 - t }, { id: b.key.id, weight: t }], nonFinite, uvOutside, uvBounds, foldedTriangles, triangles, joints: target, clothBend: bend }
    return this.diagnostics
  }
  inspect() { return { ...this.diagnostics, hand: this.handDiagnostics, webglError: this.gl.getError() } }
}
