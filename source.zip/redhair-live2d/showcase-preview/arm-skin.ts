import { createHandArt, handGeometry, selectHandView, type HandArt, type HandDescriptor } from './hand'
export type Point = { x: number; y: number }
export type JointName = 'shoulder' | 'elbow' | 'wrist' | 'palm'
export type Joints = Record<JointName, Point>
export type ClothBend = { upper: number; fore: number }
export type KeyDescriptor = { id: string; progress: number; image: string; handImage?: string; sleeveImage?: string; sourceJoints: Record<JointName, [number, number]>; handSourceJoints?: { wrist: [number, number]; palm: [number, number]; thumb?: [number, number] } }
export type KeyConfig = { canvas: [number, number]; playbackOffset: [number, number]; baseShoulder: Point; keyforms: KeyDescriptor[]; handEdge?: { image: string; sourceJoints: { wrist: [number, number]; palm: [number, number] }; thumb?: [number, number] } }
type Span = { left: Point; right: Point; negative: number; positive: number }
type Form = { key: KeyDescriptor; joints: Joints; texture: WebGLTexture; rgba: Uint8ClampedArray; upper: Span[]; fore: Span[] }
type Geometry = { positions: number[]; firstUV: number[]; secondUV: number[]; indices: number[]; coverage?: number[] }
export type ShoulderRoot = { outer: Point; inner: Point }
const names: JointName[] = ['shoulder', 'elbow', 'wrist', 'palm']
const SECTIONS = 16
const mix = (a: number, b: number, t: number) => a + (b - a) * t
const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x))
const ease = (x: number) => { const t = clamp(x, 0, 1); return t * t * (3 - 2 * t) }
const lerp = (a: Point, b: Point, t: number): Point => ({ x: mix(a.x, b.x, t), y: mix(a.y, b.y, t) })
const add = (a: Point, b: Point): Point => ({ x: a.x + b.x, y: a.y + b.y })
const mul = (a: Point, s: number): Point => ({ x: a.x * s, y: a.y * s })
function axis(a: Point, b: Point) { const length = Math.hypot(b.x - a.x, b.y - a.y); const d = { x: (b.x - a.x) / length, y: (b.y - a.y) / length }; return { length, d, n: { x: -d.y, y: d.x } } }
export function jointsFor(key: KeyDescriptor): Joints { return Object.fromEntries(names.map(n => [n, { x: key.sourceJoints[n][0], y: key.sourceJoints[n][1] }])) as Joints }
function bone(a: Point, b: Point) { return { angle: Math.atan2(b.y - a.y, b.x - a.x), length: Math.hypot(b.x - a.x, b.y - a.y) } }
function angleMix(a: number, b: number, t: number) { let d = b - a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return a + d * t }
export function targetJoints(config: KeyConfig, progress: number): Joints {
  const p = clamp(progress, 0, 1), keys = config.keyforms
  let high = keys.findIndex(k => k.progress >= p); if (high < 0) high = keys.length - 1
  const b = keys[high]!, a = keys[Math.max(0, high - 1)]!, t = a === b ? 0 : (p - a.progress) / (b.progress - a.progress), ja = jointsFor(a), jb = jointsFor(b)
  const out = { shoulder: { ...config.baseShoulder } } as Joints
  for (let k = 1; k < names.length; k++) { const n = names[k]!, prev = names[k - 1]!, ba = bone(ja[prev], ja[n]), bb = bone(jb[prev], jb[n]), angle = angleMix(ba.angle, bb.angle, t), length = mix(ba.length, bb.length, t); out[n] = { x: out[prev].x + Math.cos(angle) * length, y: out[prev].y + Math.sin(angle) * length } }
  return out
}
function image(url: string) { return new Promise<HTMLImageElement>((resolve, reject) => { const im = new Image(); im.onload = () => resolve(im); im.onerror = () => reject(Error('无法加载手臂素材：' + url)); im.src = url }) }
function program(gl: WebGL2RenderingContext, vertex: string, fragment: string) { const p = gl.createProgram()!; for (const [kind, code] of [[gl.VERTEX_SHADER, vertex], [gl.FRAGMENT_SHADER, fragment]] as const) { const s = gl.createShader(kind)!; gl.shaderSource(s, code); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(s) || 'Shader compile'); gl.attachShader(p, s); gl.deleteShader(s) } gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw Error(gl.getProgramInfoLog(p) || 'Shader link'); return p }
const vertex = `#version 300 es
precision highp float;
in vec2 position;in vec2 firstUV;in vec2 secondUV;in float coverage;
uniform vec2 view;out vec2 uvA;out vec2 uvB;out float opacity;
void main(){uvA=firstUV;uvB=secondUV;opacity=coverage;vec2 p=position/view;gl_Position=vec4(2.*p.x-1.,1.-2.*p.y,0.,1.);}`
const fragment = `#version 300 es
precision highp float;
in vec2 uvA;in vec2 uvB;in float opacity;uniform sampler2D first;uniform sampler2D second;uniform vec2 imageSize;uniform float blend;uniform bool garment;out vec4 color;
vec4 cloth(sampler2D tex,vec2 uv){
 vec4 c=texture(tex,uv);if(c.a>.92)return vec4(c.rgb/c.a,1.);
 // Padding only extends existing garment texels into the authored panel boundary.
 vec4 best=c;float offsets[6]=float[6](2.,4.,8.,16.,32.,64.);
 for(int k=0;k<6;k++){float r=offsets[k];for(int q=0;q<8;q++){float a=float(q)*.785398163;vec4 n=texture(tex,uv+vec2(cos(a),sin(a))*r/imageSize);if(n.a>best.a)best=n;}if(best.a>.92)break;}
 if(best.a>.01)return vec4(best.rgb/best.a,1.);return vec4(0.);
}
void main(){if(garment){vec4 a=cloth(first,uvA),b=cloth(second,uvB);color=mix(a,b,blend)*opacity;}else{color=texture(first,uvA);}}
`
export class ArmSkin {
  readonly gl: WebGL2RenderingContext
  private shader: WebGLProgram
  private vao: WebGLVertexArrayObject
  private buffers: WebGLBuffer[]
  private forms: Form[] = []
  private hands: HandArt[] = []
  private handDiagnostics: ReturnType<typeof handGeometry>['diagnostics'] | null = null
  private diagnostics = { progress: 0, weights: [] as { id: string; weight: number }[], nonFinite: 0, uvOutside: 0, uvBounds: [0, 0, 0, 0], foldedTriangles: 0, clothBackFacingTriangles: 0, handFoldedTriangles: 0, triangles: 0, missing: [] as string[], joints: {} as Joints, clothBend: { upper: 0, fore: 0 }, topology: 'curved torso-pinned roots; one down cloth field over continuous longitudinal cross-sections; double-sided cloth self-overlap; original natural hand and wrist roll' }
  constructor(readonly canvas: HTMLCanvasElement, readonly config: KeyConfig) {
    const gl = canvas.getContext('webgl2', { alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, antialias: true }); if (!gl) throw Error('WebGL2 unavailable')
    this.gl = gl; this.shader = program(gl, vertex, fragment); this.vao = gl.createVertexArray()!; this.buffers = Array.from({ length: 5 }, () => gl.createBuffer()!)
  }
  private texture(im: HTMLImageElement) { const gl = this.gl, tex = gl.createTexture()!; gl.bindTexture(gl.TEXTURE_2D, tex); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, im); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); return tex }
  private clothTexture(rgba: Uint8ClampedArray) {
    const [w, h] = this.config.canvas, size = w * h, nearest = new Int32Array(size).fill(-1), queue = new Int32Array(size)
    let head = 0, tail = 0
    // Use only interior cloth as padding seeds. The painted silhouette ink is
    // not a seam and must not be stretched across the inside of a bent elbow.
    for (let y = 4; y < h - 4; y++) for (let x = 4; x < w - 4; x++) {
      const q = y * w + x
      if ([q, q - 4, q + 4, q - w * 4, q + w * 4].every(i => rgba[i * 4 + 3]! > 245)) { nearest[q] = q; queue[tail++] = q }
    }
    if (!tail) throw Error('Sleeve has no interior cloth pixels')
    while (head < tail) {
      const q = queue[head++]!, x = q % w
      for (const n of [x > 0 ? q - 1 : -1, x < w - 1 ? q + 1 : -1, q >= w ? q - w : -1, q < size - w ? q + w : -1]) if (n >= 0 && nearest[n] === -1) { nearest[n] = nearest[q]!; queue[tail++] = n }
    }
    const padded = new Uint8Array(size * 4)
    for (let i = 0; i < size; i++) { const q = nearest[i]! * 4; padded[i * 4] = rgba[q]!; padded[i * 4 + 1] = rgba[q + 1]!; padded[i * 4 + 2] = rgba[q + 2]!; padded[i * 4 + 3] = 255 }
    const gl = this.gl, texture = gl.createTexture()!
    gl.bindTexture(gl.TEXTURE_2D, texture); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, padded)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
    return texture
  }
  private pixels(im: HTMLImageElement) { const c = document.createElement('canvas'); [c.width, c.height] = this.config.canvas; const ctx = c.getContext('2d')!; ctx.drawImage(im, 0, 0, c.width, c.height); return ctx.getImageData(0, 0, c.width, c.height).data }
  private alpha(rgba: Uint8ClampedArray, p: Point) { const [w, h] = this.config.canvas, x = Math.round(clamp(p.x, 0, w - 1)), y = Math.round(clamp(p.y, 0, h - 1)); return rgba[(y * w + x) * 4 + 3]! }
  private span(rgba: Uint8ClampedArray, a: Point, b: Point, t: number, min: number, max: number): Span {
    const { n } = axis(a, b), center = lerp(a, b, t)
    let low = 0, high = 0
    // Find the contiguous authored sleeve run nearest the anatomical centreline.
    const runs: [number, number][] = []; let begin: number | null = null
    for (let q = -120; q <= 120; q++) { const filled = this.alpha(rgba, add(center, mul(n, q))) > 100; if (filled && begin === null) begin = q; if ((!filled || q === 120) && begin !== null) { runs.push([begin, filled ? q : q - 1]); begin = null } }
    if (runs.length) { const chosen = runs.sort((x, y) => Math.max(0, x[0], -x[1]) - Math.max(0, y[0], -y[1]))[0]!; [low, high] = chosen }
    if (high - low < 8) { low = -min; high = min }
    // Keep source UVs just inside ink/alpha boundaries; shared geometry owns coverage.
    const negative = clamp(-low, min, max), positive = clamp(high, min, max)
    const left = add(center, mul(n, -negative + 4)), right = add(center, mul(n, positive - 4))
    return { left, right, negative, positive }
  }
  private sourcePanel(rgba: Uint8ClampedArray, j: Joints, kind: 'upper' | 'fore') {
    const a = kind === 'upper' ? j.shoulder : j.elbow, b = kind === 'upper' ? j.elbow : j.wrist
    const spans = Array.from({ length: SECTIONS + 1 }, (_, i) => this.span(rgba, a, b, i / SECTIONS, kind === 'upper' ? 28 : 25, kind === 'upper' ? 64 : 68))
    if (kind === 'upper' && j.wrist.y < 300) {
      // The raised forearm overlaps this scanline. It must not count as upper
      // sleeve width or get squeezed into the upper sleeve's UV range.
      for (let i = 0; i <= SECTIONS; i++) {
        const center = lerp(a, b, i / SECTIONS), span = spans[i]!
        span.negative = Math.min(span.negative, 53)
        span.left = add(center, mul(axis(a, b).n, -span.negative + 4))
      }
    }
    if (kind === 'fore') {
      // The anatomical wrist may lie above the visible cuff; use actual painted cuff edges.
      const cuff: [Point, Point] = b.y > 800 ? [{x:548,y:935},{x:493,y:935}] : b.y > 400 ? [{x:405,y:540},{x:462,y:515}] : [{x:540,y:253},{x:596,y:246}]
      for (let i=0;i<=SECTIONS;i++){const blend=ease((i/SECTIONS-.80)/.20);spans[i]!.left=lerp(spans[i]!.left,cuff[0],blend);spans[i]!.right=lerp(spans[i]!.right,cuff[1],blend)}
    }
    return spans
  }
  async load(urlFor: (name: string) => string) {
    const missing: string[] = [], forms: Form[] = []
    for (const key of this.config.keyforms) { try { if (!key.sleeveImage) throw Error('Sleeve missing'); const im = await image(urlFor(key.sleeveImage)), rgba = this.pixels(im), joints = jointsFor(key); forms.push({ key, joints, texture: this.clothTexture(rgba), rgba, upper: this.sourcePanel(rgba, joints, 'upper'), fore: this.sourcePanel(rgba, joints, 'fore') }) } catch { missing.push(key.id) } }
    const hands: HandArt[] = []
    for (const key of this.config.keyforms) {
      try {
        if (!key.handImage) throw Error('Hand missing')
        const hand = await image(urlFor(key.handImage))
        hands.push(createHandArt(key as HandDescriptor, this.texture(hand), this.pixels(hand), ...this.config.canvas))
      } catch { missing.push('hand-' + key.id) }
    }
    if (this.config.handEdge) {
      const edge = this.config.handEdge
      const imageData = await image(urlFor(edge.image))
      const reference = this.config.keyforms.find(k => k.id === 'head') ?? this.config.keyforms.at(-1)!
      const key: HandDescriptor = { ...reference, id: 'edge', handImage: edge.image, handSourceJoints: { ...edge.sourceJoints, thumb: edge.thumb } }
      hands.push(createHandArt(key, this.texture(imageData), this.pixels(imageData), ...this.config.canvas))
    }
    for (const f of this.forms) this.gl.deleteTexture(f.texture)
    for (const hand of this.hands) this.gl.deleteTexture(hand.texture)
    this.forms = forms; this.hands = hands; this.diagnostics.missing = missing
    if (hands.length !== this.config.keyforms.length + (this.config.handEdge ? 1 : 0)) throw Error('垂手、手背或掌面素材未加载齐')
    if (!forms.length) throw Error('袖子素材未加载')
    return { loaded: forms.map(f => f.key.id), missing }
  }
  private panel(a: Form, b: Form, target: Joints, kind: 'upper' | 'fore', t: number, material?: Form, bend = 0, root?: ShoulderRoot, artwork?: { first: Form; second: Form }): Geometry {
    const one = kind === 'upper' ? a.upper : a.fore, two = kind === 'upper' ? b.upper : b.fore, start = kind === 'upper' ? target.shoulder : target.elbow, end = kind === 'upper' ? target.elbow : target.wrist, { n } = axis(start, end), g: Geometry = { positions: [], firstUV: [], secondUV: [], indices: [] }
    // Both edges share the same normal displacement; their longitudinal projection
    // stays strictly ordered while shoulder, elbow and cuff endpoints stay fixed.
    for (let i = 0; i <= SECTIONS; i++) { const s = i / SECTIONS, x = one[i]!, y = two[i]!, center = add(lerp(start, end, s), mul(n, Math.sin(Math.PI * s) * bend)); let negative = mix(x.negative, y.negative, t), positive = mix(x.positive, y.positive, t)
      // Width is measured in drawing pixels, never stretched by the changing bone length.
      if (kind === 'fore') { const cuff = ease((s - .70) / .30); negative = mix(negative, 27, cuff); positive = mix(positive, 27, cuff) }
      const raised = kind === 'upper' ? ease((Math.abs(axis(start, end).d.x) - .3) / .7) : 0
      const bow = Math.sin(Math.PI * s) * raised
      for (const p of [add(center, mul(n, -negative - 20 * bow)), add(center, mul(n, positive + 9 * bow))]) g.positions.push(p.x, p.y)
      const materialSpan = material ? (kind === 'upper' ? material.upper : material.fore)[i]! : null
      for (const [span, uv] of [[materialSpan ?? artwork?.first.upper[i] ?? x, g.firstUV], [materialSpan ?? artwork?.second.upper[i] ?? y, g.secondUV]] as const) uv.push(span.left.x, span.left.y, span.right.x, span.right.y)
      if (i < SECTIONS) { const q = i * 2; g.indices.push(q, q + 2, q + 1, q + 1, q + 2, q + 3) }
    }
    if (kind === 'upper' && root) {
      // A continuous sleeve root opens from two points on the actual torso.
      // Its long low-pose bridge keeps the underarm below the outgoing ring;
      // the high pose uses the painted raised-sleeve folds instead of a cap.
      const direction = axis(start, end).d
      const bridgeEnd = mix(12, 8, ease((Math.abs(direction.x) - .3) / .7))
      const sourceRoots = (form: Form): ShoulderRoot => form.key.id === 'head'
        ? { outer: { x: 453, y: 374 }, inner: { x: 437, y: 530 } }
        : form.key.id === 'chest'
        ? { outer: { x: 444, y: 404 }, inner: { x: 444, y: 510 } }
        : { outer: { x: 443, y: 400 }, inner: { x: 403, y: 554 } }
      const bridge = (rows: number[], anchors: ShoulderRoot) => {
        const point = (ring: number, side: number) => {
          const low = Math.floor(ring), high = Math.min(SECTIONS, low + 1), t = ring - low, a = low * 4 + side * 2, b = high * 4 + side * 2
          return { x: mix(rows[a]!, rows[b]!, t), y: mix(rows[a + 1]!, rows[b + 1]!, t) }
        }
        for (const [side, anchor] of [[0, anchors.outer], [1, anchors.inner]] as const) {
          const finish = point(bridgeEnd, side), next = point(bridgeEnd + 1, side)
          const raised = ease((Math.abs(direction.x) - .25) / .75)
          const c1 = side === 0 ? { x: anchor.x + mix(9, 20, raised), y: anchor.y + 28 } : { x: anchor.x + mix(14, 40, raised), y: anchor.y + mix(30, 22, raised) }, c2 = { x: finish.x - (next.x - finish.x) * bridgeEnd / 3, y: finish.y - (next.y - finish.y) * bridgeEnd / 3 }
          for (let i = 0; i < bridgeEnd; i++) {
            const u = i / bridgeEnd, v = 1 - u, index = i * 4 + side * 2
            rows[index] = v ** 3 * anchor.x + 3 * v * v * u * c1.x + 3 * v * u * u * c2.x + u ** 3 * finish.x
            rows[index + 1] = v ** 3 * anchor.y + 3 * v * v * u * c1.y + 3 * v * u * u * c2.y + u ** 3 * finish.y
          }
        }
      }
      bridge(g.positions, root); bridge(g.firstUV, sourceRoots(material ?? artwork?.first ?? a)); bridge(g.secondUV, sourceRoots(material ?? artwork?.second ?? b))
      g.coverage = Array.from({ length: (SECTIONS + 1) * 2 }, (_, i) => i === 1 ? 0 : 1)
    }
    return g
  }
  private sleeve(a: Form, b: Form, target: Joints, t: number, bend: ClothBend, root: ShoulderRoot | undefined, first: Form, lateralStrain: number): Geometry {
    const upper = this.panel(a, b, target, 'upper', t, undefined, bend.upper, root, { first, second: first })
    const fore = this.panel(a, b, target, 'fore', t, undefined, bend.fore)
    // The elbow is a band of the same cloth, with one shared cross-section.
    // Round both the destination and the artwork coordinates. Independent quads
    // or a cap here expose the straight end of one panel over the other.
    const join = (u: number[], f: number[], joints: Joints, source = false) => {
      const up = axis(joints.shoulder, joints.elbow), low = axis(joints.elbow, joints.wrist)
      const cross = up.d.x * low.d.y - up.d.y * low.d.x
      const dot = up.d.x * low.d.x + up.d.y * low.d.y
      const cutU = 10, cutF = 6, rows: number[] = u.slice(0, cutU * 4)
      const point = (data: number[], ring: number, side: number) => ({ x: data[ring * 4 + side * 2]!, y: data[ring * 4 + side * 2 + 1]! })
      const controls = [0, 1].map(side => {
        const start = point(u, cutU, side), end = point(f, cutF, side)
        const edgeU = point(u, SECTIONS, side), edgeF = point(f, 0, side)
        const delta = { x: edgeF.x - edgeU.x, y: edgeF.y - edgeU.y }
        const distance = Math.abs(cross) > .03 ? (delta.x * low.d.y - delta.y * low.d.x) / cross : 0
        const intersection = add(edgeU, mul(up.d, distance))
        const maxReach = source ? Math.min(up.length * .52, low.length * .66, 105) : Math.min(up.length, low.length) * .32
        const offset = { x: intersection.x - joints.elbow.x, y: intersection.y - joints.elbow.y }
        const reach = Math.hypot(offset.x, offset.y)
        const inner = (cross > 0) === (side === 1)
        const nx = up.n.x + low.n.x, ny = up.n.y + low.n.y, normalLength = Math.hypot(nx, ny)
        const width = (Math.hypot(edgeU.x - joints.elbow.x, edgeU.y - joints.elbow.y) + Math.hypot(edgeF.x - joints.elbow.x, edgeF.y - joints.elbow.y)) * .5
        const outward = normalLength > .001 ? { x: nx / normalLength * (side ? 1 : -1), y: ny / normalLength * (side ? 1 : -1) } : up.d
        let middle = inner ? add(joints.elbow, mul(offset, Math.min(1, maxReach / Math.max(1, reach)))) : source ? lerp(edgeU, edgeF, .5) : add(joints.elbow, mul(outward, width * .92))
        if (dot > .92) middle = lerp(edgeU, edgeF, .5)
        const arc = Math.min(38, Math.hypot(start.x - end.x, start.y - end.y) * .26)
        return { start, end, middle, arc, inner, tangent: axis(start, end).d }
      })
      const cubic = (a: Point, b: Point, c: Point, d: Point, t: number) => { const s = 1 - t; return { x: s ** 3 * a.x + 3 * s * s * t * b.x + 3 * s * t * t * c.x + t ** 3 * d.x, y: s ** 3 * a.y + 3 * s * s * t * b.y + 3 * s * t * t * c.y + t ** 3 * d.y } }
      for (let ring = 0; ring <= 12; ring++) for (const c of controls) {
        const q = ring / 12, c1 = add(c.start, mul(up.d, c.inner ? Math.min(14, c.arc) : c.arc)), c2 = add(c.end, mul(low.d, -(c.inner ? Math.min(14, c.arc) : c.arc)))
        const p = q <= .5
          ? cubic(c.start, c1, c.inner ? lerp(c.start, c.middle, .86) : add(c.middle, mul(c.tangent, -c.arc)), c.middle, q * 2)
          : cubic(c.middle, c.inner ? lerp(c.middle, c.end, .14) : add(c.middle, mul(c.tangent, c.arc)), c2, c.end, q * 2 - 1)
        rows.push(p.x, p.y)
      }
      rows.push(...f.slice((cutF + 1) * 4))
      return rows
    }
    const edges = join(upper.positions, fore.positions, target)
    // One rest-pose cloth field runs along every cross-section. A folded
    // sleeve can overlap itself, but its UVs never jump to a different pose.
    const sourceUpper = this.panel(first, first, first.joints, 'upper', 0, first, 0,
      { outer: { x: 443, y: 400 }, inner: { x: 403, y: 554 } })
    const sourceRows = [...sourceUpper.firstUV.slice(0, SECTIONS * 4)]
    const elbow = first.upper.at(-1)!, foreElbow = first.fore[0]!
    for (const side of ['left', 'right'] as const) { const p = lerp(elbow[side], foreElbow[side], .5); sourceRows.push(p.x, p.y) }
    for (let i = 1; i <= SECTIONS; i++) { const s = first.fore[i]!; sourceRows.push(s.left.x, s.left.y, s.right.x, s.right.y) }
    const rows = 80, columns = 12, g: Geometry = { positions: [], firstUV: [], secondUV: [], indices: [], coverage: [] }
    const section = (data: number[], s: number, v: number) => {
      const ring = clamp(s * SECTIONS * 2, 0, SECTIONS * 2), low = Math.floor(ring), high = Math.min(SECTIONS * 2, low + 1), t = ring - low
      const left = { x: mix(data[low * 4]!, data[high * 4]!, t), y: mix(data[low * 4 + 1]!, data[high * 4 + 1]!, t) }
      const right = { x: mix(data[low * 4 + 2]!, data[high * 4 + 2]!, t), y: mix(data[low * 4 + 3]!, data[high * 4 + 3]!, t) }
      return lerp(left, right, v)
    }
    for (let row = 0; row <= rows; row++) for (let column = 0; column <= columns; column++) {
      const s = row / rows, v = column / columns, p = section(edges, s, v)
      const strain = ease((s - .36) / .18) * (1 - ease((s - .87) / .11)) * lateralStrain
      const uv = section(sourceRows, s, mix(v, .22 + .56 * v, strain))
      const arch = Math.sin(Math.PI * clamp((s - .3) / .48, 0, 1)) * Math.sin(Math.PI * v) * 20
      const direction = axis(target.elbow, target.wrist).d
      p.x += direction.x * arch; p.y += direction.y * arch
      g.positions.push(p.x, p.y); g.firstUV.push(uv.x, uv.y); g.secondUV.push(uv.x, uv.y)
      g.coverage!.push(root ? ease(s / .045) : 1)
      if (row < rows && column < columns) { const q = row * (columns + 1) + column; g.indices.push(q, q + columns + 1, q + 1, q + 1, q + columns + 1, q + columns + 2) }
    }
    return g
  }
  private drawGeometry(g: Geometry, first: WebGLTexture, second: WebGLTexture, blend: number, garment: boolean) {
    const gl = this.gl, [w, h] = this.config.canvas; let bad = 0, folded = 0, outside = 0
    const pos = g.positions.map((v, i) => v + this.config.playbackOffset[i % 2]!), uvA = g.firstUV.map((v, i) => v / (i % 2 ? h : w)), uvB = g.secondUV.map((v, i) => v / (i % 2 ? h : w))
    for (const v of pos) if (!Number.isFinite(v)) bad++
    const bounds = [Infinity, Infinity, -Infinity, -Infinity]
    for (const uv of [g.firstUV, g.secondUV]) for (let i = 0; i < uv.length; i += 2) {
      const x = uv[i]!, y = uv[i + 1]!
      if (!Number.isFinite(x)) bad++; if (!Number.isFinite(y)) bad++
      if (x < 0 || x > w || y < 0 || y > h) outside++
      bounds[0] = Math.min(bounds[0]!, x); bounds[1] = Math.min(bounds[1]!, y); bounds[2] = Math.max(bounds[2]!, x); bounds[3] = Math.max(bounds[3]!, y)
    }
    for (let i = 0; i < g.indices.length; i += 3) { const a = g.indices[i]! * 2, b = g.indices[i + 1]! * 2, c = g.indices[i + 2]! * 2; if ((pos[b]! - pos[a]!) * (pos[c + 1]! - pos[a + 1]!) - (pos[b + 1]! - pos[a + 1]!) * (pos[c]! - pos[a]!) < -.001) folded++ }
    gl.bindVertexArray(this.vao)
    for (const [i, name, data] of [[0, 'position', pos], [1, 'firstUV', uvA], [2, 'secondUV', uvB]] as const) { gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[i]!); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data), gl.DYNAMIC_DRAW); const loc = gl.getAttribLocation(this.shader, name); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0) }
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[4]!); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(g.coverage ?? Array(pos.length / 2).fill(1)), gl.DYNAMIC_DRAW); const opacity = gl.getAttribLocation(this.shader, 'coverage'); gl.enableVertexAttribArray(opacity); gl.vertexAttribPointer(opacity, 1, gl.FLOAT, false, 0, 0)
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.buffers[3]!); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(g.indices), gl.DYNAMIC_DRAW); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, first); gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, second); gl.uniform1f(gl.getUniformLocation(this.shader, 'blend'), blend); gl.uniform1i(gl.getUniformLocation(this.shader, 'garment'), Number(garment)); gl.drawElements(gl.TRIANGLES, g.indices.length, gl.UNSIGNED_SHORT, 0)
    return { bad, folded, outside, bounds, count: g.indices.length / 3 }
  }
  draw(progress: number, view: { width: number; height: number }, options: { part?: 'all' | 'sleeve' | 'hand'; materialId?: string; upperMaterialId?: string; joints?: Joints; clothBend?: ClothBend; viewport?: [number, number, number, number]; shoulderRoot?: ShoulderRoot } = {}) {
    if (!this.forms.length) return this.diagnostics
    const gl = this.gl, p = clamp(progress, 0, 1), target = options.joints ?? targetJoints(this.config, p)
    let high = this.forms.findIndex(f => f.key.progress >= p); if (high < 0) high = this.forms.length - 1
    const b = this.forms[high]!, a = this.forms[Math.max(0, high - 1)]!, raw = a === b ? 0 : (p - a.key.progress) / (b.key.progress - a.key.progress), t = ease(raw), part = options.part ?? 'all', upperMaterial = this.forms.find(f => f.key.id === (options.upperMaterialId ?? options.materialId))
    const bend: ClothBend = { upper: Number.isFinite(options.clothBend?.upper) ? clamp(options.clothBend!.upper, -8, 8) : 0, fore: Number.isFinite(options.clothBend?.fore) ? clamp(options.clothBend!.fore, -8, 8) : 0 }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(...(options.viewport ?? [0, 0, this.canvas.width, this.canvas.height])); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT); gl.useProgram(this.shader); gl.uniform2f(gl.getUniformLocation(this.shader, 'view'), view.width, view.height); gl.uniform2f(gl.getUniformLocation(this.shader, 'imageSize'), ...this.config.canvas); gl.uniform1i(gl.getUniformLocation(this.shader, 'first'), 0); gl.uniform1i(gl.getUniformLocation(this.shader, 'second'), 1); gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA)
    let nonFinite = 0, foldedTriangles = 0, triangles = 0, uvOutside = 0, clothBackFacingTriangles = 0, handFoldedTriangles = 0
    const uvBounds = [Infinity, Infinity, -Infinity, -Infinity]
    const draw = (g: Geometry, first: WebGLTexture, second = first, blend = 0, garment = true) => { const d = this.drawGeometry(g, first, second, blend, garment); nonFinite += d.bad; foldedTriangles += d.folded; if (garment) clothBackFacingTriangles += d.folded; else handFoldedTriangles += d.folded; triangles += d.count; uvOutside += d.outside; for (let i = 0; i < 4; i++) uvBounds[i] = i < 2 ? Math.min(uvBounds[i]!, d.bounds[i]!) : Math.max(uvBounds[i]!, d.bounds[i]!) }
    if (part !== 'hand') {
      // Chest artwork has a removed-hand cut through its upper sleeve. Keep
      // its pose geometry, but sample only clean rest/raised upper cloth.
      const material = upperMaterial ?? this.forms.find(f => f.key.id === 'down') ?? a
      draw(this.sleeve(a, b, target, t, bend, options.shoulderRoot, material, ease(p / .2)), material.texture)
    }
    if (part !== 'sleeve') {
      const handView = selectHandView(p, this.hands), art = this.hands.find(h => h.id === handView.sourceId) ?? this.hands[0]!
      const hand = handGeometry(art, this.hands, target, p, handView)
      draw(hand.geometry, art.texture, art.texture, 0, false); this.handDiagnostics = hand.diagnostics
    }
    this.diagnostics = { ...this.diagnostics, progress: p, weights: [{ id: a.key.id, weight: 1 - t }, { id: b.key.id, weight: t }], nonFinite, uvOutside, uvBounds, foldedTriangles, clothBackFacingTriangles, handFoldedTriangles, triangles, joints: target, clothBend: bend }
    return this.diagnostics
  }
  inspect() { return { ...this.diagnostics, hand: this.handDiagnostics, webglError: this.gl.getError() } }
}
