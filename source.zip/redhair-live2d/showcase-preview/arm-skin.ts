import { createNaturalCloth, naturalClothGeometry, naturalRootBridge, registeredClothMixGeometry, selectSleevePoses, type NaturalCloth, type SleevePoseDescriptor } from './natural-cloth'
import { createHandArt, handGeometry, selectHandView, type HandArt, type HandDescriptor } from './hand'
export type Point = { x: number; y: number }
export type JointName = 'shoulder' | 'elbow' | 'wrist' | 'palm'
export type Joints = Record<JointName, Point>
export type ClothBend = { upper: number; fore: number }
export type KeyDescriptor = { id: string; progress: number; image: string; handImage?: string; sleeveImage?: string; sourceJoints: Record<JointName, [number, number]>; handSourceJoints?: { wrist: [number, number]; palm: [number, number]; thumb?: [number, number] } }
export type KeyConfig = { canvas: [number, number]; playbackOffset: [number, number]; baseShoulder: Point; keyforms: KeyDescriptor[]; sleevePoses?: SleevePoseDescriptor[]; handEdge?: { image: string; sourceJoints: { wrist: [number, number]; palm: [number, number] }; thumb?: [number, number] } }
type Geometry = { positions: number[]; firstUV: number[]; secondUV: number[]; indices: number[]; coverage?: number[] }
export type ShoulderRoot = { outer: Point; inner: Point }
const names: JointName[] = ['shoulder', 'elbow', 'wrist', 'palm']
const mix = (a: number, b: number, t: number) => a + (b - a) * t
const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x))
export function jointsFor(key: KeyDescriptor): Joints { return Object.fromEntries(names.map(n => [n, { x: key.sourceJoints[n][0], y: key.sourceJoints[n][1] }])) as Joints }
function bone(a: Point, b: Point) { return { angle: Math.atan2(b.y - a.y, b.x - a.x), length: Math.hypot(b.x - a.x, b.y - a.y) } }
function angleMix(a: number, b: number, t: number) { let d = b - a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return a + d * t }
export function targetJoints(config: KeyConfig, progress: number): Joints {
  const p = clamp(progress, 0, 1), keys = config.keyforms
  let high = keys.findIndex(k => k.progress >= p); if (high < 0) high = keys.length - 1
  const b = keys[high]!, a = keys[Math.max(0, high - 1)]!, t = a === b ? 0 : (p - a.progress) / (b.progress - a.progress), ja = jointsFor(a), jb = jointsFor(b)
  const out = { shoulder: { ...config.baseShoulder } } as Joints
  for (let k = 1; k < names.length; k++) { const n = names[k]!, prev = names[k - 1]!, ba = bone(ja[prev], ja[n]), bb = bone(jb[prev], jb[n]), angle = angleMix(ba.angle, bb.angle, t), length = mix(ba.length, bb.length, t); out[n] = { x: out[prev].x + Math.cos(angle) * length, y: out[prev].y + Math.sin(angle) * length } }
  return out
}
function image(url: string) { return new Promise<HTMLImageElement>((resolve, reject) => { const im = new Image(); im.onload = () => resolve(im); im.onerror = () => reject(Error('无法加载手臂素材：' + url)); im.src = url }) }
function program(gl: WebGL2RenderingContext, vertex: string, fragment: string) { const p = gl.createProgram()!; for (const [kind, code] of [[gl.VERTEX_SHADER, vertex], [gl.FRAGMENT_SHADER, fragment]] as const) { const s = gl.createShader(kind)!; gl.shaderSource(s, code); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(s) || 'Shader compile'); gl.attachShader(p, s); gl.deleteShader(s) } gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw Error(gl.getProgramInfoLog(p) || 'Shader link'); return p }
const vertex = `#version 300 es
precision highp float;
in vec2 position;in vec2 firstUV;in vec2 secondUV;in float coverage;
uniform vec2 view;out vec2 uvA;out vec2 uvB;out float opacity;
void main(){uvA=firstUV;uvB=secondUV;opacity=coverage;vec2 p=position/view;gl_Position=vec4(2.*p.x-1.,1.-2.*p.y,0.,1.);}`
const fragment = `#version 300 es
precision highp float;
in vec2 uvA;in vec2 uvB;in float opacity;
uniform sampler2D first;uniform sampler2D second;uniform float blend;uniform bool garment;out vec4 color;
void main(){
 if(!garment){color=texture(first,uvA);return;}
 vec4 a=texture(first,uvA),b=texture(second,uvB);float alpha=mix(a.a,b.a,blend);
 // The registered silhouettes coincide. Keep cloth opaque where the two
 // paintings disagree only about an internal overlap/occlusion boundary.
 float coverage=mix(alpha,max(a.a,b.a),4.*blend*(1.-blend));
 vec3 rgb=mix(a.rgb,b.rgb,blend)/max(alpha,.000001);
 color=vec4(rgb*coverage,coverage)*opacity;
}`
type RenderTarget = { framebuffer: WebGLFramebuffer; texture: WebGLTexture; width: number; height: number }
export class ArmSkin {
  readonly gl: WebGL2RenderingContext
  private shader: WebGLProgram
  private vao: WebGLVertexArrayObject
  private buffers: WebGLBuffer[]
  private sleeves: NaturalCloth[] = []
  private hands: HandArt[] = []
  private targets: RenderTarget[] = []
  private handDiagnostics: ReturnType<typeof handGeometry>['diagnostics'] | null = null
  private diagnostics = { progress: 0, weights: [] as { id: string; weight: number }[], nonFinite: 0, uvOutside: 0, uvBounds: [0, 0, 0, 0], foldedTriangles: 0, clothBackFacingTriangles: 0, handFoldedTriangles: 0, triangles: 0, missing: [] as string[], joints: {} as Joints, clothBend: { upper: 0, fore: 0 }, topology: 'native alpha sleeve paintings; local two-bone registration; short premultiplied framebuffer handovers; original hand articulation' }
  constructor(readonly canvas: HTMLCanvasElement, readonly config: KeyConfig) {
    const gl = canvas.getContext('webgl2', { alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, antialias: true }); if (!gl) throw Error('WebGL2 unavailable')
    this.gl = gl; this.shader = program(gl, vertex, fragment); this.vao = gl.createVertexArray()!; this.buffers = Array.from({ length: 5 }, () => gl.createBuffer()!)
  }
  private texture(im: HTMLImageElement) { const gl = this.gl, tex = gl.createTexture()!; gl.bindTexture(gl.TEXTURE_2D, tex); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, im); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); return tex }
  private pixels(im: HTMLImageElement) { const c = document.createElement('canvas'); [c.width, c.height] = this.config.canvas; const ctx = c.getContext('2d')!; ctx.drawImage(im, 0, 0, c.width, c.height); return ctx.getImageData(0, 0, c.width, c.height).data }
  private renderTarget(index: number, width = this.canvas.width, height = this.canvas.height) {
    const gl = this.gl, old = this.targets[index]
    if (old && old.width === width && old.height === height) return old
    if (old) { gl.deleteFramebuffer(old.framebuffer); gl.deleteTexture(old.texture) }
    const texture = gl.createTexture()!, framebuffer = gl.createFramebuffer()!
    gl.bindTexture(gl.TEXTURE_2D, texture); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
    gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0)
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw Error('Sleeve framebuffer unavailable')
    return this.targets[index] = { framebuffer, texture, width, height }
  }
  async load(urlFor: (name: string) => string) {
    const missing: string[] = [], sleeves: NaturalCloth[] = []
    const descriptors = this.config.sleevePoses ?? this.config.keyforms.map(key => ({ id: key.id, progress: key.progress, sleeveImage: key.sleeveImage!, sourceJoints: key.sourceJoints }))
    for (const descriptor of descriptors) {
      try { const im = await image(urlFor(descriptor.sleeveImage)), rgba = this.pixels(im); sleeves.push(createNaturalCloth(descriptor, this.texture(im), rgba, ...this.config.canvas)) } catch { missing.push(descriptor.id) }
    }
    const hands: HandArt[] = []
    for (const key of this.config.keyforms) {
      try {
        if (!key.handImage) throw Error('Hand missing')
        const hand = await image(urlFor(key.handImage))
        hands.push(createHandArt(key as HandDescriptor, this.texture(hand), this.pixels(hand), ...this.config.canvas))
      } catch { missing.push('hand-' + key.id) }
    }
    if (this.config.handEdge) {
      const edge = this.config.handEdge
      const imageData = await image(urlFor(edge.image))
      const reference = this.config.keyforms.find(k => k.id === 'head') ?? this.config.keyforms.at(-1)!
      const key: HandDescriptor = { ...reference, id: 'edge', handImage: edge.image, handSourceJoints: { ...edge.sourceJoints, thumb: edge.thumb } }
      hands.push(createHandArt(key, this.texture(imageData), this.pixels(imageData), ...this.config.canvas))
    }

    for (const sleeve of this.sleeves) this.gl.deleteTexture(sleeve.texture)
    for (const hand of this.hands) this.gl.deleteTexture(hand.texture)
    this.sleeves = sleeves.sort((a, b) => a.descriptor.progress - b.descriptor.progress); this.hands = hands; this.diagnostics.missing = missing
    if (hands.length !== this.config.keyforms.length + (this.config.handEdge ? 1 : 0)) throw Error('垂手、手背或掌面素材未加载齐')
    if (!sleeves.length) throw Error('自然袖子关键图未加载')
    return { loaded: sleeves.map(f => f.descriptor.id), missing }
  }
  private drawGeometry(g: Geometry, first: WebGLTexture, second: WebGLTexture, blend: number, garment: boolean) {
    const gl = this.gl, [w, h] = this.config.canvas; let bad = 0, folded = 0, outside = 0
    const pos = g.positions.map((v, i) => v + this.config.playbackOffset[i % 2]!), uvA = g.firstUV.map((v, i) => v / (i % 2 ? h : w)), uvB = g.secondUV.map((v, i) => v / (i % 2 ? h : w))
    for (const v of pos) if (!Number.isFinite(v)) bad++
    const bounds = [Infinity, Infinity, -Infinity, -Infinity]
    for (const uv of [g.firstUV, g.secondUV]) for (let i = 0; i < uv.length; i += 2) {
      const x = uv[i]!, y = uv[i + 1]!
      if (!Number.isFinite(x)) bad++; if (!Number.isFinite(y)) bad++
      if (x < 0 || x > w || y < 0 || y > h) outside++
      bounds[0] = Math.min(bounds[0]!, x); bounds[1] = Math.min(bounds[1]!, y); bounds[2] = Math.max(bounds[2]!, x); bounds[3] = Math.max(bounds[3]!, y)
    }
    for (let i = 0; i < g.indices.length; i += 3) { const a = g.indices[i]! * 2, b = g.indices[i + 1]! * 2, c = g.indices[i + 2]! * 2; if ((pos[b]! - pos[a]!) * (pos[c + 1]! - pos[a + 1]!) - (pos[b + 1]! - pos[a + 1]!) * (pos[c]! - pos[a]!) < -.001) folded++ }
    gl.bindVertexArray(this.vao)
    for (const [i, name, data] of [[0, 'position', pos], [1, 'firstUV', uvA], [2, 'secondUV', uvB]] as const) { gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[i]!); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data), gl.DYNAMIC_DRAW); const loc = gl.getAttribLocation(this.shader, name); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0) }
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[4]!); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(g.coverage ?? Array(pos.length / 2).fill(1)), gl.DYNAMIC_DRAW); const opacity = gl.getAttribLocation(this.shader, 'coverage'); gl.enableVertexAttribArray(opacity); gl.vertexAttribPointer(opacity, 1, gl.FLOAT, false, 0, 0)
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.buffers[3]!); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(g.indices), gl.DYNAMIC_DRAW); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, first); gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, second); gl.uniform1f(gl.getUniformLocation(this.shader, 'blend'), blend); gl.uniform1i(gl.getUniformLocation(this.shader, 'garment'), Number(garment)); gl.drawElements(gl.TRIANGLES, g.indices.length, gl.UNSIGNED_SHORT, 0)
    return { bad, folded, outside, bounds, count: g.indices.length / 3 }
  }

  draw(progress: number, view: { width: number; height: number }, options: { part?: 'all' | 'sleeve' | 'hand'; materialId?: string; upperMaterialId?: string; joints?: Joints; clothBend?: ClothBend; viewport?: [number, number, number, number]; shoulderRoot?: ShoulderRoot } = {}) {
    if (!this.sleeves.length) return this.diagnostics
    const gl = this.gl, p = clamp(progress, 0, 1), target = options.joints ?? targetJoints(this.config, p), part = options.part ?? 'all', selection = selectSleevePoses(this.sleeves, p)
    const viewport: [number, number, number, number] = options.viewport ?? [0, 0, this.canvas.width, this.canvas.height]
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(...viewport); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT); gl.useProgram(this.shader)
    gl.uniform2f(gl.getUniformLocation(this.shader, 'view'), view.width, view.height); gl.uniform1i(gl.getUniformLocation(this.shader, 'first'), 0); gl.uniform1i(gl.getUniformLocation(this.shader, 'second'), 1)
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA)
    let nonFinite = 0, foldedTriangles = 0, triangles = 0, uvOutside = 0, clothBackFacingTriangles = 0, handFoldedTriangles = 0
    const uvBounds = [Infinity, Infinity, -Infinity, -Infinity]
    const draw = (g: Geometry, texture: WebGLTexture, garment: boolean) => {
      const d = this.drawGeometry(g, texture, texture, 0, garment); nonFinite += d.bad; foldedTriangles += d.folded; triangles += d.count; uvOutside += d.outside
      if (garment) clothBackFacingTriangles += d.folded; else handFoldedTriangles += d.folded
      for (let i = 0; i < 4; i++) uvBounds[i] = i < 2 ? Math.min(uvBounds[i]!, d.bounds[i]!) : Math.max(uvBounds[i]!, d.bounds[i]!)
    }
    const drawPose = (pose: NaturalCloth, registration?: { other: NaturalCloth; blend: number }) => { const bridge = naturalRootBridge(pose, target, options.shoulderRoot); if (bridge) draw(bridge, pose.texture, true); draw(naturalClothGeometry(pose, target, options.shoulderRoot, registration), pose.texture, true) }
    if (part !== 'hand') {
      // Use the same contour/compositing path on both sides of a handover.
      // Switching between direct drawing and mask resampling at its endpoints
      // made even a continuous blend show a small silhouette jump.
      const paired = selection.first !== selection.second
      const first = this.renderTarget(0), second = paired ? this.renderTarget(1) : first
      const paints = paired ? [[selection.first, first], [selection.second, second]] as const : [[selection.first, first]] as const
      for (const [pose, destination] of paints) {
        gl.bindFramebuffer(gl.FRAMEBUFFER, destination.framebuffer); gl.viewport(...viewport); gl.clear(gl.COLOR_BUFFER_BIT)
        drawPose(pose, paired ? { other: pose === selection.first ? selection.second : selection.first, blend: pose === selection.first ? selection.blend : 1 - selection.blend } : undefined)
      }
      const [ox, oy] = this.config.playbackOffset, [iw, ih] = this.config.canvas, w = this.canvas.width, h = this.canvas.height, mw = 160, mh = 224
      const uv = [0, ih, iw, ih, 0, 0, iw, 0], masks: Uint8Array[] = []
      for (const [index, source] of (paired ? [first, second] : [first]).entries()) {
        const mask = this.renderTarget(index + 2, mw, mh)
        gl.bindFramebuffer(gl.FRAMEBUFFER, mask.framebuffer); gl.viewport(0, 0, mw, mh); gl.uniform2f(gl.getUniformLocation(this.shader, 'view'), mw, mh); gl.clear(gl.COLOR_BUFFER_BIT)
        this.drawGeometry({ positions: [-ox, -oy, mw - ox, -oy, -ox, mh - oy, mw - ox, mh - oy], firstUV: uv, secondUV: uv, indices: [0, 1, 2, 1, 3, 2] }, source.texture, source.texture, 0, true)
        const rgba = new Uint8Array(mw * mh * 4); gl.readPixels(0, 0, mw, mh, gl.RGBA, gl.UNSIGNED_BYTE, rgba); masks.push(rgba)
      }
      gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, w, h); gl.uniform2f(gl.getUniformLocation(this.shader, 'view'), w, h)
      const registered = registeredClothMixGeometry(masks[0]!, masks[1] ?? masks[0]!, mw, mh, w, h, iw, ih, this.config.playbackOffset, selection.blend, h - viewport[1] - viewport[3] + (target.wrist.y + oy) / view.height * viewport[3])
      const composite = this.drawGeometry(registered, first.texture, second.texture, selection.blend, true)
      nonFinite += composite.bad; uvOutside += composite.outside
      for (let i = 0; i < 4; i++) uvBounds[i] = i < 2 ? Math.min(uvBounds[i]!, composite.bounds[i]!) : Math.max(uvBounds[i]!, composite.bounds[i]!)
      gl.viewport(...viewport); gl.uniform2f(gl.getUniformLocation(this.shader, 'view'), view.width, view.height)
    }
    if (part !== 'sleeve') {
      const handView = selectHandView(p, this.hands), art = this.hands.find(h => h.id === handView.sourceId) ?? this.hands[0]!
      const hand = handGeometry(art, this.hands, target, p, handView)
      draw(hand.geometry, art.texture, false); this.handDiagnostics = hand.diagnostics
    }
    this.diagnostics = { ...this.diagnostics, progress: p, weights: [{ id: selection.first.descriptor.id, weight: 1 - selection.blend }, ...(selection.first === selection.second ? [] : [{ id: selection.second.descriptor.id, weight: selection.blend }])], nonFinite, uvOutside, uvBounds, foldedTriangles, clothBackFacingTriangles, handFoldedTriangles, triangles, joints: target, clothBend: options.clothBend ?? { upper: 0, fore: 0 } }
    return this.diagnostics
  }
  inspect() { return { ...this.diagnostics, hand: this.handDiagnostics, webglError: this.gl.getError() } }
}
