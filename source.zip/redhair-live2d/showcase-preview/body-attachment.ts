import type { Anime25DPlayer } from '../vendor/myriad-figure/src/anime25drig/index'
import type { Joints, Point, KeyConfig, ShoulderRoot } from './arm-skin'
type Inspection = ReturnType<Anime25DPlayer['inspect']>
type Pin = { triangle: number[], weights: number[], rest: Point }

function bind(rest: Float32Array, indices: Uint16Array, p: Point): Pin {
  let best = { outside: Infinity, triangle: [0, 0, 0], weights: [1, 0, 0], rest: p }
  for (let i = 0; i < indices.length; i += 3) {
    const a=indices[i]!,b=indices[i+1]!,c=indices[i+2]!,ax=rest[a*2]!,ay=rest[a*2+1]!,ex=rest[b*2]!-ax,ey=rest[b*2+1]!-ay,fx=rest[c*2]!-ax,fy=rest[c*2+1]!-ay,d=ex*fy-fx*ey
    if(Math.abs(d)<1e-9)continue
    const u=((p.x-ax)*fy-fx*(p.y-ay))/d,v=(ex*(p.y-ay)-(p.x-ax)*ey)/d,outside=Math.max(0,-u)+Math.max(0,-v)+Math.max(0,u+v-1)
    if(outside<best.outside)best={outside,triangle:[a,b,c],weights:[1-u-v,u,v],rest:p}
    if(outside===0)break
  }
  return best
}

/** Read the actual rendered torso, including its final body pitch/scale transform. */
export class BodyAttachment {
  private pins: Pin[]
  private layerName: string
  private last = { shoulder: { x: 0, y: 0 }, determinant: 1, attachmentError: 0 }
  private root: ShoulderRoot = { outer: { x: 451, y: 398 }, inner: { x: 401, y: 542 } }
  private affine = { s: { x: 0, y: 0 }, S: { x: 0, y: 0 }, a: 1, b: 0, c: 0, d: 1 }
  constructor(inspection: Inspection, private config: KeyConfig) {
    const layer=inspection.layers.find(l=>l.role==='topwear')!
    if(!layer)throw Error('衣身图层未加载')
    this.layerName=layer.name
    const s={x:config.baseShoulder.x+config.playbackOffset[0],y:config.baseShoulder.y+config.playbackOffset[1]}
    this.pins=[s,{x:s.x-100,y:s.y},{x:s.x-60,y:s.y+100},{x:451+config.playbackOffset[0],y:398},{x:401+config.playbackOffset[0],y:542}].map(p=>bind(layer.rest,layer.indices,p))
  }
  map(joints: Joints, inspection: Inspection): Joints {
    const layer=inspection.layers.find(l=>l.name===this.layerName)!
    const drawn=this.pins.map(pin=>{let x=0,y=0;for(let k=0;k<3;k++){x+=layer.placed[pin.triangle[k]!*2]!*pin.weights[k]!;y+=layer.placed[pin.triangle[k]!*2+1]!*pin.weights[k]!}return inspection.draw({x,y})})
    const [s,x,y]=this.pins.map(p=>p.rest) as [Point,Point,Point],[S,X,Y]=drawn as [Point,Point,Point]
    const ux=x.x-s.x,uy=x.y-s.y,vx=y.x-s.x,vy=y.y-s.y,det=ux*vy-vx*uy
    const a=((X.x-S.x)*vy-(Y.x-S.x)*uy)/det,b=((X.y-S.y)*vy-(Y.y-S.y)*uy)/det,c=((Y.x-S.x)*ux-(X.x-S.x)*vx)/det,d=((Y.y-S.y)*ux-(X.y-S.y)*vx)/det
    const out={} as Joints,offset=this.config.playbackOffset
    for(const name of ['shoulder','elbow','wrist','palm'] as const){
      // Local articulation follows the body, with its root pinned to the rendered shoulder.
      const dx=joints[name].x-joints.shoulder.x,dy=joints[name].y-joints.shoulder.y
      out[name]={x:S.x+a*dx+c*dy-offset[0],y:S.y+b*dx+d*dy-offset[1]}
    }
    this.last={shoulder:S,determinant:a*d-b*c,attachmentError:Math.hypot(out.shoulder.x+offset[0]-S.x,out.shoulder.y+offset[1]-S.y)}
    this.affine={s:{...joints.shoulder},S:{x:S.x-offset[0],y:S.y-offset[1]},a,b,c,d}
    this.root = { outer: { x: drawn[3]!.x - offset[0], y: drawn[3]!.y - offset[1] }, inner: { x: drawn[4]!.x - offset[0], y: drawn[4]!.y - offset[1] } }
    return out
  }
  inspect(){return this.last}
  sleeveRoot(){return this.root}
  /** The drawn torso's transform at the shoulder, in source coordinates, for whole-frame arm art. */
  attach(){return this.affine}
}
