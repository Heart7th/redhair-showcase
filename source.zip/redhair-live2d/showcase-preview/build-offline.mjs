import fs from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {build} from '../vendor/myriad-figure/node_modules/vite/dist/node/index.js'

const root=path.dirname(fileURLToPath(import.meta.url)),project=path.dirname(root)
const source=JSON.parse(await fs.readFile(path.join(project,'body-rig/rig-source-body.json'),'utf8'))
const config=JSON.parse(await fs.readFile(path.join(project,'shoulder-assets/arm-keyforms.json'),'utf8'))
function collectImages(value){
 if(Array.isArray(value))return value.flatMap(collectImages)
 if(!value||typeof value!=='object')return []
 return Object.entries(value).flatMap(([key,child])=>(key==='image'||key.endsWith('Image'))&&typeof child==='string'&&/\.(png|webp)$/.test(child)?[child]:collectImages(child))
}
// Generated arm frames covering the whole raise replace the painted sleeve rig and its textures.
const videoOnly=(config.videoArm?.timeline?.progress?.at(-1)??0)>=1
const imageNames=[...new Set(collectImages(videoOnly?{videoArm:config.videoArm,faceArt:config.faceArt}:config))]
const images={}
for(const name of imageNames){
 if(path.isAbsolute(name)||name.split(/[\\/]/).includes('..'))throw Error('Unexpected asset path: '+name)
 const image=await fs.readFile(path.join(project,'shoulder-assets',name))
 images[name]=(name.endsWith('.webp')?'data:image/webp;base64,':'data:image/png;base64,')+image.toString('base64')
}
const atlas=await fs.readFile(path.join(project,'preview/export/atlas.png'))
const result=await build({configFile:false,root,build:{target:'es2022',write:false,minify:true,lib:{entry:path.join(root,'offline.ts'),name:'RaisePreviewOffline',formats:['iife']},rolldownOptions:{output:{inlineDynamicImports:true}}}})
const code=(Array.isArray(result)?result.flatMap(r=>r.output):result.output).find(file=>file.type==='chunk').code
const input=await fs.readFile(path.join(root,'index.html'),'utf8')
const payload=JSON.stringify({source,config,images,atlas:'data:image/png;base64,'+atlas.toString('base64')}).replaceAll('<','\\u003c')
const html=input.replace(/<script type="module" src="\.\/main.ts"><\/script>/,'<script>window.__RAISE_PREVIEW__='+payload+';</script><script>'+code.replaceAll('</script','<\\/script')+'</script>')
const out=path.join(root,'export/index.html')
await fs.mkdir(path.dirname(out),{recursive:true});await fs.writeFile(out,html)
await fs.mkdir(path.join(root,'export/licenses'),{recursive:true})
await fs.copyFile(path.join(project,'vendor/myriad-figure/LICENSE'),path.join(root,'export/licenses/myriad-figure-LICENSE.txt'))
await fs.copyFile(path.join(project,'vendor/myriad-figure/src/anime25drig/vendor/NOTICE'),path.join(root,'export/licenses/myriad-figure-NOTICE.txt'))
await fs.copyFile(path.join(project,'vendor/myriad-figure/src/anime25drig/vendor/LICENSE'),path.join(root,'export/licenses/Anime2.5DRig-MIT.txt'))
await fs.copyFile(path.join(root,'licenses.html'),path.join(root,'export/licenses/index.html'))
await fs.copyFile(path.join(project,'vendor/myriad-figure/LICENSE'),path.join(root,'export/licenses/AGPL-3.0.txt'))
await fs.copyFile(path.join(project,'vendor/myriad-figure/src/anime25drig/vendor/NOTICE'),path.join(root,'export/licenses/NOTICE.txt'))
console.log(JSON.stringify({file:out,bytes:Buffer.byteLength(html),imageCount:imageNames.length,images:imageNames}))
