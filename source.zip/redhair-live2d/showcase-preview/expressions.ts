import type { Anime25DPlayer } from '../vendor/myriad-figure/src/anime25drig/index'

type Driver = ReturnType<Anime25DPlayer['getTarget']>
type NumericFaceKey =
  | 'eyeOpenL' | 'eyeOpenR' | 'eyeSmile' | 'eyeWide'
  | 'eyeDizzy' | 'eyeSqueeze' | 'eyeCry' | 'anger' | 'speechless'
  | 'accentNotes' | 'accentQuestion' | 'accentSleep' | 'accentSparkle' | 'accentBlush'
  | 'maniac' | 'silly' | 'lovestruck' | 'eyeX' | 'eyeY' | 'irisScale'
  | 'brow' | 'browAngL' | 'browAngR' | 'browAngSym'
  | 'mouthOpen' | 'mouthWide' | 'mouthRound' | 'mouthNarrow' | 'mouthSeal' | 'mouthForm'
  | 'mouthCY' | 'mouthCAng' | 'mouthScale' | 'eyeCY' | 'eyeCAng' | 'eyeScaleL' | 'eyeScaleR'
type NumericFace = Pick<Driver, NumericFaceKey>
export type ExpressionId = 'neutral' | 'smile' | 'happy' | 'surprised' | 'thinking' | 'worried' | 'angry' | 'wink' | 'shy'
export type ExpressionHead = Pick<Driver, 'angleX' | 'angleY' | 'angleZ'>
export interface ExpressionPreset {
  id: ExpressionId
  label: string
  description: string
}
export interface ExpressionSample {
  id: ExpressionId
  label: string
  driver: Partial<Driver>
  /** Add to the motion's head offsets; facial presets never own the torso or arm. */
  head: ExpressionHead
}

export const EXPRESSION_PRESETS: readonly ExpressionPreset[] = [
  { id: 'neutral', label: '自然', description: '放松的眼神与闭口' },
  { id: 'smile', label: '微笑', description: '嘴角上扬，下眼睑轻轻抬起' },
  { id: 'happy', label: '开心笑眼', description: '闭合的笑眼与张口笑容' },
  { id: 'surprised', label: '惊讶', description: '抬眉、睁眼和圆口' },
  { id: 'thinking', label: '思考', description: '眉毛稍不对称，视线移向一侧' },
  { id: 'worried', label: '担心', description: '内眉抬起，嘴角轻轻下垂' },
  { id: 'angry', label: '生气', description: '压低眉毛，略眯眼与抿嘴' },
  { id: 'wink', label: '眨眼', description: '单眼闭合，另一眼保持笑意' },
  { id: 'shy', label: '害羞', description: '视线稍向下，柔和微笑与轻淡脸红' },
]

// Every owned facial channel is returned on every sample. Switching away from
// a face therefore releases its mouth material, eye shape and accents together.
const NEUTRAL: Readonly<NumericFace> = {
  eyeOpenL: 1, eyeOpenR: 1, eyeSmile: 0, eyeWide: 0,
  eyeDizzy: 0, eyeSqueeze: 0, eyeCry: 0, anger: 0, speechless: 0,
  accentNotes: 0, accentQuestion: 0, accentSleep: 0, accentSparkle: 0, accentBlush: 0,
  maniac: 0, silly: 0, lovestruck: 0, eyeX: 0, eyeY: 0, irisScale: 1,
  brow: 0, browAngL: 0, browAngR: 0, browAngSym: 0,
  mouthOpen: 0, mouthWide: 0, mouthRound: 0, mouthNarrow: 0, mouthSeal: 0, mouthForm: 0,
  mouthCY: 0, mouthCAng: 0, mouthScale: 1,
  eyeCY: 0, eyeCAng: 0, eyeScaleL: 1, eyeScaleR: 1,
}
const HEAD_NEUTRAL: Readonly<ExpressionHead> = { angleX: 0, angleY: 0, angleZ: 0 }
const numericKeys = Object.keys(NEUTRAL) as NumericFaceKey[]
const headKeys = Object.keys(HEAD_NEUTRAL) as (keyof ExpressionHead)[]
const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x))
const mix = (a: number, b: number, t: number) => a + (b - a) * t

/**
 * The values drive the existing eyebrow/eye/mouth geometry and authored mouth
 * materials. No whole-face image swap or emoji covers the character's face.
 * `time` is expression-local seconds; reset it when choosing another preset.
 */
export function sampleExpression(
  requestedId: ExpressionId | string,
  intensity = 1,
  time = 0,
  options: { talk?: boolean } = {},
): ExpressionSample {
  const preset = EXPRESSION_PRESETS.find(p => p.id === requestedId) ?? EXPRESSION_PRESETS[0]!
  const id = preset.id, strength = clamp(Number.isFinite(intensity) ? intensity : 1, 0, 1)
  const t = Math.max(0, Number.isFinite(time) ? time : 0)
  const face: NumericFace = { ...NEUTRAL }, head: ExpressionHead = { ...HEAD_NEUTRAL }
  let blink = true
  switch (id) {
    case 'smile':
      Object.assign(face, { eyeOpenL: .97, eyeOpenR: .97, eyeSmile: .48, brow: .12, mouthOpen: .18, mouthForm: .90, mouthWide: .62, mouthScale: 1.45 })
      head.angleZ = .035
      break
    case 'happy': {
      const laugh = Math.sin(t * 7.4)
      Object.assign(face, { eyeOpenL: .018 + .012 * laugh, eyeOpenR: .018 + .012 * laugh, eyeSmile: 1, brow: .24, mouthOpen: .70 + .045 * laugh, mouthWide: .80, mouthForm: .82, mouthScale: 1.5, irisScale: 1.02 })
      head.angleY = -.035 + .018 * Math.sin(t * 5.2)
      head.angleZ = -.055
      blink = false
      break
    }
    case 'surprised':
      Object.assign(face, { eyeWide: .80, brow: .67, irisScale: .88, mouthOpen: .31, mouthRound: .86, mouthForm: -.02, mouthScale: 1.25 })
      head.angleY = -.055
      break
    case 'thinking':
      Object.assign(face, { eyeOpenL: .80, eyeOpenR: .91, brow: .24, browAngL: .48, browAngR: -.14, browAngSym: -.06, eyeX: .43 + .035 * Math.sin(t * .72), eyeY: -.26 + .025 * Math.sin(t * .58), irisScale: .96, mouthForm: -.22, mouthOpen: .065, mouthNarrow: .32, mouthScale: 1.2 })
      Object.assign(head, { angleX: -.10, angleY: .055, angleZ: -.085 })
      break
    case 'worried':
      Object.assign(face, { eyeOpenL: .92, eyeOpenR: .90, brow: .40, browAngSym: -.86, eyeY: .15, irisScale: 1.02, mouthForm: -.85, mouthNarrow: .76, mouthOpen: .13, mouthScale: 1.35 })
      Object.assign(head, { angleY: .065, angleZ: .055 })
      break
    case 'angry':
      // The actual lowered/angled brows and mouth carry this expression;
      // the optional cartoon anger-mark material deliberately stays at zero.
      Object.assign(face, { eyeOpenL: .68, eyeOpenR: .68, brow: -.50, browAngSym: .90, irisScale: .92, mouthForm: -.90, mouthNarrow: .84, mouthOpen: .14, mouthScale: 1.4 })
      Object.assign(head, { angleY: .035, angleZ: -.065 })
      break
    case 'wink':
      Object.assign(face, { eyeOpenL: .98, eyeOpenR: .015, eyeSmile: .55, brow: .08, browAngL: -.06, browAngR: .10, mouthForm: .75, mouthOpen: .12, mouthWide: .45, mouthScale: 1.35 })
      head.angleZ = -.12
      blink = false
      break
    case 'shy':
      Object.assign(face, { eyeOpenL: .83, eyeOpenR: .86, eyeSmile: .23, brow: .10, browAngSym: -.16, eyeX: .20, eyeY: .29, mouthForm: .35, mouthOpen: .08, mouthNarrow: .45, mouthScale: 1.2, accentBlush: .26 })
      Object.assign(head, { angleX: .055, angleY: .10, angleZ: .075 })
      break
    case 'neutral':
      break
  }
  if (options.talk) {
    const syllable = .18 + .82 * (.5 + .5 * Math.sin(t * 8.4 + .4 * Math.sin(t * 2.3)))
    const vowel = .5 + .5 * Math.sin(t * 3.1 + .35)
    face.mouthOpen = clamp(face.mouthOpen + .39 * syllable * (1 - face.mouthOpen), 0, .72)
    face.mouthWide = Math.max(face.mouthWide, .32 * vowel * syllable)
    face.mouthRound = Math.max(face.mouthRound, .36 * (1 - vowel) * syllable)
    face.mouthSeal = 0
  }
  const driver: Partial<Driver> = { thinking: false, talk: false, blink: strength < .15 ? true : blink, mouthEase: .40, eyeEase: .28 }
  for (const key of numericKeys) driver[key] = mix(NEUTRAL[key], face[key], strength)
  for (const key of headKeys) head[key] *= strength
  return { id, label: preset.label, driver, head }
}
