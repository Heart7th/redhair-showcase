import type { PerformanceWorkbench } from './workbench'
import type { ExpressionId } from './expressions'
import type { HeadTurnMode } from './head-motion'
export function performanceApi(app: PerformanceWorkbench) {
  return {
    setProgress: (p: number, immediate = false) => app.setProgress(p, immediate),
    setPose: (mode: string) => app.setPose(mode),
    setExpression: (id: ExpressionId) => app.setExpression(id),
    setExpressionStrength: (value: number) => app.setExpressionStrength(value),
    setExpressionLoop: (enabled: boolean) => app.setExpressionLoop(enabled),
    setHeadTurn: (mode: HeadTurnMode) => app.setHeadTurn(mode),
    setTalk: (enabled: boolean) => app.setTalk(enabled),
    setView: (view: 'full' | 'face' | 'shoulder') => app.setView(view),
    setPaused: (paused: boolean) => app.setPaused(paused),
    setSkeleton: (show: boolean) => app.setSkeleton(show),
    seek: (time: number, mode = 'demo', settleFrames = 45) => app.seek(time, mode, settleFrames),
    getState: () => app.getState(),
    snapshot: (name: string, bones = false, face?: boolean) => app.snapshot(name, bones, face),
    record: (seconds = 16, bones = false, kind: 'motion' | 'expressions' | 'shoulder' = 'motion') => app.record(seconds, bones, kind),
    reload: () => app.loadKeyforms(),
  }
}
