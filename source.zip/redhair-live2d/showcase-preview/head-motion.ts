export type HeadTurnMode = 'center' | 'left' | 'right' | 'up' | 'down' | 'auto'
export const HEAD_TURN_PERIOD_SECONDS = 16
/** The native single-front-image rig turns 11 degrees at full normalized yaw. */
export const HEAD_TURN_AMOUNT = .9
/** Native angleY raises the face using the head-depth field and connected neck. */
export const HEAD_PITCH_AMOUNT = .8
const axisKeys: readonly [number,number][] = [[0,0],[.6,0],[1.8,-1],[2.5,-1],[3.6,0],[4.2,0],[5.4,1],[6.1,1],[7.3,0],[8,0]]
const clamp = (v:number,min:number,max:number) => Math.max(min,Math.min(max,Number.isFinite(v)?v:min))
const smooth = (v:number) => { const t=clamp(v,0,1);return t*t*t*(t*(t*6-15)+10) }
function axisSample(time:number) {
  const end=axisKeys.findIndex(k=>k[0]>=time),high=Math.max(1,end),a=axisKeys[high-1]!,b=axisKeys[high]!
  return a[1]+(b[1]-a[1])*smooth((time-a[0])/(b[0]-a[0]))
}

/** Every expression completes left, right, up and down with front-facing pauses. */
export function sampleHeadTurn(mode:HeadTurnMode,time=0,intensity=1) {
  const strength=clamp(intensity,0,1),t=((Number.isFinite(time)?time:0)%HEAD_TURN_PERIOD_SECONDS+HEAD_TURN_PERIOD_SECONDS)%HEAD_TURN_PERIOD_SECONDS
  let yaw=mode==='left'?-1:mode==='right'?1:0,pitch=mode==='up'?1:mode==='down'?-1:0
  if(mode==='auto'){
    if(t<8)yaw=axisSample(t)
    else pitch=-axisSample(t-8)
  }
  const direction=yaw<-.05?'left':yaw>.05?'right':pitch>.05?'up':pitch<-.05?'down':'center'
  const label=({left:'向左',right:'向右',up:'抬头',down:'低头',center:'正面'} as const)[direction]
  return {yaw:yaw*HEAD_TURN_AMOUNT*strength,pitch:pitch*HEAD_PITCH_AMOUNT*strength,label,phase:direction,direction,localTime:t,periodSeconds:HEAD_TURN_PERIOD_SECONDS}
}
