export type HeadTurnMode = 'center' | 'left' | 'right' | 'auto'
export const HEAD_TURN_PERIOD_SECONDS = 8
/** The native single-front-image rig turns 11 degrees at full normalized yaw. */
export const HEAD_TURN_AMOUNT = .9
const keys: readonly [number,number][] = [[0,0],[.6,0],[1.8,-1],[2.5,-1],[3.6,0],[4.2,0],[5.4,1],[6.1,1],[7.3,0],[8,0]]
const clamp = (v:number,min:number,max:number) => Math.max(min,Math.min(max,Number.isFinite(v)?v:min))
const smooth = (v:number) => { const t=clamp(v,0,1);return t*t*t*(t*(t*6-15)+10) }

/** Each expression gets both sides, with a front-facing pause at either end. */
export function sampleHeadTurn(mode:HeadTurnMode,time=0,intensity=1) {
  const strength=clamp(intensity,0,1),t=((Number.isFinite(time)?time:0)%HEAD_TURN_PERIOD_SECONDS+HEAD_TURN_PERIOD_SECONDS)%HEAD_TURN_PERIOD_SECONDS
  let amount=mode==='left'?-1:mode==='right'?1:0
  if(mode==='auto'){
    const end=keys.findIndex(k=>k[0]>=t),high=Math.max(1,end),a=keys[high-1]!,b=keys[high]!
    amount=a[1]+(b[1]-a[1])*smooth((t-a[0])/(b[0]-a[0]))
  }
  const direction=amount<-.05?'left':amount>.05?'right':'center'
  return {yaw:amount*HEAD_TURN_AMOUNT*strength,label:direction==='left'?'向左':direction==='right'?'向右':'正面',phase:direction,direction,localTime:t,periodSeconds:HEAD_TURN_PERIOD_SECONDS}
}
