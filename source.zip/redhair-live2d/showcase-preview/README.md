# 红发少女 · 互动展示

中文公开展示页，默认全身连续动作和自然表情。动作、九组表情、面部与肩袖近景可互动切换；骨架、高清PNG和录制收在创作工具中。

构建：在共享 `vendor/myriad-figure/` 下 `npm ci`，再到本目录运行 `node build-offline.mjs`。产物 `export/index.html` 内嵌所用图片、配置和脚本，可单独离线打开。

完整公开目录由项目根的 `tools/package-public-showcase.py` 组装，包含单文件页面、对应源码下载和来源许可。所用姿态及素材来自 `shoulder-assets/`，保留此前高清表情、肤色、下巴和肩袖修正。

GitHub Pages：https://heart7th.github.io/redhair-showcase/
仓库：https://github.com/Heart7th/redhair-showcase

运行时 AGPL-3.0（含上游 MIT 来源）。人物图像为演示素材，代码开源不另行授予图像许可。
