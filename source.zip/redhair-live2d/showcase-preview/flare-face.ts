import type { Anime25DPlayer } from '../vendor/myriad-figure/src/anime25drig/index'

type Inspection = ReturnType<Anime25DPlayer['inspect']>
type Point = { x: number; y: number }
type Pin = { triangle: [number, number, number]; weights: [number, number, number] }
type Texture = { id: string; texture: WebGLTexture; bounds: [number, number, number, number] }

export type FlareFaceConfig = {
  crop: { x: number; y: number; width: number; height: number }
  playbackOffset: [number, number]
  transitionSeconds?: number
  /** Local crop Y where the painted eyes end and the mouth region begins. */
  upperBoundary?: number
  gridStep?: number
}
export type FlareFaceManifest = {
  expressions: { id: string; image: string; label?: string }[]
  /** A painted closed-eye patch; mouth pixels are ignored during a blink. */
  blinkImage?: string
}
export type FlareFaceOptions = { blink?: number; upperStrength?: number; mouthStrength?: number; viewport?: [number, number, number, number] }

const clamp = (x: number, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, Number.isFinite(x) ? x : lo))
const smooth = (x: number) => { const t = clamp(x); return t * t * (3 - 2 * t) }

function loadImage(url: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image(); image.onload = () => resolve(image)
    image.onerror = () => reject(Error('无法加载 Flare 表情素材：' + url)); image.src = url
  })
}

/** The same barycentric attachment used by the public player's inspection view. */
function bind(rest: Float32Array, indices: Uint16Array, point: Point): Pin {
  let outside = Infinity, result: Pin = { triangle: [0, 0, 0], weights: [1, 0, 0] }
  for (let i = 0; i < indices.length; i += 3) {
    const a = indices[i]!, b = indices[i + 1]!, c = indices[i + 2]!, x = rest[a * 2]!, y = rest[a * 2 + 1]!
    const ex = rest[b * 2]! - x, ey = rest[b * 2 + 1]! - y, fx = rest[c * 2]! - x, fy = rest[c * 2 + 1]! - y, determinant = ex * fy - fx * ey
    if (Math.abs(determinant) < 1e-9) continue
    const u = ((point.x - x) * fy - fx * (point.y - y)) / determinant
    const v = (ex * (point.y - y) - (point.x - x) * ey) / determinant
    const error = Math.max(0, -u) + Math.max(0, -v) + Math.max(0, u + v - 1)
    if (error < outside) { outside = error; result = { triangle: [a, b, c], weights: [1 - u - v, u, v] } }
    if (error === 0) break
  }
  return result
}

const VERTEX = `#version 300 es
precision highp float;
in vec2 position;in vec2 sourceUV;uniform vec2 view;out vec2 uv;
void main(){uv=sourceUV;vec2 p=position/view;gl_Position=vec4(p.x*2.-1.,1.-p.y*2.,0.,1.);}`
const FRAGMENT = `#version 300 es
precision highp float;
in vec2 uv;uniform sampler2D previousFace;uniform sampler2D nextFace;uniform sampler2D blinkFace;
uniform float transition;uniform float strength;uniform float blink;uniform float upperStrength;uniform float mouthStrength;
uniform float upperBoundary;uniform float cropHeight;out vec4 color;
void main(){
 vec4 before=texture(previousFace,uv),after=texture(nextFace,uv);
 vec4 painted=mix(before,after,transition);
 float upper=1.-smoothstep(upperBoundary-3.,upperBoundary+3.,uv.y*cropHeight);
 if(blink>0.)painted=mix(painted,texture(blinkFace,uv),blink*upper);
 color=painted*strength*mix(mouthStrength,upperStrength,upper);
}`

function shader(gl: WebGL2RenderingContext) {
  const program = gl.createProgram()!
  for (const [type, text] of [[gl.VERTEX_SHADER, VERTEX], [gl.FRAGMENT_SHADER, FRAGMENT]] as const) {
    const part = gl.createShader(type)!; gl.shaderSource(part, text); gl.compileShader(part)
    if (!gl.getShaderParameter(part, gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(part) || 'Flare shader compile')
    gl.attachShader(program, part); gl.deleteShader(part)
  }
  gl.linkProgram(program)
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw Error(gl.getProgramInfoLog(program) || 'Flare shader link')
  return program
}

/**
 * Painted feature patches ride the character's actual face mesh. The underlying
 * original head, hair, skin silhouette and body are rendered by Anime25DPlayer.
 * This renderer never substitutes the old generic eye/mouth expression shapes.
 */
export class FlareFace {
  readonly gl: WebGL2RenderingContext
  private program: WebGLProgram
  private vao: WebGLVertexArrayObject
  private positionsBuffer: WebGLBuffer
  private uvBuffer: WebGLBuffer
  private indexBuffer: WebGLBuffer
  private empty: WebGLTexture
  private faces = new Map<string, Texture>()
  private blinkTexture?: Texture
  private loaded: string[] = []
  private missing: string[] = []
  private points: Point[] = []
  private pins: Pin[] = []
  private indices = new Uint16Array()
  private positions = new Float32Array()
  private faceLayer = ''
  private faceRestLength = 0
  private active = 'neutral'
  private previous = 'neutral'
  private progress = 1
  private maskBounds: [number, number, number, number] = [0, 0, 0, 0]
  private diagnostics = { requested: 'neutral', active: 'neutral', previous: 'neutral', transition: 1, strength: 0, blink: 0, nonFinite: 0, foldedTriangles: 0, triangles: 0, faceLayer: '', loaded: [] as string[], missing: [] as string[] }

  constructor(readonly canvas: HTMLCanvasElement, readonly config: FlareFaceConfig) {
    const gl = canvas.getContext('webgl2', { alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, antialias: true })
    if (!gl) throw Error('Flare 表情需要 WebGL2')
    this.gl = gl; this.program = shader(gl); this.vao = gl.createVertexArray()!
    this.positionsBuffer = gl.createBuffer()!; this.uvBuffer = gl.createBuffer()!; this.indexBuffer = gl.createBuffer()!
    this.empty = gl.createTexture()!; gl.bindTexture(gl.TEXTURE_2D, this.empty)
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array(4)); this.textureParameters()
  }

  private textureParameters() {
    const gl = this.gl
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
  }
  private makeTexture(id: string, image: HTMLImageElement): Texture {
    const gl = this.gl, texture = gl.createTexture()!
    gl.bindTexture(gl.TEXTURE_2D, texture); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true)
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image); this.textureParameters()
    const canvas = document.createElement('canvas'); canvas.width = image.naturalWidth; canvas.height = image.naturalHeight
    const context = canvas.getContext('2d')!; context.drawImage(image, 0, 0)
    const data = context.getImageData(0, 0, canvas.width, canvas.height).data
    let x0 = canvas.width, y0 = canvas.height, x1 = 0, y1 = 0
    for (let y = 0; y < canvas.height; y++) for (let x = 0; x < canvas.width; x++) if (data[(y * canvas.width + x) * 4 + 3]! > 2) {
      x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x + 1); y1 = Math.max(y1, y + 1)
    }
    if (x1 <= x0 || y1 <= y0) { gl.deleteTexture(texture); throw Error('Flare 表情贴图为空：' + id) }
    const crop = this.config.crop
    return { id, texture, bounds: [x0 / canvas.width * crop.width, y0 / canvas.height * crop.height, x1 / canvas.width * crop.width, y1 / canvas.height * crop.height] }
  }

  async load(manifest: FlareFaceManifest, urlFor: (name: string) => string) {
    const faces = new Map<string, Texture>(), missing: string[] = []
    for (const expression of manifest.expressions) {
      if (expression.id === 'neutral') continue
      try { faces.set(expression.id, this.makeTexture(expression.id, await loadImage(urlFor(expression.image)))) }
      catch { missing.push(expression.id) }
    }
    let blinkTexture: Texture | undefined
    if (manifest.blinkImage) {
      try { blinkTexture = this.makeTexture('__blink', await loadImage(urlFor(manifest.blinkImage))) }
      catch { missing.push('__blink') }
    }
    for (const face of this.faces.values()) this.gl.deleteTexture(face.texture)
    if (this.blinkTexture) this.gl.deleteTexture(this.blinkTexture.texture)
    this.faces = faces; this.blinkTexture = blinkTexture; this.loaded = ['neutral', ...faces.keys()]; this.missing = missing
    this.active = 'neutral'; this.previous = 'neutral'; this.progress = 1
    this.buildGrid([...faces.values(), ...(blinkTexture ? [blinkTexture] : [])])
    return { loaded: [...this.loaded], missing: [...missing] }
  }

  private buildGrid(textures: Texture[]) {
    this.points = []; this.pins = []; this.faceLayer = ''; this.faceRestLength = 0
    if (!textures.length) { this.indices = new Uint16Array(); this.positions = new Float32Array(); return }
    const crop = this.config.crop
    const x0 = Math.max(0, Math.min(...textures.map(t => t.bounds[0])) - 2), y0 = Math.max(0, Math.min(...textures.map(t => t.bounds[1])) - 2)
    const x1 = Math.min(crop.width, Math.max(...textures.map(t => t.bounds[2])) + 2), y1 = Math.min(crop.height, Math.max(...textures.map(t => t.bounds[3])) + 2)
    this.maskBounds = [x0, y0, x1, y1]
    const step = Math.max(4, this.config.gridStep ?? 12), cols = Math.max(1, Math.ceil((x1 - x0) / step)), rows = Math.max(1, Math.ceil((y1 - y0) / step)), uv: number[] = [], indices: number[] = []
    for (let y = 0; y <= rows; y++) for (let x = 0; x <= cols; x++) {
      const px = x0 + (x1 - x0) * x / cols, py = y0 + (y1 - y0) * y / rows
      this.points.push({ x: crop.x + px + this.config.playbackOffset[0], y: crop.y + py + this.config.playbackOffset[1] }); uv.push(px / crop.width, py / crop.height)
      if (x < cols && y < rows) { const a = y * (cols + 1) + x, b = a + 1, d = a + cols + 1; indices.push(a, b, d, b, d + 1, d) }
    }
    this.positions = new Float32Array(this.points.length * 2); this.indices = new Uint16Array(indices)
    const gl = this.gl; gl.bindVertexArray(this.vao); gl.bindBuffer(gl.ARRAY_BUFFER, this.uvBuffer); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(uv), gl.STATIC_DRAW)
    const location = gl.getAttribLocation(this.program, 'sourceUV'); gl.enableVertexAttribArray(location); gl.vertexAttribPointer(location, 2, gl.FLOAT, false, 0, 0)
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.indices, gl.STATIC_DRAW)
  }

  draw(id: string, strength: number, dt: number, inspection: Inspection, view: { width: number; height: number }, options: FlareFaceOptions = {}) {
    const gl = this.gl, requested = id, target = this.faces.has(id) ? id : 'neutral', amount = clamp(strength)
    if (target !== this.active) { this.previous = this.active; this.active = target; this.progress = 0 }
    const duration = clamp(this.config.transitionSeconds ?? .12, .06, .18)
    this.progress = Math.min(1, this.progress + Math.max(0, Number.isFinite(dt) ? dt : 0) / duration)
    const transition = smooth(this.progress)
    const automaticBlink = this.blinkTexture && this.progress < 1 ? Math.sin(this.progress * Math.PI) ** 2 : 0
    const blink = this.blinkTexture ? Math.max(clamp(options.blink ?? 0), automaticBlink) : 0
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(...(options.viewport ?? [0, 0, this.canvas.width, this.canvas.height])); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT)
    let nonFinite = 0, foldedTriangles = 0
    const layer = inspection.layers.find(l => l.role === 'face')
    if (this.indices.length && layer && amount > 0 && (this.active !== 'neutral' || this.previous !== 'neutral' && this.progress < 1 || blink > 0)) {
      if (this.faceLayer !== layer.name || this.faceRestLength !== layer.rest.length || this.pins.length !== this.points.length) {
        this.pins = this.points.map(point => bind(layer.rest, layer.indices, point)); this.faceLayer = layer.name; this.faceRestLength = layer.rest.length
      }
      for (let i = 0; i < this.pins.length; i++) {
        const pin = this.pins[i]!; let x = 0, y = 0
        for (let k = 0; k < 3; k++) { x += layer.placed[pin.triangle[k]!*2]! * pin.weights[k]!; y += layer.placed[pin.triangle[k]!*2+1]! * pin.weights[k]! }
        const p = inspection.draw({ x, y }); this.positions[i*2] = p.x; this.positions[i*2+1] = p.y
        if (!Number.isFinite(p.x) || !Number.isFinite(p.y)) nonFinite++
      }
      for (let i = 0; i < this.indices.length; i += 3) {
        const a = this.indices[i]!*2, b = this.indices[i+1]!*2, c = this.indices[i+2]!*2, p = this.positions
        if ((p[b]!-p[a]!)*(p[c+1]!-p[a+1]!)-(p[b+1]!-p[a+1]!)*(p[c]!-p[a]!) < -.001) foldedTriangles++
      }
      if (!nonFinite) {
        gl.useProgram(this.program); gl.bindVertexArray(this.vao); gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA)
        gl.bindBuffer(gl.ARRAY_BUFFER, this.positionsBuffer); gl.bufferData(gl.ARRAY_BUFFER, this.positions, gl.DYNAMIC_DRAW)
        const position = gl.getAttribLocation(this.program, 'position'); gl.enableVertexAttribArray(position); gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0)
        gl.uniform2f(gl.getUniformLocation(this.program, 'view'), view.width, view.height)
        for (const [unit, name, texture] of [[0, 'previousFace', this.faces.get(this.previous)?.texture ?? this.empty], [1, 'nextFace', this.faces.get(this.active)?.texture ?? this.empty], [2, 'blinkFace', this.blinkTexture?.texture ?? this.empty]] as const) {
          gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, texture); gl.uniform1i(gl.getUniformLocation(this.program, name), unit)
        }
        gl.uniform1f(gl.getUniformLocation(this.program, 'transition'), transition); gl.uniform1f(gl.getUniformLocation(this.program, 'strength'), amount * layer.opacity)
        gl.uniform1f(gl.getUniformLocation(this.program, 'blink'), blink); gl.uniform1f(gl.getUniformLocation(this.program, 'upperStrength'), clamp(options.upperStrength ?? 1))
        gl.uniform1f(gl.getUniformLocation(this.program, 'mouthStrength'), clamp(options.mouthStrength ?? 1)); gl.uniform1f(gl.getUniformLocation(this.program, 'upperBoundary'), this.config.upperBoundary ?? 270)
        gl.uniform1f(gl.getUniformLocation(this.program, 'cropHeight'), this.config.crop.height)
        gl.drawElements(gl.TRIANGLES, this.indices.length, gl.UNSIGNED_SHORT, 0)
      }
    }
    this.diagnostics = { requested, active: this.active, previous: this.previous, transition, strength: amount, blink, nonFinite, foldedTriangles, triangles: this.indices.length / 3, faceLayer: layer?.name ?? '', loaded: [...this.loaded], missing: [...this.missing] }
    return { ...this.diagnostics }
  }
  inspect() { return { ...this.diagnostics, maskBounds: [...this.maskBounds], sourceCrop: { ...this.config.crop }, webglError: this.gl.getError() } }
  dispose() {
    const gl = this.gl
    for (const face of this.faces.values()) gl.deleteTexture(face.texture)
    if (this.blinkTexture) gl.deleteTexture(this.blinkTexture.texture)
    gl.deleteTexture(this.empty); gl.deleteBuffer(this.positionsBuffer); gl.deleteBuffer(this.uvBuffer); gl.deleteBuffer(this.indexBuffer); gl.deleteVertexArray(this.vao); gl.deleteProgram(this.program)
  }
}
