import type { Joints, KeyDescriptor, Point } from './arm-skin'

export type HandSourceAnchors = { wrist: [number, number]; palm: [number, number]; thumb?: [number, number] }
export type HandDescriptor = KeyDescriptor & { handSourceJoints?: HandSourceAnchors }
export type HandArt = {
  id: string
  texture: WebGLTexture
  wrist: Point
  palm: Point
  thumb: Point
  length: number
  axis: Point
  normal: Point
  bounds: [number, number, number, number]
  tipRatio: number
  widthRatio: number
  cuffHalfWidth: number
}
export type HandGeometry = { positions: number[]; firstUV: number[]; secondUV: number[]; indices: number[] }
export type HandView = ReturnType<typeof selectHandView>

const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x))
const ease = (x: number) => { const t = clamp(x); return t * t * (3 - 2 * t) }
const mix = (a: number, b: number, t: number) => a + (b - a) * t
const fallbackThumb: Record<string, [number, number]> = { down: [503, 1007], chest: [413, 424], head: [497, 160] }

/** Three drawings are views of the same left hand, not a mirrored palm reused upside-down. */
export function createHandArt(key: HandDescriptor, texture: WebGLTexture, data: Uint8ClampedArray, width: number, height: number): HandArt {
  const anchors = key.handSourceJoints ?? key.sourceJoints
  const wrist = { x: anchors.wrist[0], y: anchors.wrist[1] }, palm = { x: anchors.palm[0], y: anchors.palm[1] }
  const length = Math.hypot(palm.x - wrist.x, palm.y - wrist.y), axis = { x: (palm.x - wrist.x) / length, y: (palm.y - wrist.y) / length }, normal = { x: -axis.y, y: axis.x }
  const thumbPair = key.handSourceJoints?.thumb ?? fallbackThumb[key.id] ?? [wrist.x, wrist.y]
  const thumb = { x: thumbPair[0], y: thumbPair[1] }
  let n0 = Infinity, n1 = -Infinity, a0 = Infinity, a1 = -Infinity, cuff = 0
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) if (data[(y * width + x) * 4 + 3]! > 8) {
    const dx = x - wrist.x, dy = y - wrist.y, n = dx * normal.x + dy * normal.y, a = dx * axis.x + dy * axis.y
    n0 = Math.min(n0, n); n1 = Math.max(n1, n); a0 = Math.min(a0, a); a1 = Math.max(a1, a)
    if (Math.abs(a) < 7) cuff = Math.max(cuff, Math.abs(n))
  }
  if (!Number.isFinite(n0) || length < 1) throw Error('手部图层或手腕轴无效：' + key.id)
  return { id: key.id, texture, wrist, palm, thumb, length, axis, normal, bounds: [n0 - 2, a0 - 2, n1 + 2, a1 + 2], tipRatio: Math.max(1.4, a1 / length), widthRatio: (n1 - n0) / length, cuffHalfWidth: Math.max(20, cuff) }
}

/** Native side drawings carry thickness; open fingers are never crushed into an edge-on wire. */
export function selectHandView(progress: number, arts: HandArt[] = []) {
  const p = clamp(progress), edge = arts.find(a => a.id === 'edge')
  if (p < .26) return { sourceId: 'down', width: 1, edgeOn: false, transition: p > .16 ? 'side-to-back' : 'hold', phase: ease((p-.16)/.10), rollDegrees: 0, mirrored: false, nativeEdge: false }
  if (p < .42) return { sourceId: 'chest', width: mix(.65, 1, ease((p-.26)/.16)), edgeOn: false, transition: 'side-to-back', phase: ease((p-.26)/.16), rollDegrees: 0, mirrored: false, nativeEdge: false }
  if (p < .62) return { sourceId: 'chest', width: 1, edgeOn: false, transition: 'hold', phase: 0, rollDegrees: 0, mirrored: false, nativeEdge: false }
  const phase = ease((p-.62)/.16), edgeWidth = edge ? clamp(edge.widthRatio/profile(arts,p,'widthRatio'), .40, .70) : .65
  if (p < .66) return { sourceId: 'chest', width: mix(1,edgeWidth,ease((p-.62)/.04)), edgeOn: true, transition: 'back-to-palm', phase, rollDegrees: phase*180, mirrored: false, nativeEdge: false }
  if (p <= .74 && edge) return { sourceId: 'edge', width: edgeWidth, edgeOn: true, transition: 'back-to-palm', phase, rollDegrees: phase*180, mirrored: false, nativeEdge: true }
  // The real side view owns the narrow profile. Once the palm is visible,
  // preserve the painted finger thickness instead of flattening four fingers.
  if (p < .78) return { sourceId: 'head', width: mix(Math.max(.85,edgeWidth),1,ease((p-.74)/.04)), edgeOn: true, transition: 'back-to-palm', phase, rollDegrees: phase*180, mirrored: false, nativeEdge: false }
  return { sourceId: 'head', width: 1, edgeOn: false, transition: 'hold', phase: 0, rollDegrees: 180, mirrored: false, nativeEdge: false }
}

function profile(arts: HandArt[], progress: number, key: 'tipRatio' | 'widthRatio') {
  const p = clamp(progress), ids = ['down', 'chest', 'head'], index = p <= .5 ? 0 : 1, t = ease((p - index * .5) / .5)
  const a = arts.find(x => x.id === ids[index]) ?? arts[0]!, b = arts.find(x => x.id === ids[index + 1]) ?? arts.at(-1)!
  return mix(a[key], b[key], t)
}

export function handGeometry(art: HandArt, all: HandArt[], target: Joints, progress: number, view = selectHandView(progress, all)) {
  const delta = { x: target.palm.x - target.wrist.x, y: target.palm.y - target.wrist.y }, targetLength = Math.max(1, Math.hypot(delta.x, delta.y)), axis = { x: delta.x / targetLength, y: delta.y / targetLength }, normal = { x: -axis.y, y: axis.x }
  const tipRatio = profile(all, progress, 'tipRatio'), widthRatio = profile(all, progress, 'widthRatio'), [n0, a0, n1, a1] = art.bounds
  const project = (n: number, a: number): Point => {
    const axial = a <= art.length ? a / art.length * targetLength : targetLength + (a / art.length - 1) * targetLength * (tipRatio - 1) / (art.tipRatio - 1)
    const hand = ease(a / (art.length * .72)), cuffScale = 27 / art.cuffHalfWidth, palmScale = view.nativeEdge ? targetLength / art.length : targetLength / art.length * widthRatio / art.widthRatio * view.width
    const lateral = n * mix(cuffScale, palmScale, hand)
    return { x: target.wrist.x + axis.x * axial + normal.x * lateral, y: target.wrist.y + axis.y * axial + normal.y * lateral }
  }
  const geometry: HandGeometry = { positions: [], firstUV: [], secondUV: [], indices: [] }, columns = 8, rows = 18
  for (let j = 0; j <= rows; j++) for (let i = 0; i <= columns; i++) {
    const n = mix(n0, n1, i / columns), a = mix(a0, a1, j / rows), point = project(n, a), x = art.wrist.x + art.normal.x * n + art.axis.x * a, y = art.wrist.y + art.normal.y * n + art.axis.y * a
    geometry.positions.push(point.x, point.y); geometry.firstUV.push(x, y); geometry.secondUV.push(x, y)
    if (i < columns && j < rows) { const q = j * (columns + 1) + i; geometry.indices.push(q, q + columns + 1, q + 1, q + 1, q + columns + 1, q + columns + 2) }
  }
  const dx = art.thumb.x - art.wrist.x, dy = art.thumb.y - art.wrist.y, thumb = project(dx * art.normal.x + dy * art.normal.y, dx * art.axis.x + dy * art.axis.y)
  const thumbCross = delta.x * (thumb.y - target.wrist.y) - delta.y * (thumb.x - target.wrist.x)
  return { geometry, diagnostics: { ...view, sourceWrist: art.wrist, sourcePalm: art.palm, thumb, wrist: target.wrist, palm: target.palm, thumbCross, thumbSide: thumbCross >= 0 ? 'side/back' : 'palm', tipRatio, widthRatio } }
}
