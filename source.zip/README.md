# 公开演示对应源码

此压缩包包含互动展示页的预览源码、所用运行时源码、姿态与绑定配置、图集及实际使用的图片。

构建：
1. 进入 redhair-live2d/vendor/myriad-figure，运行 npm ci。
2. 进入 redhair-live2d/showcase-preview，运行 node build-offline.mjs。
3. 输出 redhair-live2d/showcase-preview/export/index.html 为自包含页面。

运行时代码沿用 AGPL-3.0，包含上游 MIT 来源；请保留 vendor/myriad-figure/LICENSE 和 src/anime25drig/vendor/ 中的许可、NOTICE。
角色图像为本次演示素材，此源码发布不对人物图像另行授予许可。
